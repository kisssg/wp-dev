<?php
namespace WglAddons\Widgets;

use WglAddons\Includes\Wgl_Loop_Settings;
use WglAddons\Includes\Wgl_Carousel_Settings;
use WglAddons\Templates\WglPortfolio;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Core\Schemes\Color;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Box_Shadow;

if ( ! defined( 'ABSPATH' ) ) exit; // If this file is called directly, abort.

class Wgl_Portfolio extends Widget_Base {

    public function get_name() {
        return 'wgl-portfolio';
    }

    public function get_title() {
        return esc_html__( 'WGL Portfolio', 'littledino-core' );
    }

    public function get_icon() {
        return 'wgl-portfolio';
    }

    public function get_categories() {
        return [ 'wgl-extensions' ];
    }

    public function get_script_depends() {
        return [
            'slick',
            'imagesloaded',
            'isotope',
            'wgl-elementor-extensions-widgets',
        ];
    }

    protected function register_controls() {
        $theme_color = esc_attr(\LittleDino_Theme_Helper::get_option('theme-custom-color'));
        $second_color = esc_attr(\LittleDino_Theme_Helper::get_option('theme-secondary-color'));
        $third_color = esc_attr(\LittleDino_Theme_Helper::get_option('theme-third-color'));
        $h_font_color = esc_attr(\LittleDino_Theme_Helper::get_option('header-font')['color']);
        $main_font_color = esc_attr(\LittleDino_Theme_Helper::get_option('main-font')['color']);

        /* Start General Settings Section */
        $this->start_controls_section(
            'wgl_portfolio_section',
            [ 'label' => esc_html__( 'Settings', 'littledino-core') ]
        );

        $this->add_control(
            'portfolio_layout',
            [
                'label' => esc_html__( 'Layout', 'littledino-core' ),
                'type' => 'wgl-radio-image',
                'options' => [
                    'grid' => [
                        'title'=> esc_html__( 'Grid', 'littledino-core' ),
                        'image' => WGL_ELEMENTOR_ADDONS_URL . 'assets/img/wgl_composer_addon/icons/layout_grid.png',
                    ],
                    'carousel' => [
                        'title'=> esc_html__( 'Carousel', 'littledino-core' ),
                        'image' => WGL_ELEMENTOR_ADDONS_URL . 'assets/img/wgl_composer_addon/icons/layout_carousel.png',
                    ],
                    'masonry' => [
                        'title'=> esc_html__( 'Masonry', 'littledino-core' ),
                        'image' => WGL_ELEMENTOR_ADDONS_URL . 'assets/img/wgl_composer_addon/icons/layout_masonry.png',
                    ],
                    'masonry2' => [
                        'title'=> esc_html__( 'Masonry 2', 'littledino-core' ),
                        'image' => WGL_ELEMENTOR_ADDONS_URL . 'assets/img/wgl_composer_addon/icons/layout_masonry.png',
                    ],
                    'masonry3' => [
                        'title'=> esc_html__( 'Masonry 3', 'littledino-core' ),
                        'image' => WGL_ELEMENTOR_ADDONS_URL . 'assets/img/wgl_composer_addon/icons/layout_masonry.png',
                    ],
                    'masonry4' => [
                        'title'=> esc_html__( 'Masonry 4', 'littledino-core' ),
                        'image' => WGL_ELEMENTOR_ADDONS_URL . 'assets/img/wgl_composer_addon/icons/layout_masonry.png',
                    ],
                ],
                'default' => 'grid',
            ]
        );

        $this->add_control(
            'posts_per_row',
            array(
                'label' => esc_html__( 'Columns Amount', 'littledino-core' ),
                'type' => Controls_Manager::SELECT,
                'condition' => [
                    'portfolio_layout' => [ 'grid', 'masonry', 'carousel' ],
                ],
                'options' => [
                    '1' => esc_html__( '1', 'littledino-core' ),
                    '2' => esc_html__( '2', 'littledino-core' ),
                    '3' => esc_html__( '3', 'littledino-core' ),
                    '4' => esc_html__( '4', 'littledino-core' ),
                    '5' => esc_html__( '5', 'littledino-core' ),
                ],
                'default' => '3',
            )
        );

        $this->add_control(
            'grid_gap',
            [
                'label' => esc_html__( 'Grid Gap', 'littledino-core' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '0px' => esc_html__( '0', 'littledino-core' ),
                    '1px' => esc_html__( '1', 'littledino-core' ),
                    '2px' => esc_html__( '2', 'littledino-core' ),
                    '3px' => esc_html__( '3', 'littledino-core' ),
                    '4px' => esc_html__( '4', 'littledino-core' ),
                    '5px' => esc_html__( '5', 'littledino-core' ),
                    '10px' => esc_html__( '10', 'littledino-core' ),
                    '15px' => esc_html__( '15', 'littledino-core' ),
                    '20px' => esc_html__( '20', 'littledino-core' ),
                    '25px' => esc_html__( '25', 'littledino-core' ),
                    '30px' => esc_html__( '30', 'littledino-core' ),
                    '35px' => esc_html__( '35', 'littledino-core' ),
                ],
                'default' => '30px',
            ]
        );

        $this->add_control(
            'show_filter',
            [
                'label' => esc_html__( 'Show Filter', 'littledino-core' ),
                'type' => Controls_Manager::SWITCHER,
                'condition' => [
                    'portfolio_layout' => [ 'grid', 'masonry', 'masonry2', 'masonry3', 'masonry4' ],
                ],
                'label_on' => esc_html__( 'On', 'littledino-core' ),
                'label_off' => esc_html__( 'Off', 'littledino-core' ),
                'return_value' => 'yes',
            ]
        );

        $this->add_control(
            'filter_align',
            [
                'label' => esc_html__( 'Filter Align', 'littledino-core' ),
                'type' => Controls_Manager::SELECT,
                'condition' => [ 'show_filter' => 'yes' ],
                'options' => [
                    'left' => esc_html__( 'Left', 'littledino-core' ),
                    'right' => esc_html__( 'Right', 'littledino-core' ),
                    'center' => esc_html__( 'Сenter', 'littledino-core' ),
                ],
                'default' => 'center',
            ]
        );

        $this->add_control(
            'crop_images',
            [
                'label' => esc_html__( 'Crop Images', 'littledino-core' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'On', 'littledino-core' ),
                'label_off' => esc_html__( 'Off', 'littledino-core' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'navigation',
            [
                'label' => esc_html__( 'Navigation Type', 'littledino-core' ),
                'type' => Controls_Manager::SELECT,
                'condition' => [
                    'portfolio_layout' => [ 'grid', 'masonry', 'masonry2', 'masonry3', 'masonry4' ],
                ],
                'options' => [
                    'none' => esc_html__( 'None', 'littledino-core' ),
                    'pagination' => esc_html__( 'Pagination', 'littledino-core' ),
                    'infinite' => esc_html__( 'Infinite Scroll', 'littledino-core' ),
                    'load_more' => esc_html__( 'Load More', 'littledino-core' ),
                ],
                'default' => 'none',
            ]
        );

        $this->add_control(
            'nav_align',
            [
                'label' => esc_html__( 'Navigation\'s Alignment', 'littledino-core' ),
                'type' => Controls_Manager::SELECT,
                'condition' => [ 'navigation'  => 'pagination' ],
                'options' => [
                	'center' => esc_html__( 'Сenter', 'littledino-core' ),
                    'left' => esc_html__( 'Left', 'littledino-core' ),
                    'right' => esc_html__( 'Right', 'littledino-core' ),
                ],
                'default' => 'center',
            ]
        );

        $this->add_control(
            'items_load',
            [
                'label' => esc_html__( 'Items to be loaded', 'littledino-core' ),
                'type' => Controls_Manager::TEXT,
                'condition' => [
                    'navigation' => [ 'load_more', 'infinite' ],
                ],
                'default' => esc_html__( '4', 'littledino-core' ),
            ]
        );

        $this->add_control(
            'name_load_more',
            [
                'label' => esc_html__( 'Button Text', 'littledino-core' ),
                'type' => Controls_Manager::TEXT,
                'condition' => [ 'navigation' =>  'load_more' ],
                'default' => esc_html__( 'Load More', 'littledino-core' ),
            ]
        );

        $this->add_control(
            'add_animation',
            [
                'label' => esc_html__( 'Add Appear Animation', 'littledino-core' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'On', 'littledino-core' ),
                'label_off' => esc_html__( 'Off', 'littledino-core' ),
                'return_value' => 'yes',
            ]
        );

        $this->add_control(
            'appear_animation',
            [
                'label' => esc_html__( 'Animation Style', 'littledino-core' ),
                'type' => Controls_Manager::SELECT,
                'condition' => [ 'add_animation'  => 'yes' ],
                'options' => [
                	'fade-in' => esc_html__( 'Fade In', 'littledino-core' ),
                    'slide-top' => esc_html__( 'Slide Top', 'littledino-core' ),
                    'slide-bottom' => esc_html__( 'Slide Bottom', 'littledino-core' ),
                    'slide-left' => esc_html__( 'Slide Left', 'littledino-core' ),
                    'slide-right' => esc_html__( 'Slide Right', 'littledino-core' ),
                    'zoom' => esc_html__( 'Zoom', 'littledino-core' ),
                ],
                'default' => 'fade-in',
            ]
        );

        $this->end_controls_section();

        /*-----------------------------------------------------------------------------------*/
        /*  Dispay Section
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'display_section',
            [ 'label' => esc_html__( 'Display', 'littledino-core' ) ]
        );

        $this->add_control(
            'click_area',
            [
                'label' => esc_html__( 'On click action:', 'littledino-core' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'single' => esc_html__( 'Open Single Page', 'littledino-core' ),
                    'popup' => esc_html__( 'Popup Image', 'littledino-core' ),
                    'custom' => esc_html__( 'Open Custom Link', 'littledino-core' ),
                    'none' => esc_html__( 'None', 'littledino-core' ),
                ],
                'default' => 'popup',
            ]
        );

        $this->add_control(
            'single_link_title',
            [
                'label' => esc_html__( 'Add Single Link to Title', 'littledino-core' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'On', 'littledino-core' ),
                'label_off' => esc_html__( 'Off', 'littledino-core' ),
                'return_value' => 'yes',
                'default' => 'yes'
            ]
        );

        $this->add_control(
            'info_position',
            [
                'label' => esc_html__( 'Show Info Position', 'littledino-core' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'inside_image' => esc_html__( 'Inside Image', 'littledino-core' ),
                    'under_image' => esc_html__( 'Under Image', 'littledino-core' ),
                ],
                'default' => 'inside_image',
            ]
        );

        $this->add_control(
            'image_anim',
            [
                'label' => esc_html__( 'Inside Image Animation', 'littledino-core' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'simple' => esc_html__( 'Simple', 'littledino-core'),
                    'sub_layer' => esc_html__( 'On Sub-Layer', 'littledino-core'),
                    'offset' => esc_html__( 'Side Offset', 'littledino-core'),
                    'zoom_in' => esc_html__( 'Zoom In', 'littledino-core'),
                    'outline' => esc_html__( 'Outline', 'littledino-core'),
                    'bordered' => esc_html__( 'Bordered', 'littledino-core'),
                    'always_info' => esc_html__( 'Always Show Info', 'littledino-core'),
                ],
                'default' => 'offset',
                'condition' => [ 'info_position'   => 'inside_image' ]
            ]
        );

        $this->add_control(
            'horizontal_align',
            [
                'label' => esc_html__( 'Horizontal Content Align', 'littledino-core' ),
                'type' => Controls_Manager::SELECT,
                'condition' => [ 'info_position' => 'under_image' ],
                'options' => [
                    'center' => esc_html__( 'Center', 'littledino-core' ),
                    'left' => esc_html__( 'Left', 'littledino-core' ),
                    'right' => esc_html__( 'Right', 'littledino-core' ),
                ],
                'default' => 'center',
            ]
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'content_section',
            [ 'label' => esc_html__( 'Content', 'littledino-core' ) ]
        );

        $this->add_control(
            'gallery_mode',
            array(
                'label'        => esc_html__( 'Gallery Mode', 'littledino-core' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'On', 'littledino-core' ),
                'label_off'    => esc_html__( 'Off', 'littledino-core' ),
                'return_value' => 'yes',
            )
        );

        $this->add_control(
            'show_portfolio_title',
            array(
                'label'        => esc_html__( 'Show Title?', 'littledino-core' ),
                'type'         => Controls_Manager::SWITCHER,
                'condition' => [ 'gallery_mode'  => '' ],
                'label_on'     => esc_html__( 'On', 'littledino-core' ),
                'label_off'    => esc_html__( 'Off', 'littledino-core' ),
                'return_value' => 'yes',
                'default'      => 'yes',
            )
        );

        $this->add_control(
            'show_meta_categories',
            array(
                'label' => esc_html__( 'Show categories?', 'littledino-core' ),
                'type' => Controls_Manager::SWITCHER,
                'condition' => [ 'gallery_mode' => '' ],
                'label_on' => esc_html__( 'On', 'littledino-core' ),
                'label_off' => esc_html__( 'Off', 'littledino-core' ),
                'return_value' => 'yes',
                'default' => 'yes',
            )
        );

        $this->add_control(
            'show_content',
            array(
                'label' => esc_html__( 'Show Content?', 'littledino-core' ),
                'type' => Controls_Manager::SWITCHER,
                'condition' => [ 'gallery_mode' => '' ],
                'label_on' => esc_html__( 'On', 'littledino-core' ),
                'label_off' => esc_html__( 'Off', 'littledino-core' ),
                'return_value' => 'yes',
            )
        );

        $this->add_control(
            'content_letter_count',
            [
                'label'       => esc_html__( 'Content Letter Count', 'littledino-core' ),
                'type'        => Controls_Manager::NUMBER,
                'default'     => '85',
                'description' => esc_html__( 'Enter content letter count.', 'integrio-core' ),
                'min'         => 1,
                'step'        => 1,
                'condition' => [
                    'show_content'  => 'yes',
                    'gallery_mode'  => '',
                ]
            ]
        );

        $this->end_controls_section();

        /* Start Carousel General Settings Section */
        $this->start_controls_section(
            'wgl_carousel_section',
            [
                'label' => esc_html__( 'Carousel Options', 'littledino-core' ),
                'condition' => [ 'portfolio_layout' => 'carousel' ]
            ]
        );

        $this->add_control(
            'autoplay',
            [
                'label' => esc_html__( 'Autoplay', 'littledino-core' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'On', 'littledino-core' ),
                'label_off' => esc_html__( 'Off', 'littledino-core' ),
                'return_value' => 'yes',
            ]
        );

        $this->add_control(
            'autoplay_speed',
            [
                'label' => esc_html__( 'Autoplay Speed', 'littledino-core' ),
                'type' => Controls_Manager::NUMBER,
                'condition' => [ 'autoplay' => 'yes' ],
                'default' => '3000',
                'min' => 1,
                'step' => 1,
            ]
        );

        $this->add_control(
            'multiple_items',
            [
                'label' => esc_html__( 'Multiple Items', 'littledino-core' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'On', 'littledino-core' ),
                'label_off' => esc_html__( 'Off', 'littledino-core' ),
                'return_value' => 'yes',
            ]
        );

        $this->add_control(
            'slides_to_scroll',
            [
                'label' => esc_html__( 'Slide One Item per time', 'littledino-core' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'On', 'littledino-core' ),
                'label_off' => esc_html__( 'Off', 'littledino-core' ),
                'return_value' => 'yes',
            ]
        );

        $this->add_control(
            'center_mode',
            [
                'label' => esc_html__( 'Center Mode', 'littledino-core' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'On', 'littledino-core' ),
                'label_off' => esc_html__( 'Off', 'littledino-core' ),
                'return_value' => 'yes',
            ]
        );

        $this->add_control(
            'center_info',
            [
                'label' => esc_html__( 'Show Center Info', 'littledino-core' ),
                'type' => Controls_Manager::SWITCHER,
                'condition' => [ 'center_mode'  => 'yes' ],
                'label_on' => esc_html__( 'On', 'littledino-core' ),
                'label_off' => esc_html__( 'Off', 'littledino-core' ),
                'return_value' => 'yes',
            ]
        );

        $this->add_control(
            'variable_width',
            [
                'label'        => esc_html__( 'Variable Width', 'littledino-core' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'On', 'littledino-core' ),
                'label_off'    => esc_html__( 'Off', 'littledino-core' ),
                'return_value' => 'yes',
            ]
        );

        $this->add_control(
            'use_pagination',
            [
                'label'        => esc_html__( 'Add Pagination control', 'littledino-core' ),
                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'On', 'littledino-core' ),
                'label_off'    => esc_html__( 'Off', 'littledino-core' ),
                'return_value' => 'yes',
            ]
        );

        $this->add_control(
            'pag_type',
            [
                'label' => esc_html__( 'Pagination Type', 'littledino-core' ),
                'type' => 'wgl-radio-image',
                'condition' => [ 'use_pagination'  => 'yes' ],
                'options' => [
                    'circle' => [
                        'title'=> esc_html__( 'Circle', 'littledino-core' ),
                        'image' => WGL_ELEMENTOR_ADDONS_URL . 'assets/img/wgl_composer_addon/icons/pag_circle.png',
                    ],
                    'circle_border' => [
                        'title'=> esc_html__( 'Empty Circle', 'littledino-core' ),
                        'image' => WGL_ELEMENTOR_ADDONS_URL . 'assets/img/wgl_composer_addon/icons/pag_circle_border.png',
                    ],
                    'square' => [
                        'title'=> esc_html__( 'Square', 'littledino-core' ),
                        'image' => WGL_ELEMENTOR_ADDONS_URL . 'assets/img/wgl_composer_addon/icons/pag_square.png',
                    ],
                    'line' => [
                        'title'=> esc_html__( 'Line', 'littledino-core' ),
                        'image' => WGL_ELEMENTOR_ADDONS_URL . 'assets/img/wgl_composer_addon/icons/pag_line.png',
                    ],
                    'line_circle' => [
                        'title'=> esc_html__( 'Line - Circle', 'littledino-core' ),
                        'image' => WGL_ELEMENTOR_ADDONS_URL . 'assets/img/wgl_composer_addon/icons/pag_line_circle.png',
                    ],
                ],
                'default' => 'circle',
            ]
        );

        $this->add_control(
            'pag_offset',
            [
                'label' => esc_html__( 'Pagination Top Offset', 'littledino-core' ),
                'type' => Controls_Manager::NUMBER,
                'condition' => [ 'use_pagination' => 'yes' ],
                'min' => -50,
                'max' => 250,
                'selectors' => [
                    '{{WRAPPER}} .wgl-carousel .slick-dots' => 'margin-top: {{SIZE}}px;',
                ],
            ]
        );

        $this->add_control(
            'custom_pag_color',
            [
                'label' => esc_html__( 'Custom Pagination Color', 'littledino-core' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'On', 'littledino-core' ),
                'label_off' => esc_html__( 'Off', 'littledino-core' ),
                'return_value' => 'yes',
            ]
        );

        $this->add_control(
            'pag_color',
            [
                'label' => esc_html__( 'Color', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'condition' => [ 'custom_pag_color' => 'yes' ],
                'default' => $theme_color,
                'selectors' => [
                    '{{WRAPPER}} .pagination_circle .slick-dots li button' => 'background: {{VALUE}}',
                    '{{WRAPPER}} .pagination_square .slick-dots li' => 'background: {{VALUE}}',
                    '{{WRAPPER}} .pagination_circle_border .slick-dots li.slick-active button' => 'border-color: {{VALUE}}',
                    '{{WRAPPER}} .pagination_circle_border .slick-dots li button:before' => 'background: {{VALUE}}',
                    '{{WRAPPER}} .pagination_line_circle .slick-dots li button' => 'background: {{VALUE}}',
                    '{{WRAPPER}} .pagination_line .slick-dots li button:before' => 'background: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'use_prev_next',
            [
                'label' => esc_html__( 'Add Prev/Next buttons', 'littledino-core' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'On', 'littledino-core' ),
                'label_off' => esc_html__( 'Off', 'littledino-core' ),
                'return_value' => 'yes',
            ]
        );

        $this->add_control(
            'arrows_center_mode',
            array(
                'label'        => esc_html__( 'Center Mode', 'littledino-core' ),
                'type'         => Controls_Manager::SWITCHER,
                'condition'    => [ 'use_prev_next' => 'yes' ],
                'label_on'     => esc_html__( 'On', 'littledino-core' ),
                'label_off'    => esc_html__( 'Off', 'littledino-core' ),
                'return_value' => 'yes',
            )
        );


        $this->add_control(
            'custom_resp',
            [
                'label' => esc_html__( 'Customize Responsive', 'littledino-core' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'On', 'littledino-core' ),
                'label_off' => esc_html__( 'Off', 'littledino-core' ),
                'return_value' => 'yes',
            ]
        );

        $this->add_control(
            'heading_desktop',
            [
                'label' => esc_html__( 'Desktop Settings', 'littledino-core' ),
                'type' => Controls_Manager::HEADING,
                'condition' => [ 'custom_resp' => 'yes' ],
                'separator' => 'after',
            ]
        );

        $this->add_control(
            'resp_medium',
            [
                'label' => esc_html__( 'Desktop Screen Breakpoint', 'littledino-core' ),
                'type' => Controls_Manager::NUMBER,
                'condition' => [ 'custom_resp' => 'yes' ],
                'min' => 1,
                'step' => 1,
                'default' => '1025',
            ]
        );

        $this->add_control(
            'resp_medium_slides',
            [
                'label' => esc_html__( 'Slides to show', 'littledino-core' ),
                'type' => Controls_Manager::NUMBER,
                'condition' => [ 'custom_resp' => 'yes' ],
                'min' => 1,
                'step' => 1,
            ]
        );

        $this->add_control(
            'heading_tablet',
            array(
                'label' => esc_html__( 'Tablet Settings', 'littledino-core' ),
                'type' => Controls_Manager::HEADING,
                'condition' => [ 'custom_resp' => 'yes' ],
                'separator' => 'after',
            )
        );

        $this->add_control(
            'resp_tablets',
            array(
                'label' => esc_html__( 'Tablet Screen Breakpoint', 'littledino-core' ),
                'type' => Controls_Manager::NUMBER,
                'condition' => [ 'custom_resp' => 'yes' ],
                'min' => 1,
                'step' => 1,
                'default' => '800',
            )
        );

        $this->add_control(
            'resp_tablets_slides',
            array(
                'label' => esc_html__( 'Slides to show', 'littledino-core' ),
                'type' => Controls_Manager::NUMBER,
                'condition' => [ 'custom_resp' => 'yes' ],
                'min' => 1,
                'step' => 1,
            )
        );

        $this->add_control(
            'heading_mobile',
            [
                'label' => esc_html__( 'Mobile Settings', 'littledino-core' ),
                'type' => Controls_Manager::HEADING,
                'condition' => [ 'custom_resp' => 'yes' ],
                'separator' => 'after',
            ]
        );

        $this->add_control(
            'resp_mobile',
            [
                'label' => esc_html__( 'Mobile Screen Breakpoint', 'littledino-core' ),
                'type' => Controls_Manager::NUMBER,
                'condition' => [ 'custom_resp' => 'yes' ],
                'default' => '480',
                'min' => 1,
                'step' => 1,
            ]
        );

        $this->add_control(
            'resp_mobile_slides',
            [
                'label' => esc_html__( 'Slides to show', 'littledino-core' ),
                'type' => Controls_Manager::NUMBER,
                'condition' => [ 'custom_resp'   => 'yes' ],
                'min' => 1,
                'step' => 1,
            ]
        );

        $this->end_controls_section();

        /*-----------------------------------------------------------------------------------*/
        /*  Build Query Section
        /*-----------------------------------------------------------------------------------*/

        Wgl_Loop_Settings::init(
            $this,
            [
                'post_type' => 'portfolio',
                'hide_cats' => true,
                'hide_tags' => true
            ]
        );


        /*-----------------------------------------------------------------------------------*/
        /*  STYLE -> FILTER
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'filter_cats_style_section',
            [
                'label' => esc_html__( 'Filter', 'littledino-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [ 'show_filter' => 'yes' ],
            ]
        );

        $this->add_responsive_control(
            'filter_cats_padding',
            array(
                'label' => esc_html__( 'Filter padding', 'littledino-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'default' => [
                    'top' => 1,
                    'left' => 7,
                    'right' => 7,
                    'bottom' => 1,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .isotope-filter a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            )
        );

        $this->add_responsive_control(
            'filter_cats_margin',
            [
                'label' => esc_html__( 'Filter margin', 'littledino-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'default' => [
                    'top' => 0,
                    'left' => 0,
                    'right' => 25,
                    'bottom' => 35,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .isotope-filter a' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'custom_fonts_filter_cats',
                'selector' => '{{WRAPPER}} .isotope-filter a',
            ]
        );

        $this->start_controls_tabs( 'filter_cats_color_tab' );

        $this->start_controls_tab(
            'custom_filter_cats_color_normal',
            [ 'label' => esc_html__( 'Normal' , 'littledino-core' ) ]
        );

        $this->add_control(
            'filter_cats_color',
            array(
                'label' => esc_html__( 'Color', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'default' => $h_font_color,
                'selectors' => array(
                    '{{WRAPPER}} .isotope-filter a' => 'color: {{VALUE}};',
                ),
            )
        );

        $this->add_control(
            'filter_cats_background',
            array(
                'label' => esc_html__( 'Background', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'default' => $second_color,
                'selectors' => array(
                    '{{WRAPPER}} .isotope-filter a:after' => 'background: {{VALUE}};',
                ),
            )
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'custom_filter_cats_color_hover',
            array(
                'label' => esc_html__( 'Active' , 'littledino-core' ),
            )
        );

        $this->add_control(
            'filter_cats_color_hover',
            array(
                'label' => esc_html__( 'Color', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'default' => $h_font_color,
                'selectors' => array(
                    '{{WRAPPER}} .isotope-filter a.active' => 'color: {{VALUE}};',
                ),
            )
        );

        $this->add_control(
            'filter_cats_background_hover',
            array(
                'label' => esc_html__( 'Background', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'default' => $second_color,
                'selectors' => array(
                    '{{WRAPPER}} .isotope-filter a.active:after' => 'background: {{VALUE}};',
                ),
            )
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->add_group_control(
            Group_Control_Border::get_type(),
            array(
                'name'     => 'filter_cats_border',
                'label'    => esc_html__( 'Border Type', 'littledino-core' ),
                'default' => '1px',
                'selector' => '{{WRAPPER}} .isotope-filter a',
            )
        );

        $this->add_control(
            'filter_cats_radius',
            array(
                'label' => esc_html__( 'Border Radius', 'littledino-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'default'   => [
                    'top'       => 3,
                    'left'      => 3,
                    'right'     => 3,
                    'bottom'    => 3,
                    'unit'      => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .isotope-filter a:after' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            )
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            array(
                'name'      => 'filter_cats_shadow',
                'selector' =>  '{{WRAPPER}} .isotope-filter a',
            )
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'headings_style_section',
            array(
                'label'     => esc_html__( 'Headings', 'littledino-core' ),
                'tab'       => Controls_Manager::TAB_STYLE,
            )
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            array(
                'name' => 'custom_fonts_portfolio_headings',
                'fields_options' => [
                    'typography' => ['default' => 'yes'],
                    'font_family' => ['default' => \Wgl_Addons_Elementor::$typography_1['font_family']],
                    'font_weight' => ['default' => \Wgl_Addons_Elementor::$typography_1['font_weight']],
                ],
                'selector' => '{{WRAPPER}} .title',
            )
        );

        $this->add_control(
            'h_heading_colors',
            array(
                'label'        => esc_html__( 'Custom Heading Colors', 'littledino-core' ),

                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'On', 'littledino-core' ),
                'label_off'    => esc_html__( 'Off', 'littledino-core' ),
                'return_value' => 'yes',
            )
        );

        $this->start_controls_tabs( 'headings_color' );

        $this->start_controls_tab(
            'custom_headings_color_normal',
            array(
                'label' => esc_html__( 'Normal' , 'littledino-core' ),
                'condition'     => [
                    'h_heading_colors'   => 'yes',
                ],
            )
        );

        $this->add_control(
            'custom_headings_color',
            array(
                'label' => esc_html__( 'Color', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'default' => $theme_color,
                'selectors' => array(
                    '{{WRAPPER}} .title' => 'color: {{VALUE}};',
                ),
                'condition'     => [
                    'h_heading_colors'   => 'yes',
                ],
            )
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'custom_headings_color_hover',
            array(
                'label' => esc_html__( 'Hover' , 'littledino-core' ),
                'condition'     => [
                    'h_heading_colors'   => 'yes',
                ],
            )
        );

        $this->add_control(
            'custom_hover_headings_color',
            array(
                'label' => esc_html__( 'Color', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'default' => $theme_color,
                'selectors' => array(
                    '{{WRAPPER}} .title:hover' => 'color: {{VALUE}};',
                    '{{WRAPPER}} .title:hover a' => 'color: {{VALUE}};',
                ),
                'condition' => [ 'h_heading_colors'   => 'yes' ],
            )
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->end_controls_section();

        $this->start_controls_section(
            'cats_style_section',
            array(
                'label'     => esc_html__( 'Categories', 'littledino-core' ),
                'tab'       => Controls_Manager::TAB_STYLE,
            )
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            array(
                'name' => 'custom_fonts_portfolio_cats',
                'selector' => '{{WRAPPER}} .post_cats',
            )
        );

        $this->add_control(
            'h_cat_colors',
            array(
                'label'        => esc_html__( 'Custom Categories Colors', 'littledino-core' ),

                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'On', 'littledino-core' ),
                'label_off'    => esc_html__( 'Off', 'littledino-core' ),
                'return_value' => 'yes',
            )
        );

        $this->start_controls_tabs( 'cats_color_tab' );

        $this->start_controls_tab(
            'custom_cats_color_normal',
            array(
                'label' => esc_html__( 'Normal' , 'littledino-core' ),
                'condition'     => [
                    'h_cat_colors'   => 'yes',
                ],
            )
        );

        $this->add_control(
            'cats_color',
            array(
                'label' => esc_html__( 'Color', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'default' => $theme_color,
                'selectors' => array(
                    '{{WRAPPER}} .post_cats' => 'color: {{VALUE}};',
                ),
                'condition'     => [
                    'h_cat_colors'   => 'yes',
                ],
            )
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'custom_cats_color_hover',
            array(
                'label' => esc_html__( 'Hover' , 'littledino-core' ),
                'condition' => [ 'h_cat_colors'   => 'yes' ],
            )
        );

        $this->add_control(
            'cat_color_hover',
            array(
                'label' => esc_html__( 'Color', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'default' => $theme_color,
                'selectors' => array(
                    '{{WRAPPER}} .post_cats a:hover' => 'color: {{VALUE}};',
                ),
                'condition'     => [
                    'h_cat_colors'   => 'yes',
                ],
            )
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->end_controls_section();

        $this->start_controls_section(
            'content_style_section',
            array(
                'label'     => esc_html__( 'Content', 'littledino-core' ),
                'tab'       => Controls_Manager::TAB_STYLE,
            )
        );

        $this->add_control(
            'custom_content',
            array(
                'label'        => esc_html__( 'Custom Content Colors', 'littledino-core' ),

                'type'         => Controls_Manager::SWITCHER,
                'label_on'     => esc_html__( 'On', 'littledino-core' ),
                'label_off'    => esc_html__( 'Off', 'littledino-core' ),
                'return_value' => 'yes',
            )
        );
        $this->add_control(
            'custom_content_color',
            array(
                'label' => esc_html__( 'Color', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'default' => '#cccccc',
                'selectors' => array(
                    '{{WRAPPER}} .wgl-portfolio-item_content' => 'color: {{VALUE}};',
                ),
                'condition'     => [
                    'custom_content'   => 'yes',
                ],
            )
        );

        $this->end_controls_section();


        /*-----------------------------------------------------------------------------------*/
        /*  STYLE -> ITEMS
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'section_style_items',
            [
                'label' => esc_html__( 'Items', 'littledino-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'items_radius',
            array(
                'label' => esc_html__( 'Border Radius', 'littledino-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-portfolio-item_image' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .inside_image.offset_animation:before' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
                'default'   => [
                    'top'       => 30,
                    'left'      => 30,
                    'right'     => 30,
                    'bottom'    => 30,
                    'unit'      => 'px',
                ],
            )
        );

        $this->add_responsive_control(
            'items_padding',
            [
                'label' => esc_html__( 'Padding', 'littledino-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-portfolio-item_description' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'custom_desc_mask_color',
                'label' => esc_html__( 'Background', 'littledino-core' ),
                'types' => [ 'classic', 'gradient' ],
                'condition' => [
                    'info_position' => 'inside_image',
                    'image_anim' => 'sub_layer',
                ],
                'default'  => $theme_color,
                'selector' => '{{WRAPPER}} .wgl-portfolio-item_description',
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'custom_image_mask_color',
                'label' => esc_html__( 'Background', 'littledino-core' ),
                'condition' => [
                    'image_anim!' => 'sub_layer',
                    'info_position' => 'inside_image',
                ],
                'types' => [ 'classic', 'gradient' ],
                'default' => 'rgba(14,21,30,.6)',
                'selector' => '{{WRAPPER}} .overlay',
            ]
        );

        $this->add_control(
            'sec_overlay_color',
            [
                'label' => esc_html__( 'Secondary Color', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'default' => $theme_color,
                'condition' => [
                    'image_anim' => [ 'offset', 'outline', 'always_info' ],
                    'info_position' => 'inside_image',
                ],
                'selectors' => [
                    '{{WRAPPER}} .inside_image .overlay:before' => 'box-shadow: inset 0px 0px 0px 0px {{VALUE}}',
                    '{{WRAPPER}} .inside_image:hover .overlay:before' => 'box-shadow: inset 0px 0px 0px 10px {{VALUE}}',
                    '{{WRAPPER}} .inside_image.offset_animation:before' => 'border-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'h_inner_border',
            [
                'label' => esc_html__( 'Inner Border', 'littledino-core' ),
                'type' => Controls_Manager::HEADING,
                'condition' => [
                    'image_anim' => 'bordered',
                    'info_position' => 'inside_image',
                ],
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'dashes_anim_switch',
            [
                'label' => esc_html__( 'Use running animation on Hover state?', 'littledino-core' ),
                'type' => Controls_Manager::SWITCHER,
                'condition' => [
                    'image_anim' => 'bordered',
                    'info_position' => 'inside_image',
                ],
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'dashes_color',
            [
                'label' => esc_html__( 'Dashes Color', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'condition' => [
                    'image_anim' => 'bordered',
                    'info_position' => 'inside_image',
                ],
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .inner-dashed-border' => 'stroke: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'dashes_offset',
            [
                'label' => esc_html__( 'Dashes Offset', 'littledino-core' ),
                'type' => Controls_Manager::SLIDER,
                'condition' => [
                    'image_anim' => 'bordered',
                    'info_position' => 'inside_image',
                ],
                'label_block' => true,
                'range' => [ 'px' => [ 'max' => 50 ] ],
                'default' => [ 'size' => 35, 'unit' => 'px' ],
            ]
        );

        $this->end_controls_section();


        /*-----------------------------------------------------------------------------------*/
        /*  STYLE -> LOAD MORE
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'load_more_style_section',
            [
                'label' => esc_html__( 'Load More', 'littledino-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [ 'navigation' => 'load_more' ],
            ]
        );

        $this->add_responsive_control(
            'load_more_padding',
            [
                'label' => esc_html__( 'Load More Padding', 'littledino-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'default' => [
                    'top' => 15,
                    'left' => 52,
                    'right' => 52,
                    'bottom' => 15,
                    'unit' => 'px',
                    'isLinked' => false
                ],
                'selectors' => [
                    '{{WRAPPER}} .load_more_wrapper .load_more_item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'load_more_margin',
            [
                'label' => esc_html__( 'Load More margin', 'littledino-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'default' => [
                    'top' => 50,
                    'left' => 0,
                    'right' => 0,
                    'bottom' => 0,
                    'unit' => 'px',
                    'isLinked' => false
                ],
                'selectors' => [
                    '{{WRAPPER}} .load_more_wrapper' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'custom_fonts_load_more',
                'selector' => '{{WRAPPER}} .load_more_wrapper .load_more_item',
            ]
        );


        $this->start_controls_tabs( 'load_more_color_tab' );

        $this->start_controls_tab(
            'custom_load_more_color_normal',
            [ 'label' => esc_html__( 'Normal' , 'littledino-core' ) ]
        );

        $this->add_control(
            'load_more_color',
            [
                'label' => esc_html__( 'Color', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .load_more_wrapper .load_more_item' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'load_more_background',
            [
                'label' => esc_html__( 'Background', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'default' => $second_color,
                'selectors' => [
                    '{{WRAPPER}} .load_more_wrapper .load_more_item' => 'background: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'custom_load_more_color_hover',
            [ 'label' => esc_html__( 'Hover' , 'littledino-core' ) ]
        );

        $this->add_control(
            'load_more_color_hover',
            [
                'label' => esc_html__( 'Color', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .load_more_wrapper .load_more_item:hover' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'load_more_background_hover',
            [
                'label' => esc_html__( 'Background', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'default' => $h_font_color,
                'selectors' => [
                    '{{WRAPPER}} .load_more_wrapper .load_more_item:hover' => 'background: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'load_more_border',
                'label' => esc_html__( 'Border Type', 'littledino-core' ),
                'default' => '1px',
                'selector' => '{{WRAPPER}} .load_more_wrapper .load_more_item',
            ]
        );

        $this->add_control(
            'load_more_radius',
            [
                'label' => esc_html__( 'Border Radius', 'littledino-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .load_more_wrapper .load_more_item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'load_more_shadow',
                'selector' => '{{WRAPPER}} .load_more_wrapper .load_more_item',
            ]
        );

        $this->end_controls_section();


        // Gallery Styles

        $this->start_controls_section(
            'gallery_style_section',
            [
                'label' => esc_html__( 'Gallery Icon', 'littledino-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [ 'gallery_mode'  => 'yes' ],
            ]
        );

         $this->add_control('icon_pack',
            [
                'label' => esc_html__('Icon Pack', 'littledino-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'fontawesome' => esc_html__('Fontawesome', 'littledino-core'),
                    'flaticon' => esc_html__('Flaticon', 'littledino-core'),
                ],
                'default' => 'flaticon',
            ]
        );

        $this->add_control(
            'icon_flaticon',
            [
                'label' => esc_html__( 'Icon', 'littledino-core' ),
                'type' => 'wgl-icon',
                'condition' => [ 'icon_pack' => 'flaticon' ],
                'label_block' => true,
                'default'           => 'flaticon-footprint-1',
                'description' => esc_html__( 'Select icon from Flaticon library.', 'littledino-core' ),
            ]
        );

        $this->add_control('icon_fontawesome',
            [
                'label' => esc_html__( 'Icon', 'littledino-core' ),
                'type' => Controls_Manager::ICON,
                'condition' => [ 'icon_pack'  => 'fontawesome' ],
                'label_block' => true,
                'description' => esc_html__( 'Select icon from Fontawesome library.', 'littledino-core' ),
            ]
        );

        $this->add_control(
            'gallery_icon_rotate',
            [
                'label' => esc_html__( 'Rotate Icon', 'littledino-core' ),
                'type' => Controls_Manager::SLIDER,
                'default' => [ 'size' => 0, 'unit' => 'deg' ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-portfolio-item_gallery-icon' => 'transform: rotate({{SIZE}}{{UNIT}});',
                ],
            ]
        );


        $this->add_responsive_control(
            'gallery_icon_size',
            [
                'label' => esc_html__( 'Icon Size', 'littledino-core' ),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 10,
                        'max' => 100,
                    ],
                ],
                'default'   => [
                    'unit' => 'px',
                    'size' => 54,
                    'px' => [ 'min' => 10, 'max' => 100 ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-portfolio-item_gallery-icon' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'gallery_padding',
            [
                'label' => esc_html__( 'Padding', 'littledino-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-portfolio-item_gallery-icon' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'gallery_icon_color',
            [
                'label' => esc_html__( 'Icon Color', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .wgl-portfolio-item_gallery-icon' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'gallery_icon_bg_color',
            [
                'label' => esc_html__( 'Icon Background Color', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .wgl-portfolio-item_gallery-icon' => 'background: {{VALUE}}',
                ],
            ]
        );

        $this->add_control(
            'gallery_icon_border_radius',
            [
                'label' => esc_html__( 'Border Radius', 'littledino-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-portfolio-item_gallery-icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

    }

    protected function render() {
        $atts = $this->get_settings_for_display();

       	$portfolio = new WglPortfolio();
        echo $portfolio->render($atts);
    }

    public function wpml_support_module() {
        add_filter( 'wpml_elementor_widgets_to_translate',  [$this, 'wpml_widgets_to_translate_filter']);
    }

    public function wpml_widgets_to_translate_filter( $widgets ){
        return \WglAddons\Includes\Wgl_WPML_Settings::get_translate(
            $this, $widgets
        );
    }
}
