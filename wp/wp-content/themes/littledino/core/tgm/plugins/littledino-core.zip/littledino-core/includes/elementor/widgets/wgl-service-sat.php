<?php
namespace WglAddons\Widgets;

defined('ABSPATH') || exit; // Abort, if accessed directly.

use Elementor\{Widget_Base, Controls_Manager, Scheme_Typography};
use Elementor\{Group_Control_Border, Group_Control_Typography, Group_Control_Box_Shadow, Group_Control_Background};
use WglAddons\Includes\Wgl_Icons;

class Wgl_Service_Sat extends Widget_Base
{
    public function get_name()
    {
        return 'wgl-service-sat';
    }

    public function get_title()
    {
        return esc_html__('WGL Satellite Service', 'littledino-core');
    }

    public function get_icon()
    {
        return 'wgl-services-2';
    }

    public function get_categories()
    {
        return ['wgl-extensions'];
    }

    protected function register_controls()
    {
        $theme_color = esc_attr(\LittleDino_Theme_Helper::get_option('theme-custom-color'));
        $second_color = esc_attr(\LittleDino_Theme_Helper::get_option('theme-secondary-color'));
        $third_color = esc_attr(\LittleDino_Theme_Helper::get_option('theme-third-color'));
        $h_font_color = esc_attr(\LittleDino_Theme_Helper::get_option('header-font')['color']);
        $main_font_color = esc_attr(\LittleDino_Theme_Helper::get_option('main-font')['color']);

        /*-----------------------------------------------------------------------------------*/
        /*  CONTENT -> ICON/IMAGE
        /*-----------------------------------------------------------------------------------*/

        $output['media_width'] = [
            'label' => esc_html__('Media Diameter', 'littledino-core'),
            'type' => Controls_Manager::NUMBER,
            'condition' => ['icon_type!' => ''],
            'separator' => 'before',
            'min' => 50,
            'step' => 1,
            'default' => 110,
            'selectors' => [
                '{{WRAPPER}} .sat-service__media-wrap' => 'width: {{VALUE}}px; height: {{VALUE}}px; line-height: {{VALUE}}px;',
            ],
        ];

        Wgl_Icons::init(
            $this,
            [
                'output' => $output,
                'section' => true,
            ]
        );


        /*-----------------------------------------------------------------------------------*/
        /*  CONTENT -> CONTENT
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'section_content_content',
            ['label' => esc_html__('Content', 'littledino-core')]
        );

        $this->add_control(
            'ss_title',
            [
                'label' => esc_html__('Title', 'littledino-core'),
                'type' => Controls_Manager::TEXT,
                'label_block' => true,
                'default' => esc_html__('This is the heading​', 'littledino-core'),
            ]
        );

        $this->add_control(
            'ss_content',
            [
                'label' => esc_html__('Text', 'littledino-core'),
                'type' => Controls_Manager::WYSIWYG,
                'placeholder' => esc_html__('Description Text', 'littledino-core'),
                'label_block' => true,
                'default' => esc_html__('Click edit button to change this text. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.', 'littledino-core'),
            ]
        );

        $this->add_control(
            'alignment',
            [
                'label' => esc_html__( 'Alignment', 'littledino-core' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => esc_html__( 'Left', 'littledino-core' ),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__( 'Center', 'littledino-core' ),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__( 'Right', 'littledino-core' ),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'default' => 'center',
                'toggle' => true,
                'prefix_class' => 'sat-align-',
                'selectors' => [
                    '{{WRAPPER}} .sat-service__wrap' => 'text-align: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();


        /*-----------------------------------------------------------------------------------*/
        /*  CONTENT -> SATELLITES
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'section_content_sats',
            [
                'label' => esc_html__('Satellites', 'littledino-core'),
                'condition' => ['icon_type!' => ''],
            ]
        );

        $this->add_control(
            'heading_first_sat',
            [
                'label' => esc_html__('1st Satellite', 'littledino-core'),
                'type' => Controls_Manager::HEADING,
            ]
        );

        $this->add_control(
            'sat_1_number_switch',
            [
                'label' => esc_html__('Show number in sattelite', 'littledino-core'),
                'type' => Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'sat_1_number',
            [
                'label' => esc_html__('Inner number', 'littledino-core'),
                'type' => Controls_Manager::NUMBER,
                'condition' => ['sat_1_number_switch' => 'yes'],
                'min' => 1,
                'max' => 99,
                'step' => 1,
            ]
        );

        $this->add_control(
            'sat_1_img_switch',
            [
                'label' => esc_html__('Image on satellite background', 'littledino-core'),
                'type' => Controls_Manager::SWITCHER,
                'return_value' => 'yes',
            ]
        );

        $this->add_control(
            'sat_1_img',
            [
                'label' => esc_html__('Background Image', 'littledino-core'),
                'type' => Controls_Manager::MEDIA,
                'condition' => ['sat_1_img_switch' => 'yes'],
                'label_block' => true,
            ]
        );

        $this->add_control(
            'heading_second_sat',
            [
                'label' => esc_html__('2nd Satellite', 'littledino-core'),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'sat_2_switch',
            [
                'label' => esc_html__('Add 2nd satellite', 'littledino-core'),
                'type' => Controls_Manager::SWITCHER,
                'return_value' => 'yes',
            ]
        );

        $this->add_control(
            'sat_2_img_switch',
            [
                'label' => esc_html__('Image on satellite background', 'littledino-core'),
                'type' => Controls_Manager::SWITCHER,
                'condition' => ['sat_2_switch' => 'yes'],
                'return_value' => 'yes',
            ]
        );

        $this->add_control(
            'sat_2_img',
            [
                'label' => esc_html__('Background Image', 'littledino-core'),
                'type' => Controls_Manager::MEDIA,
                'condition' => [
                    'sat_2_switch' => 'yes',
                    'sat_2_img_switch' => 'yes'
                ],
                'label_block' => true,
            ]
        );

        $this->end_controls_section();


        /*-----------------------------------------------------------------------------------*/
        /*  CONTENT -> LINK
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'section_style_link',
            ['label' => esc_html__('Link', 'littledino-core')]
        );

        $this->add_control(
            'add_item_link',
            [
                'label' => esc_html__('Full Module Link', 'littledino-core'),
                'type' => Controls_Manager::SWITCHER,
                'condition' => ['add_read_more!' => 'yes'],
                'description' => esc_html__('Clickable at any place', 'littledino-core'),
                'label_on' => esc_html__('On', 'littledino-core'),
                'label_off' => esc_html__('Off', 'littledino-core'),
                'return_value' => 'yes',
            ]
        );

        $this->add_control(
            'item_link',
            [
                'label' => esc_html__('Link', 'littledino-core'),
                'type' => Controls_Manager::URL,
                'condition' => ['add_item_link'   => 'yes'],
                'label_block' => true,
            ]
        );

        $this->add_control(
            'add_read_more',
            [
                'label' => esc_html__('Add \'Read More\' Button', 'littledino-core'),
                'type' => Controls_Manager::SWITCHER,
                'condition' => ['add_item_link!' => 'yes'],
                'label_on' => esc_html__('On', 'littledino-core'),
                'label_off' => esc_html__('Off', 'littledino-core'),
                'return_value' => 'yes',
            ]
        );

        $this->add_control(
            'read_more_text',
            [
                'label' => esc_html__('Button Text', 'littledino-core'),
                'type' => Controls_Manager::TEXT,
                'condition' => ['add_read_more' => 'yes'],
                'default' =>  esc_html__('Read More', 'littledino-core'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'link',
            [
                'label' => esc_html__('Button Link', 'littledino-core'),
                'type' => Controls_Manager::URL,
                'condition' => ['add_read_more' => 'yes'],
                'label_block' => true,
            ]
        );

        $this->end_controls_section();


        /*-----------------------------------------------------------------------------------*/
        /*  STYLE -> MEDIA
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'section_style_media',
            [
                'label' => esc_html__('Media', 'littledino-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->start_controls_tabs(
            'icon_colors',
            ['condition' => ['icon_type' => 'font']]
        );

        $this->start_controls_tab(
            'icon_colors_normal',
            ['label' => esc_html__('Idle', 'littledino-core')]
        );

        $this->add_control(
            'primary_color',
            [
                'label' => esc_html__('Icon Color', 'littledino-core'),
                'type' => Controls_Manager::COLOR,
                'default' => $second_color,
                'selectors' => [
                    '{{WRAPPER}} .wgl-icon' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'icon_colors_hover',
            ['label' => esc_html__('Hover', 'littledino-core')]
        );

        $this->add_control(
            'hover_primary_color',
            [
                'label' => esc_html__('Icon Color', 'littledino-core'),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}}:hover .wgl-icon' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();

        $this->add_responsive_control(
            'icon_space',
            [
                'label' => esc_html__('Margin', 'littledino-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .sat-service__media-wrap' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'icon_size',
            [
                'label' => esc_html__('Icon Size', 'littledino-core'),
                'type' => Controls_Manager::SLIDER,
                'condition' => ['icon_type' => 'font'],
                'range' => [
                    'px' => [
                        'min' => 16,
                        'max' => 100,
                    ],
                ],
                'default'   => [
                    'unit' => 'px',
                    'size' => 45,
                ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-icon' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'image_size',
            [
                'label' => esc_html__('Width', 'littledino-core') . ' (%)',
                'type' => Controls_Manager::SLIDER,
                'condition' => ['icon_type' => 'image'],
                'size_units' => ['%'],
                'range' => [
                    '%' => [
                        'min' => 5,
                        'max' => 100,
                    ],
                ],
                'default' => [
                    'size' => 100,
                    'unit' => '%',
                ],
                'tablet_default' => ['unit' => '%'],
                'mobile_default' => ['unit' => '%'],
                'selectors' => [
                    '{{WRAPPER}} .elementor-image-box-img .wgl-widget_container' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();


        /*-----------------------------------------------------------------------------------*/
        /*  STYLE -> SATELLITES
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'section_style_satellites',
            [
                'label' => esc_html__('Satellites', 'littledino-core'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => ['icon_type!'  => ''],
            ]
        );

        $this->add_responsive_control(
            's_orbit_width',
            [
                'label' => esc_html__('Orbit Width', 'littledino-core'),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 1,
                        'max' => 10,
                    ],
                ],
                'default'   => [
                    'size' => 2,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .sat-service__media-wrap' => 'border-width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            's_orbit_type',
            [
                'label' => esc_html__('Orbit Type', 'Border Control', 'littledino-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'dashed' => esc_html__('Dashed', 'Border Control', 'littledino-core'),
                    'solid' => esc_html__('Solid', 'Border Control', 'littledino-core'),
                    'double' => esc_html__('Double', 'Border Control', 'littledino-core'),
                    'dotted' => esc_html__('Dotted', 'Border Control', 'littledino-core'),
                    'groove' => esc_html__('Groove', 'Border Control', 'littledino-core'),
                ],
                'default' => 'dashed',
                'selectors' => [
                    '{{WRAPPER}} .sat-service__media-wrap' => 'border-style: {{VALUE}};',
                ],
            ]
        );

        $this->start_controls_tabs('border_colors');

        $this->start_controls_tab(
            'orbit_colors_normal',
            ['label' => esc_html__('Idle', 'littledino-core')]
        );

        $this->add_control(
            'orbit_color_idle',
            [
                'label' => esc_html__('Orbit Color', 'littledino-core'),
                'type' => Controls_Manager::COLOR,
                'default' => $theme_color,
                'selectors' => [
                    '{{WRAPPER}} .sat-service__media-wrap' => 'border-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'tab_border_hover_color',
            ['label' => esc_html__('Hover', 'littledino-core')]
        );

        $this->add_control(
            'orbit_color_hover',
            [
                'label' => esc_html__('Orbit Color', 'littledino-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}}:hover .sat-service__media-wrap' => 'border-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();

        $this->add_responsive_control(
            'sat_offset',
            [
                'label' => esc_html__('Satellite Offset', 'littledino-core'),
                'type' => Controls_Manager::SLIDER,
                'separator' => 'before',
                'range' => [
                    'px' => [
                        'min' => 1,
                        'max' => 50,
                    ],
                ],
                'default'   => [
                    'size' => 15,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .sat-service__media-wrap' => 'padding: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'sat_diameter',
            [
                'label' => esc_html__('Satellite Diameter', 'littledino-core'),
                'type' => Controls_Manager::NUMBER,
                'separator' => 'after',
                'min' => 2,
                'step' => 1,
                'default' => 38,
                'selectors' => [
                    '{{WRAPPER}} .sat-service__satellite' => 'width: {{VALUE}}px; height: {{VALUE}}px; font-size: calc({{VALUE}}px / 2); line-height: {{VALUE}}px;',
                ],
            ]
        );

        $this->add_control(
            'heading_first_sat_style',
            [
                'label' => esc_html__('1st Satellite', 'littledino-core'),
                'type' => Controls_Manager::HEADING,
            ]
        );

        $this->add_control(
            'sat_1_color',
            [
                'label' => esc_html__('Color', 'littledino-core'),
                'type' => Controls_Manager::COLOR,
                'condition' => ['sat_1_number_switch' => 'yes'],
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .sat-service__satellite-wrapper:nth-child(1) .sat-service__satellite' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'sat_1_bg',
            [
                'label' => esc_html__('Background Color', 'littledino-core'),
                'type' => Controls_Manager::COLOR,
                'default' => $second_color,
                'selectors' => [
                    '{{WRAPPER}} .sat-service__satellite-wrapper:nth-child(1) .sat-service__satellite' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'heading_second_sat_style',
            [
                'label' => esc_html__('2nd Satellite', 'littledino-core'),
                'type' => Controls_Manager::HEADING,
                'condition' => ['sat_2_switch' => 'yes'],
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'sat_2_bg',
            [
                'label' => esc_html__('2nd Satellite Background Color', 'littledino-core'),
                'type' => Controls_Manager::COLOR,
                'condition' => ['sat_2_switch' => 'yes'],
                'default' => $second_color,
                'selectors' => [
                    '{{WRAPPER}} .sat-service__satellite-wrapper:nth-child(2) .sat-service__satellite' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'heading_sat_animation',
            [
                'label' => esc_html__('Animation', 'littledino-core'),
                'type' => Controls_Manager::HEADING,
                'condition' => ['icon_type!' => ''],
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'ss_sat_animation',
            [
                'label' => esc_html__('Hover Animation', 'littledino-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '360' => esc_html__('Infinite rotation', 'littledino-core'),
                    '90' => esc_html__('Сrank 90 degrees', 'littledino-core'),
                ],
                'default' => '90',
                'prefix_class' => 'sat-animation-'
            ]
        );

        $this->add_control(
            'ss_sat_animation_duration',
            [
                'label' => esc_html__('Animation Duaration', 'littledino-core'),
                'type' => Controls_Manager::SLIDER,
                'condition' => ['ss_sat_animation' => '360'],
                'size_units' => ['s'],
                'range' => [
                    's' => ['min' => 1, 'max' => 7, 'step' => 0.1],
                ],
                'default' => ['size' => 3, 'unit' => 's'],
                'selectors' => [
                    '{{WRAPPER}} .sat-service__satellite-wrapper' => 'animation-duration: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .sat-service__satellite' => 'animation-duration: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();


        /*-----------------------------------------------------------------------------------*/
        /*  STYLE -> TITLE
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'section_style_title',
            [
                'label' => esc_html__('Title', 'littledino-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->start_controls_tabs('tabs_title_colors');

        $this->start_controls_tab(
            'tab_idle_title_color',
            ['label' => esc_html__('Idle', 'littledino-core')]
        );

        $this->add_control(
            'title_color_idle',
            [
                'label' => esc_html__('Color', 'littledino-core'),
                'type' => Controls_Manager::COLOR,
                'default' => $h_font_color,
                'selectors' => [
                    '{{WRAPPER}} .sat-service__title' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'tab_hover_title_color',
            ['label' => esc_html__('Hover', 'littledino-core')]
        );

        $this->add_control(
            'title_color_hover',
            [
                'label' => esc_html__('Color', 'littledino-core'),
                'type' => Controls_Manager::COLOR,
                'default' => $h_font_color,
                'selectors' => [
                    '{{WRAPPER}}:hover .sat-service__title' => 'color: {{VALUE}};',
                    '{{WRAPPER}}:hover .sat-service__title a' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();

        $this->add_responsive_control(
            'title_margin',
            [
                'label' => esc_html__('Margin', 'littledino-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'separator' => 'before',
                'default' => [
                    'top' => 15,
                    'right' => 0,
                    'bottom' => 10,
                    'left' => 0,
                    'unit'  => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .sat-service__title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'custom_fonts_title',
                'selector' => '{{WRAPPER}} .sat-service__title',
            ]
        );

        $this->add_control(
            'title_tag',
            [
                'label' => esc_html__('HTML Tag', 'littledino-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'h1' => '‹h1›',
                    'h2' => '‹h2›',
                    'h3' => '‹h3›',
                    'h4' => '‹h4›',
                    'h5' => '‹h5›',
                    'h6' => '‹h6›',
                    'div' => '‹div›',
                    'span' => '‹span›',
                ],
                'default' => 'h3',
            ]
        );

        $this->end_controls_section();


        /*-----------------------------------------------------------------------------------*/
        /*  STYLE -> CONTENT
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'section_style_content',
            [
                'label' => esc_html__('Content', 'littledino-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'content_tag',
            [
                'label' => esc_html__('Content Tag', 'littledino-core'),
                'type' => Controls_Manager::SELECT,
                'default' => 'div',
                'description' => esc_html__('Choose your tag for service content', 'littledino-core'),
                'options' => [
                    'h1' => '‹h1›',
                    'h2' => '‹h2›',
                    'h3' => '‹h3›',
                    'h4' => '‹h4›',
                    'h5' => '‹h5›',
                    'h6' => '‹h6›',
                    'div' => '‹div›',
                    'span' => '‹span›',
                ],
            ]
        );

        $this->add_responsive_control(
            'content_offset',
            [
                'label' => esc_html__('Content Offset', 'littledino-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'default' => [
                    'top' => 0,
                    'right' => 0,
                    'bottom' => 20,
                    'left' => 0,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .sat-service__text' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'content_padding',
            [
                'label' => esc_html__('Content Padding', 'littledino-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .sat-service__text' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'custom_content_mask_color',
                'label' => esc_html__('Background', 'littledino-core'),
                'types' => ['classic', 'gradient'],
                'condition' => ['custom_bg' => 'custom'],
                'selector' => '{{WRAPPER}} .sat-service__text',
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'custom_fonts_content',
                'fields_options' => [
                    'typography' => ['default' => 'yes'],
                    'font_family' => ['default' => \Wgl_Addons_Elementor::$typography_3['font_family']],
                    'font_weight' => ['default' => \Wgl_Addons_Elementor::$typography_3['font_weight']],
                ],
                'selector' => '{{WRAPPER}} .sat-service__text',
            ]
        );

        $this->start_controls_tabs('content_color_tab');

        $this->start_controls_tab(
            'custom_content_color_normal',
            ['label' => esc_html__('Idle', 'littledino-core')]
        );

        $this->add_control(
            'content_color',
            [
                'label' => esc_html__('Color', 'littledino-core'),
                'type' => Controls_Manager::COLOR,
                'default' => esc_attr($main_font_color),
                'selectors' => [
                    '{{WRAPPER}} .sat-service__text' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'custom_content_color_hover',
            ['label' => esc_html__('Hover', 'littledino-core')]
        );

        $this->add_control(
            'content_color_hover',
            [
                'label' => esc_html__('Color', 'littledino-core'),
                'type' => Controls_Manager::COLOR,
                'default' => esc_attr($main_font_color),
                'selectors' => [
                    '{{WRAPPER}}:hover .sat-service__text' => 'color: {{VALUE}};'
                ],
            ]
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();


        /*-----------------------------------------------------------------------------------*/
        /*  STYLE -> BUTTON
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'section_style_button',
            [
                'label' => esc_html__('Button', 'littledino-core'),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => ['add_read_more!'   => ''],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'custom_fonts_button',
                'fields_options' => [
                    'typography' => ['default' => 'yes'],
                    'font_family' => ['default' => \Wgl_Addons_Elementor::$typography_1['font_family']],
                    'font_weight' => ['default' => \Wgl_Addons_Elementor::$typography_1['font_weight']],
                ],
                'selector' => '{{WRAPPER}} .button-read-more',
            ]
        );

        $this->add_responsive_control(
            'custom_button_padding',
            [
                'label' => esc_html__('Padding', 'littledino-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .button-read-more' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'custom_button_margin',
            [
                'label' => esc_html__('Margin', 'littledino-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', 'em', '%'],
                'selectors' => [
                    '{{WRAPPER}} .button-read-more' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'custom_button_border',
            [
                'label' => esc_html__('Border Radius', 'littledino-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'selectors' => [
                    '{{WRAPPER}} .button-read-more' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->start_controls_tabs('button_color_tab');

        $this->start_controls_tab(
            'custom_button_color_normal',
            ['label' => esc_html__('Idle', 'littledino-core')]
        );

        $this->add_control(
            'button_background',
            [
                'label' => esc_html__('Background Color', 'littledino-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .button-read-more' => 'background: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'button_color',
            [
                'label' => esc_html__('Color', 'littledino-core'),
                'type' => Controls_Manager::COLOR,
                'default' => esc_attr($theme_color),
                'selectors' => [
                    '{{WRAPPER}} .button-read-more' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'button_border',
                'label' => esc_html__('Border Type', 'littledino-core'),
                'selector' => '{{WRAPPER}} .button-read-more',
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'button_shadow',
                'selectors' => '{{WRAPPER}} .button-read-more',
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'custom_button_color_hover',
            ['label' => esc_html__('Hover', 'littledino-core')]
        );

        $this->add_control(
            'button_background_hover',
            [
                'label' => esc_html__('Background Color', 'littledino-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .button-read-more:hover' => 'background: {{VALUE}};'
                ],
            ]
        );

        $this->add_control(
            'button_color_hover',
            [
                'label' => esc_html__('Color', 'littledino-core'),
                'type' => Controls_Manager::COLOR,
                'default' => $second_color,
                'selectors' => [
                    '{{WRAPPER}} .button-read-more:hover' => 'color: {{VALUE}};'
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'button_border_hover',
                'label' => esc_html__('Border Type', 'littledino-core'),
                'selector' => '{{WRAPPER}} .button-read-more:hover',
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'button_shadow_hover',
                'selector' => '{{WRAPPER}} .button-read-more:hover',
            ]
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();
    }

    /**
     * @since 1.0.0
     * @version 1.0.5
     */
    public function render()
    {
        $_s = $this->get_settings_for_display();
        if ($_s['icon_type'] != '') {
            $orbit_w = $_s['media_width'] + $_s['sat_offset']['size'] * 2;
            $sat_1_number = !empty($_s['sat_1_number']) ? $_s['sat_1_number'] : '';
            if ($sat_1_number > 0 && $sat_1_number < 10) $sat_1_number = '0' . $sat_1_number;
            $this->add_render_attribute(
                [
                    'circle_wrap' => [
                        'class' => 'sat-service__satellite-wrapper',
                        'style' => [
                            'width: ' . (round($orbit_w / sqrt(2))) . 'px;',
                            'height: ' . (round($orbit_w / sqrt(2))) . 'px;',
                            'left: ' . (($orbit_w - round($orbit_w / sqrt(2))) / 2) . 'px;',
                            'top: ' . (($orbit_w - round($orbit_w / sqrt(2))) / 2) . 'px;',
                        ]
                    ],
                    'sat_1' => ['class' => 'sat-service__satellite'],
                    'sat_2' => ['class' => 'sat-service__satellite'],
                ]
            );
        }

        $this->add_render_attribute(
            [
                'wrapper' => ['class' => 'wgl-service-satellite'],
                'read-more' => ['class' => 'button-read-more wgl-read-more_icon flaticon-footprint'],
                'full_module_link' => ['class' => 'sat-service__item-link'],
            ]
        );
        if (isset($_s['sat_1_img']['url'])) {
            $this->add_render_attribute('sat_1', 'style', 'background-image: url(' . esc_url($_s['sat_1_img']['url']) . ')');
        }
        if (isset($_s['sat_2_img']['url'])) {
            $this->add_render_attribute('sat_2', 'style', 'background-image: url(' . esc_url($_s['sat_2_img']['url']) . ')');
        }
        if (!empty($_s['link']['url'])) {
            $this->add_link_attributes('read-more', $_s['link']);
        }
        if (!empty($_s['item_link']['url'])) {
            $this->add_link_attributes('full_module_link', $_s['item_link']);
        }

        // KSES allowed tags
        $allowed_html = [
            'a' => [
                'href' => true, 'title' => true,
                'class' => true, 'style' => true,
                'target' => true, 'rel' => true,
            ],
            'br' => ['class' => true, 'style' => true],
            'em' => ['class' => true, 'style' => true],
            'strong' => ['class' => true, 'style' => true],
            'span' => ['class' => true, 'style' => true],
            'p' => ['class' => true, 'style' => true],
        ];

        // Icon/Image out
        ob_start();
        if (!empty($_s['icon_type'])) {
            $icons = new Wgl_Icons;
            echo $icons->build($this, $_s, []);
        }
        $services_media = ob_get_clean();

        // Render
        printf('<div %s>', $this->get_render_attribute_string('wrapper'));
        ?>
        <div class="sat-service__wrap"><?php
            if ($_s['icon_type'] != '') { ?>
                <div class="sat-service__media-wrap"><?php
                    printf(
                        '<div %s><div %s>%s</div></div>',
                        $this->get_render_attribute_string('circle_wrap'),
                        $this->get_render_attribute_string('sat_1'),
                        $sat_1_number
                    );
                    if ($_s['sat_2_switch'])
                        printf(
                            '<div %s><div %s></div></div>',
                            $this->get_render_attribute_string('circle_wrap'),
                            $this->get_render_attribute_string('sat_2')
                        );
                    if ($services_media) echo $services_media;
                    ?>
                </div><?php
            }
            ?>
            <div class="sat-service__content-wrap"><?php
                printf(
                    '<%1$s class="sat-service__title">%2$s</%1$s>',
                    $_s['title_tag'],
                    wp_kses($_s['ss_title'], $allowed_html)
                );
                if ($_s['ss_content'])
                    printf(
                        '<%1$s class="sat-service__text">%2$s</%1$s>',
                        $_s['content_tag'],
                        wp_kses($_s['ss_content'], $allowed_html)
                    );
                if ($_s['add_read_more'])
                    printf(
                        '<a %s>%s</a>',
                        $this->get_render_attribute_string('read-more'),
                        esc_html($_s['read_more_text'])
                    );
                ?>
            </div><?php
                if ($_s['add_item_link'])
                    printf('<a %s></a>', $this->get_render_attribute_string('full_module_link'));
                ?>
            </div>
        </div>
        <?php
    }

    public function wpml_support_module() {
        add_filter( 'wpml_elementor_widgets_to_translate',  [$this, 'wpml_widgets_to_translate_filter']);
    }

    public function wpml_widgets_to_translate_filter( $widgets ){
        return \WglAddons\Includes\Wgl_WPML_Settings::get_translate(
            $this, $widgets
        );
    }
}
