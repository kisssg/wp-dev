<?php

namespace WglAddons\Templates;

if ( ! defined( 'ABSPATH' ) ) { exit; }

use Elementor\Plugin;
use Elementor\Frontend;
use WglAddons\Includes\Wgl_Loop_Settings;
use WglAddons\Includes\Wgl_Elementor_Helper;
use WglAddons\Includes\Wgl_Carousel_Settings;
use WglAddons\Includes\Wgl_Icons;
use WglAddons\Templates\WglButton;


/**
* WGL Countdown
*
*
* @class        WglCountDown
* @version      1.0
* @category     Class
* @author       WebGeniusLab
*/

class WglCountDown{

    private static $instance = null;
    public static function get_instance( ) {
        if ( null == self::$instance ) {
            self::$instance = new self( );
        }

        return self::$instance;
    }

    public function render( $self, $atts ){

        extract($atts);

        wp_enqueue_script('coundown', get_template_directory_uri() . '/js/jquery.countdown.min.js', array(), false, false);

        // Module unique id
        $cd_id = uniqid( 'countdown_' );
        $cd_attr = ' id='.$cd_id;

        $wrapper_class = $hide_separating ? '' : ' show_separating';
        $wrapper_class .= $hide_value_names ? ' hide-period' : '';

        $f = !(bool)$hide_day ? 'd' : '';
        $f .= !(bool)$hide_hours ? 'H' : '';
        $f .= !(bool)$hide_minutes ? 'M' : '';
        $f .= !(bool)$hide_seconds ? 'S' : '';

        // Countdown data attribute http://keith-wood.name/countdown.html
        $cd_data = array(); 

        $cd_data['format'] = !empty($f) ? esc_attr($f) : '';

        $cd_data['year'] = esc_attr($cd_year);
        $cd_data['month'] = esc_attr($cd_month);
        $cd_data['day'] = esc_attr($cd_day);
        $cd_data['hours'] = esc_attr($cd_hour);
        $cd_data['minutes'] = esc_attr($cd_minute);

        $cd_data['labels'][] = esc_attr( esc_html__( 'Years', 'littledino-core' ) );
        $cd_data['labels'][] = esc_attr( esc_html__( 'Months', 'littledino-core' ) );
        $cd_data['labels'][] = esc_attr( esc_html__( 'Weeks', 'littledino-core' ) );
        $cd_data['labels'][] = esc_attr( esc_html__( 'Days', 'littledino-core' ) );
        $cd_data['labels'][] = esc_attr( esc_html__( 'Hours', 'littledino-core' ) );
        $cd_data['labels'][] = esc_attr( esc_html__( 'Minutes', 'littledino-core' ) );
        $cd_data['labels'][] = esc_attr( esc_html__( 'Seconds', 'littledino-core' ) );
        $cd_data['labels1'][] = esc_attr( esc_html__( 'Year', 'littledino-core' ) );
        $cd_data['labels1'][] = esc_attr( esc_html__( 'Month', 'littledino-core' ) );
        $cd_data['labels1'][] = esc_attr( esc_html__( 'Week', 'littledino-core' ) );
        $cd_data['labels1'][] = esc_attr( esc_html__( 'Day', 'littledino-core' ) );
        $cd_data['labels1'][] = esc_attr( esc_html__( 'Hour', 'littledino-core' ) );
        $cd_data['labels1'][] = esc_attr( esc_html__( 'Minute', 'littledino-core' ) );
        $cd_data['labels1'][] = esc_attr( esc_html__( 'Second', 'littledino-core' ) );

        $data_attribute = json_encode($cd_data, true);

        printf( '<div%s class="wgl-countdown%s" data-atts="%s"></div>',
            $cd_attr,
            esc_attr($wrapper_class),
            esc_js($data_attribute)
        );
    }
}