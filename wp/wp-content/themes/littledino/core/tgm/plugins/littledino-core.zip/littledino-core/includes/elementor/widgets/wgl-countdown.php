<?php

namespace WglAddons\Widgets;

if ( ! defined( 'ABSPATH' ) ) exit; // Abort, if accessed directly.

use WglAddons\Includes\Wgl_Icons;
use WglAddons\Includes\Wgl_Loop_Settings;
use WglAddons\Includes\Wgl_Carousel_Settings;
use WglAddons\Templates\WglCountDown;
use Elementor\Widget_Base;
use Elementor\Utils;
use Elementor\Controls_Manager;
use Elementor\Core\Schemes\Color;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Box_Shadow;


class Wgl_CountDown extends Widget_Base {

	public function get_name() {
		return 'wgl-countdown';
	}

	public function get_title() {
		return esc_html__( 'WGL Countdown Timer', 'littledino-core' );
	}

	public function get_icon() {
		return 'wgl-countdown';
	}

	public function get_categories() {
		return [ 'wgl-extensions' ];
	}

	public function get_script_depends() {
		return [
			'coundown',
			'wgl-elementor-extensions-widgets',
		];
	}

	protected function register_controls() {
		$theme_color = esc_attr(\LittleDino_Theme_Helper::get_option('theme-custom-color'));
		$second_color = esc_attr(\LittleDino_Theme_Helper::get_option('theme-secondary-color'));
		$h_font_color = esc_attr(\LittleDino_Theme_Helper::get_option('header-font')['color']);
		$main_font_color = esc_attr(\LittleDino_Theme_Helper::get_option('main-font')['color']);


		/*-----------------------------------------------------------------------------------*/
		/*  CONTENT -> GENERAL
		/*-----------------------------------------------------------------------------------*/

		$this->start_controls_section(
			'section_content_general',
			[ 'label' => esc_html__( 'General', 'littledino-core' ) ]
		);

		$this->add_control(
			'h_tip',
			[
				'label' => esc_html__( 'Choose the specific date', 'littledino-core' ),
				'type' => Controls_Manager::HEADING,
			]
		);

		$this->add_control(
			'cd_year',
			[
				'label' => esc_html__( 'Year', 'littledino-core' ),
				'type' => Controls_Manager::TEXT,
				'placeholder' => esc_attr__( 'Example: 2020', 'littledino-core' ),
				'default' => esc_html__( '2020', 'littledino-core' ),
			]
		);

		$this->add_control(
			'cd_month',
			[
				'label' => esc_html__( 'Month', 'littledino-core' ),
				'type' => Controls_Manager::TEXT,
				'placeholder' => esc_attr__( 'Example: 12', 'littledino-core' ),
				'default' => esc_html__( '12', 'littledino-core' ),
			]
		);

		$this->add_control(
			'cd_day',
			[
				'label' => esc_html__( 'Day', 'littledino-core' ),
				'type' => Controls_Manager::TEXT,
				'placeholder' => esc_attr__( 'Example: 31', 'littledino-core' ),
				'default' => esc_html__( '31', 'littledino-core' ),
			]
		);

		$this->add_control(
			'cd_hour',
			[
				'label' => esc_html__( 'Hour', 'littledino-core' ),
				'type' => Controls_Manager::TEXT,
				'placeholder' => esc_attr__( 'Example: 24', 'littledino-core' ),
				'default' => esc_html__( '24', 'littledino-core' ),
			]
		);

		$this->add_control(
			'cd_minute',
			[
				'label' => esc_html__( 'Minute', 'littledino-core' ),
				'type' => Controls_Manager::TEXT,
				'placeholder' => esc_attr__( 'Example: 59', 'littledino-core' ),
				'description'  => esc_html__( 'All above fields should be filled.', 'text-domain' ),
				'default' => esc_html__( '59', 'littledino-core' ),
			]
		);

		$this->end_controls_section();


		/*-----------------------------------------------------------------------------------*/
		/*  CONTENT -> CONTENT
		/*-----------------------------------------------------------------------------------*/

		$this->start_controls_section(
			'section_content_content',
			[ 'label' => esc_html__( 'Content', 'littledino-core' ) ]
		);

		$this->add_control(
			'cd_alignment',
			[
				'label' => esc_html__( 'Alignment', 'littledino-core' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'littledino-core' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'littledino-core' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'littledino-core' ),
						'icon' => 'eicon-text-align-right',
					],
					'justify' => [
						'title' => esc_html__( 'Justify', 'littledino-core' ),
						'icon' => 'eicon-text-align-justify',
					],
				],
				'toggle' => true,
				'prefix_class' => 'cd__align-',
				'default' => 'center',
			]
		);

		$this->add_control(
			'hide_day',
			[
				'label' => esc_html__( 'Hide Days?', 'littledino-core' ),
				'type' => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
			]
		);

		$this->add_control(
			'hide_hours',
			[
				'label' => esc_html__( 'Hide Hours?', 'littledino-core' ),
				'type' => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
			]
		);

		$this->add_control(
			'hide_minutes',
			[
				'label' => esc_html__( 'Hide Minutes?', 'littledino-core' ),
				'type' => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
			]
		);

		$this->add_control(
			'hide_seconds',
			[
				'label' => esc_html__( 'Hide Seconds?', 'littledino-core' ),
				'type' => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
			]
		);

		$this->add_control(
			'hide_value_names',
			[
				'label' => esc_html__( 'Hide Value Names?', 'littledino-core' ),
				'type' => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
			]
		);

		$this->add_control(
			'hide_separating',
			[
				'label' => esc_html__( 'Hide Separating Points?', 'littledino-core' ),
				'type' => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default' => 'yes',
			]
		);

		$this->end_controls_section();


		/*-----------------------------------------------------------------------------------*/
		/*  STYLE -> REGION
		/*-----------------------------------------------------------------------------------*/

		$this->start_controls_section(
			'section_style_region',
			[
				'label' => esc_html__( 'Region', 'littledino-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'region_margin',
			[
				'label' => esc_html__( 'Margin', 'littledino-core' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'mobile_default' => [
					'top' => 2,
					'right' => 2,
					'bottom' => 2,
					'left' => 2,
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}} .countdown-section' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
					'{{WRAPPER}} .countdown-section:before, {{WRAPPER}} .countdown-section:after' => 'right: calc( ({{LEFT}}{{UNIT}} + {{RIGHT}}{{UNIT}}) / -2)',
				],
			]
		);
		$this->add_responsive_control(
			'region_padding',
			[
				'label' => esc_html__( 'Padding', 'littledino-core' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default' => [
					'top' => 20,
					'right' => 27,
					'bottom' => 16,
					'left' => 27,
					'unit' => 'px',
				],
				'mobile_default' => [
					'top' => 15,
					'right' => 8,
					'bottom' => 15,
					'left' => 8,
					'unit'  => 'px',
				],
				'selectors' => [
					'{{WRAPPER}} .countdown-section' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'region_',
				'separator' => 'before',
				'fields_options' => [
					'border' => [ 'default' => 'dashed' ],
					'width' => [
						'default' => [
							'top' => 2,
							'right' => 2,
							'bottom' => 2,
							'left' => 2,
						],
					],
					'color' => [ 'default' => $theme_color ],
				],
				'selector' => '{{WRAPPER}} .countdown-section',
			]
		);

		$this->add_responsive_control(
			'region_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'littledino-core' ),
				'type' => Controls_Manager::DIMENSIONS,
				'separator' => 'after',
				'size_units' => [ 'px', '%', 'em' ],
				'default' => [
					'top' => 30,
					'right' => 30,
					'bottom' => 30,
					'left' => 30,
					'unit'  => 'px',
				],
				'mobile_default' => [
					'top' => 15,
					'right' => 15,
					'bottom' => 15,
					'left' => 15,
					'unit'  => 'px',
				],
				'selectors' => [
					'{{WRAPPER}} .countdown-section' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();


		/*-----------------------------------------------------------------------------------*/
		/*  STYLE -> DIGIT
		/*-----------------------------------------------------------------------------------*/

		$this->start_controls_section(
			'section_style_digit',
			[
				'label' => esc_html__( 'Digit', 'littledino-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'digits_color',
			[
				'label' => esc_html__( 'Color', 'littledino-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => $second_color,
				'selectors' => [
					'{{WRAPPER}} .countdown-amount' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'digits_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'littledino-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .countdown-amount' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'digits_margin',
			[
				'label' => esc_html__( 'Margin', 'littledino-core' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'default' => [
					'bottom' => -2,
					'unit'  => 'px',
				],
				'selectors' => [
					'{{WRAPPER}} .countdown-amount' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'digits_padding',
			[
				'label' => esc_html__( 'Padding', 'littledino-core' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .countdown-amount' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'digits_',
				'separator' => 'before',
				'selector' => '{{WRAPPER}} .countdown-amount',
			]
		);

		$this->add_responsive_control(
			'digits_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'littledino-core' ),
				'type' => Controls_Manager::DIMENSIONS,
				'separator' => 'after',
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .countdown-amount' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],

			]
		);


		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'label' => esc_html__( 'Typography', 'littledino-core' ),
				'name' => 'digit_',
				'selector' => '{{WRAPPER}} .countdown-amount',
			]
		);

		$this->end_controls_section();


		/*-----------------------------------------------------------------------------------*/
		/*  STYLE -> PERIOD NAME
		/*-----------------------------------------------------------------------------------*/

		$this->start_controls_section(
			'section_style_period',
			[
				'label' => esc_html__( 'Period Name', 'littledino-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'period_color',
			[
				'label' => esc_html__( 'Color', 'littledino-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => $h_font_color,
				'selectors' => [
					'{{WRAPPER}} .countdown-period' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'label' => esc_html__( 'Typography', 'littledino-core' ),
				'name' => 'custom_fonts_text',
				'selector' => '{{WRAPPER}} .countdown-period',
			]
		);

		$this->end_controls_section();


		/*-----------------------------------------------------------------------------------*/
		/*  STYLE -> SEPARATION
		/*-----------------------------------------------------------------------------------*/

		$this->start_controls_section(
			'section_style_separation',
			[
				'label' => esc_html__( 'Separation', 'littledino-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [ 'hide_separating!' => 'yes' ],
			]
		);

		$this->add_control(
			'separating_color',
			[
				'label' => esc_html__( 'Points Color', 'littledino-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => $second_color,
				'selectors' => [
					'{{WRAPPER}} .countdown-section:before, {{WRAPPER}} .countdown-section:after' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();
	}

	protected function render() {
		$atts = $this->get_settings_for_display();

		$countdown = new WglCountDown();
		echo $countdown->render($this, $atts);
	}

	public function wpml_support_module() {
        add_filter( 'wpml_elementor_widgets_to_translate',  [$this, 'wpml_widgets_to_translate_filter']);
    }

    public function wpml_widgets_to_translate_filter( $widgets ){
        return \WglAddons\Includes\Wgl_WPML_Settings::get_translate(
            $this, $widgets
        );
    }
}