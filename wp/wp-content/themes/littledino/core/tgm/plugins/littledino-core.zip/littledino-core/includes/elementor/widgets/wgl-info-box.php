<?php

namespace WglAddons\Widgets;

if ( ! defined( 'ABSPATH' ) ) exit; // Abort, if accessed directly.

use WglAddons\Includes\Wgl_Icons;
use WglAddons\Includes\Wgl_Carousel_Settings;
use WglAddons\Templates\WglInfoBoxes;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Core\Schemes\Color;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Group_Control_Background;
use Elementor\Utils;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Css_Filter;


class Wgl_Info_Box extends Widget_Base {

    public function get_name() {
        return 'wgl-info-box';
    }

    public function get_title() {
        return esc_html__( 'WGL Info Box', 'littledino-core' );
    }

    public function get_icon() {
        return 'wgl-info-box';
    }

    public function get_categories() {
        return [ 'wgl-extensions' ];
    }

    protected function register_controls() {
        $theme_color = esc_attr(\LittleDino_Theme_Helper::get_option('theme-custom-color'));
        $main_font_color = esc_attr(\LittleDino_Theme_Helper::get_option('main-font')['color']);
        $header_font_color = esc_attr(\LittleDino_Theme_Helper::get_option('header-font')['color']);


        /*-----------------------------------------------------------------------------------*/
        /*  CONTENT -> GENERAL
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'section_content_general',
            [ 'label' => esc_html__( 'General', 'littledino-core' ) ]
        );

        $this->add_control(
            'ib_alignment',
            [
                'label' => esc_html__( 'Alignment', 'littledino-core' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => esc_html__( 'Left', 'littledino-core' ),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__( 'Center', 'littledino-core' ),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__( 'Right', 'littledino-core' ),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'default' => 'left',
                'toggle' => true,
                'prefix_class' => 'ib-align-',
                'selectors' => [
                    '{{WRAPPER}} .wgl-infobox_wrapper' => 'text-align: {{VALUE}};',
                    '{{WRAPPER}} .wgl-infobox_wrapper .wgl-infobox_bg_title' => 'text-align: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'hover_animation',
            [
                'label' => esc_html__( 'Lift up the item on hover?', 'littledino-core' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'On', 'littledino-core' ),
                'label_off' => esc_html__( 'Off', 'littledino-core' ),
                'return_value' => 'yes',
                'prefix_class' => 'wgl-hover_shift-',
            ]
        );

        $this->add_control(
            'inner_dashes_switch',
            [
                'label' => esc_html__( 'Enable Inner Dashed Border', 'littledino-core' ),
                'type' => Controls_Manager::SWITCHER,
                'return_value' => 'yes',
            ]
        );

        $this->end_controls_section();


        /*-----------------------------------------------------------------------------------*/
        /*  CONTENT -> INFO BOX ICON/IMAGE
        /*-----------------------------------------------------------------------------------*/

        $output['view'] = [
            'label' => esc_html__( 'View', 'littledino-core' ),
            'type' => Controls_Manager::SELECT,
            'condition' => [ 'icon_type' => 'font' ],
            'options' => [
                'default' => esc_html__( 'Default', 'littledino-core' ),
                'stacked' => esc_html__( 'Stacked', 'littledino-core' ),
                'framed' => esc_html__( 'Framed', 'littledino-core' ),
            ],
            'default' => 'default',
            'prefix_class' => 'elementor-view-',
        ];

        $output['shape'] = [
            'label' => esc_html__( 'Shape', 'littledino-core' ),
            'type' => Controls_Manager::SELECT,
            'condition' => [
                'icon_type' => 'font',
                'view!' => 'default',
            ],
            'options' => [
                'circle' => esc_html__( 'Circle', 'littledino-core' ),
                'square' => esc_html__( 'Square', 'littledino-core' ),
            ],
            'default' => 'circle',
            'prefix_class' => 'elementor-shape-',
        ];

        $output['link_t'] = [
            'label' => esc_html__( 'Link', 'littledino-core' ),
            'type' => Controls_Manager::URL,
            'condition' => [ 'icon_type!' => '' ],
            'placeholder' => esc_attr__( 'https://your-link.com', 'littledino-core' ),
            'separator' => 'before',
        ];

        $output['position'] = [
            'label' => esc_html__( 'Position', 'littledino-core' ),
            'type' => 'wgl-radio-image',
            'condition' => [ 'icon_type!' => '' ],
            'prefix_class' => 'elementor-position-',
            'options' => [
                'top' => [
                    'title'=> esc_html__( 'Top', 'littledino-core' ),
                    'image' => WGL_ELEMENTOR_ADDONS_URL . 'assets/img/wgl_composer_addon/icons/style_def.png',
                ],
                'left' => [
                    'title'=> esc_html__( 'Left', 'littledino-core' ),
                    'image' => WGL_ELEMENTOR_ADDONS_URL . 'assets/img/wgl_composer_addon/icons/style_left.png',
                ],
                'right' => [
                    'title'=> esc_html__( 'Right', 'littledino-core' ),
                    'image' => WGL_ELEMENTOR_ADDONS_URL . 'assets/img/wgl_composer_addon/icons/style_right.png',
                ],
            ],
            'default' => 'top',
        ];

        Wgl_Icons::init(
            $this,
            [
                'output' => $output,
                'section' => true,
            ]
        );


        /*-----------------------------------------------------------------------------------*/
        /*  CONTENT -> CONTENT
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'section_content_content',
            [ 'label' => esc_html__( 'Content', 'littledino-core' ) ]
        );

        $this->add_control(
            'ib_title',
            [
                'label' => esc_html__( 'Title', 'littledino-core' ),
                'type' => Controls_Manager::TEXT,
                'placeholder' => esc_attr__( 'Type your title', 'littledino-core' ),
                'default' => esc_html__( 'This is heading​', 'littledino-core' ),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'add_bg_title',
            [
                'label' => esc_html__( 'Add Shadow Text Behind Title', 'littledino-core' ),
                'type' => Controls_Manager::SWITCHER,
                'return_value' => 'yes',
            ]
        );
        $this->add_control(
            'ib_bg_title',
            [
                'label' => esc_html__( 'Background Title', 'littledino-core' ),
                'type' => Controls_Manager::TEXT,
                'condition' => [ 'add_bg_title' => 'yes' ],
                'label_block' => true,
                'default' => esc_html__( 'This is the heading​', 'littledino-core' ),
            ]
        );

        $this->add_control(
            'ib_content',
            [
                'label' => esc_html__( 'Content', 'littledino-core' ),
                'type' => Controls_Manager::WYSIWYG,
                'placeholder' => esc_attr__( 'Description Text', 'littledino-core' ),
                'label_block' => true,
                'default' => esc_html__( 'Click edit button to change this text. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut elit tellus, luctus nec ullamcorper mattis, pulvinar dapibus leo.', 'littledino-core' ),
            ]
        );

        $this->end_controls_section();


        /*-----------------------------------------------------------------------------------*/
        /*  CONTENT -> LINK
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'section_content_link',
            [ 'label' => esc_html__( 'Link', 'littledino-core' ) ]
        );

        $this->add_control(
            'ib_link_switch',
            [
                'label' => esc_html__( 'Full-Module Button', 'littledino-core' ),
                'type' => Controls_Manager::SWITCHER,
                'condition' => [ 'add_read_more!' => 'yes' ],
                'description' => esc_html__( 'Clickable at any place', 'littledino-core' ),
                'label_on' => esc_html__( 'On', 'littledino-core' ),
                'label_off' => esc_html__( 'Off', 'littledino-core' ),
                'return_value' => 'yes',
            ]
        );

        $this->add_control(
            'ib_link',
            [
                'label' => esc_html__( 'Link', 'littledino-core' ),
                'type' => Controls_Manager::URL,
                'label_block' => true,
                'condition' => [ 'ib_link_switch' => 'yes' ],
            ]
        );

        $this->add_control(
            'add_read_more',
            [
                'label' => esc_html__( 'Add \'Read More\' Button', 'littledino-core' ),
                'type' => Controls_Manager::SWITCHER,
                'condition' => [ 'ib_link_switch!' => 'yes' ],
                'return_value' => 'yes',
            ]
        );

        $this->add_control(
            'read_more_text',
            [
                'label' => esc_html__( 'Button Text', 'littledino-core' ),
                'type' => Controls_Manager::TEXT,
                'condition' => [ 'add_read_more' => 'yes' ],
                'label_block' => true,
                'default' =>  esc_html__( 'Read More', 'littledino-core' ),
            ]
        );

        $this->add_control(
            'link',
            [
                'label' => esc_html__( 'Button Link', 'littledino-core' ),
                'type' => Controls_Manager::URL,
                'label_block' => true,
                'condition' => [ 'add_read_more' => 'yes' ],
            ]
        );

        $this->add_control(
            'hr_link',
            [ 'type' => Controls_Manager::DIVIDER ]
        );

        $this->add_control(
            'read_more_icon_sticky',
            [
                'label' => esc_html__( 'Stick the button','littledino-core' ),
                'type' => Controls_Manager::SWITCHER,
                'condition' => [ 'add_read_more' => 'yes' ],
                'description' => esc_html__( 'Attach to the bottom corner.', 'littledino' ),
                'label_on' => esc_html__( 'On', 'littledino-core' ),
                'label_off' => esc_html__( 'Off', 'littledino-core' ),
                'return_value' => 'yes',
            ]
        );

        $this->add_control(
            'read_more_icon_sticky_pos',
            [
                'label' => esc_html__( 'Read More Position', 'littledino-core' ),
                'type' => Controls_Manager::SELECT,
                'condition' => [
                    'add_read_more' => 'yes',
                    'read_more_icon_sticky' => 'yes',
                ],
                'options' => [
                    'right' => esc_html__( 'Right', 'littledino-core' ),
                    'left' => esc_html__( 'Left', 'littledino-core' ),
                ],
                'default' => 'right',
            ]
        );

        $this->add_control(
            'read_more_icon_switch',
            [
                'label' => esc_html__( 'Add Icon','littledino-core' ),
                'type' => Controls_Manager::SWITCHER,
                'condition' => [ 'add_read_more' => 'yes' ],
                'separator' => 'before',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'icon_read_more_pack',
            [
                'label' => esc_html__( 'Icon Pack', 'littledino-core' ),
                'type' => Controls_Manager::SELECT,
                'condition' => [
                    'add_read_more' => 'yes',
                    'read_more_icon_switch' => 'yes',
                ],
                'options' => [
                    'flaticon' => esc_html__( 'Flaticon', 'littledino-core' ),
                    'fontawesome' => esc_html__( 'Fontawesome', 'littledino-core' ),
                ],
                'default' => 'flaticon',
            ]
        );

        $this->add_control(
            'read_more_icon_flaticon',
            [
                'label' => esc_html__( 'Icon', 'littledino-core' ),
                'type' => 'wgl-icon',
                'condition' => [
                    'add_read_more' => 'yes',
                    'read_more_icon_switch' => 'yes',
                    'icon_read_more_pack' => 'flaticon',
                ],
                'label_block' => true,
                'description' => esc_html__( 'Select icon from Flaticon library.', 'littledino-core' ),
            ]
        );

        $this->add_control(
            'read_more_icon_fontawesome',
            [
                'label' => esc_html__( 'Icon', 'littledino-core' ),
                'type' => Controls_Manager::ICON,
                'condition' => [
                    'add_read_more' => 'yes',
                    'read_more_icon_switch' => 'yes',
                    'icon_read_more_pack' => 'fontawesome',
                ],
                'label_block' => true,
                'description' => esc_html__( 'Select icon from Fontawesome library.', 'littledino-core' ),
            ]
        );

        $this->add_control(
            'read_more_icon_align',
            [
                'label' => esc_html__( 'Icon Position', 'littledino-core' ),
                'type' => Controls_Manager::SELECT,
                'condition' => [
                    'add_read_more' => 'yes',
                    'read_more_icon_switch' => 'yes',
                ],
                'options' => [
                    'left' => esc_html__( 'Before', 'littledino-core' ),
                    'right' => esc_html__( 'After', 'littledino-core' ),
                ],
                'default' => 'right',
            ]
        );

        $this->start_controls_tabs(
            'tabs_rm_icon',
            [ 'condition' => [ 'add_read_more' => 'yes' ] ]
        );

        $this->start_controls_tab(
            'icon_options_idle',
            [ 'label' => esc_html__( 'Idle', 'littledino-core' ) ]
        );

        $this->add_control(
            'rm_icon_size_idle',
            [
                'label' => esc_html__( 'Icon Font Size', 'littledino-core' ),
                'type' => Controls_Manager::SLIDER,
                'condition' => [ 'read_more_icon_switch' => 'yes' ],
                'size_units' => [ 'px', 'em', 'rem' ],
                'range' => [
                    'px' => [ 'min' => 5, 'max' => 100 ],
                    'em' => [ 'max' => 5, 'step' => 0.1 ],
                ],
                'default' => [ 'size' => 1, 'unit' => 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-infobox_button i' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'rm_icon_spacing_idle',
            [
                'label' => esc_html__( 'Icon Spacing', 'littledino-core' ),
                'type' => Controls_Manager::SLIDER,
                'condition' => [ 'read_more_icon_switch' => 'yes' ],
                'range' => [
                    'px' => [ 'min' => 0, 'max' => 100 ],
                ],
                'default' => [ 'size' => 10, 'unit' => 'px' ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-infobox_button.icon-position-right i' => 'margin-left: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .wgl-infobox_button.icon-position-left i' => 'margin-right: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'rm_icon_rotation_idle',
            [
                'label' => esc_html__( 'Icon Rotation', 'littledino-core' ),
                'type' => Controls_Manager::SLIDER,
                'condition' => [ 'read_more_icon_switch' => 'yes' ],
                'size_units' => [ 'deg', 'turn' ],
                'range' => [
                    'deg' => [ 'min' => -360, 'max' => 360 ],
                    'turn' => [ 'min' => -1, 'max' => 1, 'step' => 0.1 ]
                ],
                'default' => [ 'size' => 0, 'unit' => 'deg' ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-infobox_button i' => 'transform: rotate({{SIZE}}{{UNIT}});',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'icon_options_hover',
            [ 'label' => esc_html__( 'Hover', 'littledino-core' ) ]
        );

        $this->add_control(
            'rm_icon_size_hover',
            [
                'label' => esc_html__( 'Icon Font Size', 'littledino-core' ),
                'type' => Controls_Manager::SLIDER,
                'condition' => [ 'read_more_icon_switch' => 'yes' ],
                'size_units' => [ 'px', 'em', 'rem' ],
                'range' => [
                    'px' => [ 'min' => 5, 'max' => 100 ],
                    'em' => [ 'max' => 5, 'step' => 0.1 ],
                ],
                'default' => [ 'size' => 1, 'unit' => 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-infobox_button:hover i' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'rm_icon_spacing_hover',
            [
                'label' => esc_html__( 'Icon Spacing', 'littledino-core' ),
                'type' => Controls_Manager::SLIDER,
                'condition' => [ 'read_more_icon_switch' => 'yes' ],
                'range' => [
                    'px' => [ 'min' => 0, 'max' => 100 ],
                ],
                'default' => [ 'size' => 10, 'unit' => 'px' ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-infobox_button:hover.icon-position-right i' => 'margin-left: {{SIZE}}{{UNIT}};',
                    '{{WRAPPER}} .wgl-infobox_button:hover.icon-position-left i' => 'margin-right: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'rm_icon_rotation_hover',
            [
                'label' => esc_html__( 'Icon Rotation', 'littledino-core' ),
                'type' => Controls_Manager::SLIDER,
                'condition' => [ 'read_more_icon_switch' => 'yes' ],
                'size_units' => [ 'deg', 'turn' ],
                'range' => [
                    'deg' => [ 'min' => -360, 'max' => 360 ],
                    'turn' => [ 'min' => -1, 'max' => 1, 'step' => 0.1 ]
                ],
                'default' => [ 'size' => 0, 'unit' => 'deg' ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-infobox_button:hover i' => 'transform: rotate({{SIZE}}{{UNIT}});',
                ],
            ]
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();


        /*-----------------------------------------------------------------------------------*/
        /* STYLE -> ICON
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'section_style_icon',
            [
                'label' => esc_html__( 'Icon', 'littledino-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [ 'icon_type' => 'font' ],
            ]
        );

        $this->start_controls_tabs( 'icon_colors' );

        $this->start_controls_tab(
            'icon_colors_idle',
            [ 'label' => esc_html__( 'Idle', 'littledino-core' ) ]
        );

        $this->add_control(
            'ib_icon_color_idle',
            [
                'label' => esc_html__( 'Icon Color', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}}.elementor-view-stacked .wgl-icon' => 'color: {{VALUE}};',
                    '{{WRAPPER}}.elementor-view-framed .wgl-icon, {{WRAPPER}}.elementor-view-default .wgl-icon' => 'color: {{VALUE}}; border-color: {{VALUE}}; fill: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'ib_icon_bg_idle',
            [
                'label' => esc_html__( 'Background Color', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'condition' => [ 'view!' => 'default' ],
                'selectors' => [
                    '{{WRAPPER}}.elementor-view-framed .wgl-icon' => 'background-color: {{VALUE}};',
                    '{{WRAPPER}}.elementor-view-stacked .wgl-icon' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'icon_colors_hover',
            [ 'label' => esc_html__( 'Hover', 'littledino-core' ) ]
        );

        $this->add_control(
            'ib_icon_color_hover',
            [
                'label' => esc_html__( 'Icon Color', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}}.elementor-view-stacked:hover .wgl-icon' => 'color: {{VALUE}};',
                    '{{WRAPPER}}.elementor-view-framed:hover .wgl-icon, {{WRAPPER}}.elementor-view-default .wgl-icon:hover' => 'color: {{VALUE}}; border-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'ib_icon_bg_hover',
            [
                'label' => esc_html__( 'Background Color', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'condition' => [ 'view!' => 'default' ],
                'selectors' => [
                    '{{WRAPPER}}.elementor-view-framed:hover .wgl-icon' => 'background-color: {{VALUE}};',
                    '{{WRAPPER}}.elementor-view-stacked:hover .wgl-icon' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'hover_animation_icon',
            [
                'label' => esc_html__( 'Hover Animation', 'littledino-core' ),
                'type' => Controls_Manager::HOVER_ANIMATION,
            ]
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();

        $this->add_control(
            'hr_icon_style',
            [ 'type' => Controls_Manager::DIVIDER ]
        );

        $this->add_responsive_control(
            'icon_space',
            [
                'label' => esc_html__( 'Margin', 'littledino-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .elementor-icon-box-icon' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'icon_size',
            [
                'label' => esc_html__( 'Size', 'littledino-core' ),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [ 'min' => 6, 'max' => 300 ],
                ],
                'default'   => [ 'size' => 60, 'unit' => 'px' ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-icon' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'icon_padding',
            [
                'label' => esc_html__( 'Padding', 'littledino-core' ),
                'type' => Controls_Manager::SLIDER,
                'condition' => [ 'view!' => 'default' ],
                'size_units' => [ 'px', 'em' ],
                'range' => [
                    'px' => [ 'min' => 0, 'max' => 50 ],
                    'em' => [ 'min' => 0, 'max' => 5, 'step' => 0.1 ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-icon' => 'padding: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'rotate',
            [
                'label' => esc_html__( 'Rotation', 'littledino-core' ),
                'type' => Controls_Manager::SLIDER,
                'default' => [ 'size' => 0, 'unit' => 'deg' ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-icon' => 'transform: rotate({{SIZE}}{{UNIT}});',
                ],
            ]
        );

        $this->add_control(
            'border_width',
            [
                'label' => esc_html__( 'Border Width', 'littledino-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'condition' => [ 'view' => 'framed' ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-icon' => 'border-width: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'border_radius',
            [
                'label' => esc_html__( 'Border Radius', 'littledino-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'condition' => [ 'view!' => 'default' ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-icon' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();


        /*-----------------------------------------------------------------------------------*/
        /*  STYLE -> IMAGE
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'section_style_image',
            [
                'label' => esc_html__( 'Image', 'littledino-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [ 'icon_type' => 'image' ]
            ]
        );

        $this->add_responsive_control(
            'image_space',
            [
                'label' => esc_html__( 'Margin', 'littledino-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'default' => [ 'isLinked' => false ],
                'selectors' => [
                    '{{WRAPPER}} .elementor-image-box-img' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'image_size',
            [
                'label' => esc_html__( 'Width', 'littledino-core' ),
                'type' => Controls_Manager::SLIDER,
                'tablet_default' => [ 'unit' => '%' ],
                'mobile_default' => [ 'unit' => '%' ],
                'size_units' => [ 'px', '%' ],
                'range' => [
                    'px' => [ 'min' => 5, 'max' => 1170 ],
                    '%' => [ 'min' => 5, 'max' => 100 ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .elementor-image-box-img' => 'width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'hover_animation_image',
            [
                'label' => esc_html__( 'Hover Animation', 'littledino-core' ),
                'type' => Controls_Manager::HOVER_ANIMATION,
            ]
        );

        $this->start_controls_tabs( 'image_effects' );

        $this->start_controls_tab(
            'image_idle',
            [ 'label' => esc_html__( 'Idle', 'littledino-core' ) ]
        );

        $this->add_group_control(
            Group_Control_Css_Filter::get_type(),
            [
                'name' => 'css_filters',
                'selector' => '{{WRAPPER}} .wgl-image-box_img img',
            ]
        );

        $this->add_control(
            'image_opacity',
            [
                'label' => esc_html__( 'Opacity', 'littledino-core' ),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'max' => 1,
                        'min' => 0.10,
                        'step' => 0.01,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-image-box_img img' => 'opacity: {{SIZE}};',
                ],
            ]
        );

        $this->add_control(
            'bg_hover_transition',
            [
                'label' => esc_html__( 'Transition Duration', 'littledino-core' ),
                'type' => Controls_Manager::SLIDER,
                'default' => [ 'size' => 0.3 ],
                'range' => [
                    'px' => [
                        'max' => 3,
                        'step' => 0.1,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-image-box_img img' => 'transition-duration: {{SIZE}}s',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'image_hover',
            [ 'label' => esc_html__( 'Hover', 'littledino-core' ) ]
        );

        $this->add_group_control(
            Group_Control_Css_Filter::get_type(),
            [
                'name' => 'css_filters_hover',
                'selector' => '{{WRAPPER}}:hover .wgl-image-box_img img',
            ]
        );

        $this->add_control(
            'image_opacity_hover',
            [
                'label' => esc_html__( 'Opacity', 'littledino-core' ),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'max' => 1,
                        'min' => 0.10,
                        'step' => 0.01,
                    ],
                ],
                'selectors' => [
                    '{{WRAPPER}}:hover .wgl-image-box_img img' => 'opacity: {{SIZE}};',
                ],
            ]
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();


        /*-----------------------------------------------------------------------------------*/
        /*  STYLE -> TITLE
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'section_style_title',
            [
                'label' => esc_html__( 'Title', 'littledino-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'title_tag',
            [
                'label' => esc_html__( 'HTML Tag', 'littledino-core' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'h1' => '‹h1›',
                    'h2' => '‹h2›',
                    'h3' => '‹h3›',
                    'h4' => '‹h4›',
                    'h5' => '‹h5›',
                    'h6' => '‹h6›',
                    'div' => '‹div›',
                    'span' => '‹span›',
                ],
                'default' => 'h3',
            ]
        );

        $this->add_responsive_control(
            'title_offset',
            [
                'label' => esc_html__( 'Margin', 'littledino-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'default' => [
                    'top' => '',
                    'right' => '',
                    'bottom' => 10,
                    'left' => '',
                    'unit'  => 'px',
                    'isLinked'  => false,
                ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-infobox_title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'custom_fonts_title',
                'selector' => '{{WRAPPER}} .wgl-infobox_title',
            ]
        );

        $this->start_controls_tabs( 'title_color_tab' );

        $this->start_controls_tab(
            'custom_title_color_idle',
            [ 'label' => esc_html__( 'Idle' , 'littledino-core' ) ]
        );

        $this->add_control(
            'title_color',
            [
                'label' => esc_html__( 'Color', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'default' => '#232323',
                'selectors' => [
                    '{{WRAPPER}} .wgl-infobox_title' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'custom_title_color_hover',
            [ 'label' => esc_html__( 'Hover' , 'littledino-core' ) ]
        );

        $this->add_control(
            'title_color_hover',
            [
                'label' => esc_html__( 'Color', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'default' => $theme_color,
                'selectors' => [
                    '{{WRAPPER}}:hover .wgl-infobox_title' => 'color: {{VALUE}};',
                    '{{WRAPPER}}:hover .wgl-infobox_title a' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();


        /*-----------------------------------------------------------------------------------*/
        /*  STYLE -> SHADOW BEHIND TITLE
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'section_style_bg_title',
            [
                'label' => esc_html__( 'Shadow Behind Title', 'littledino-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [ 'add_bg_title' => 'yes' ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'custom_fonts_bg_title',
                'selector' => '{{WRAPPER}} .wgl-infobox_bg_title',
            ]
        );

        $this->start_controls_tabs( 'title_bg_color_tab' );

        $this->start_controls_tab(
            'custom_bg_title_color_idle',
            [ 'label' => esc_html__( 'Idle' , 'littledino-core' ) ]
        );

        $this->add_control(
            'bg_title_color',
            [
                'label' => esc_html__( 'Color', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'default' => '#f7f7f7',
                'selectors' => [
                    '{{WRAPPER}} .wgl-infobox_bg_title' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'custom_bg_title_color_hover',
            [ 'label' => esc_html__( 'Hover' , 'littledino-core' ) ]
        );

        $this->add_control(
            'title_bg_color_hover',
            [
                'label' => esc_html__( 'Color', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'default' => '#f7f7f7',
                'selectors' => [
                    '{{WRAPPER}}:hover .wgl-infobox_bg_title' => 'color: {{VALUE}};'
                ],
            ]
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();


        /*-----------------------------------------------------------------------------------*/
        /*  STYLE -> CONTENT
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'section_style_content',
            [
                'label' => esc_html__( 'Content', 'littledino-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'content_tag',
            [
                'label' => esc_html__( 'HTML Tag', 'littledino-core' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'h1' => '‹h1›',
                    'h2' => '‹h2›',
                    'h3' => '‹h3›',
                    'h4' => '‹h4›',
                    'h5' => '‹h5›',
                    'h6' => '‹h6›',
                    'div' => '‹div›',
                    'span' => '‹span›',
                ],
                'default' => 'div',
            ]
        );

        $this->add_responsive_control(
            'content_offset',
            [
                'label' => esc_html__( 'Margin', 'littledino-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'default' => [
                    'top' => 0,
                    'right' => 0,
                    'bottom'=> 30,
                    'left' => 0,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-infobox_content' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'content_padding',
            [
                'label' => esc_html__( 'Padding', 'littledino-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-infobox_content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'custom_content_mask_color',
                'label' => esc_html__( 'Background', 'littledino-core' ),
                'types' => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .wgl-infobox_content',
                'condition' => [ 'custom_bg'   => 'custom' ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'custom_fonts_content',
                'selector' => '{{WRAPPER}} .wgl-infobox_content',
            ]
        );

        $this->start_controls_tabs( 'content_color_tab' );

        $this->start_controls_tab(
            'tab_content_color_idle',
            [ 'label' => esc_html__( 'Idle' , 'littledino-core' ) ]
        );

        $this->add_control(
            'ib_content_colo_idle',
            [
                'label' => esc_html__( 'Color', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'default' => $main_font_color,
                'selectors' => [
                    '{{WRAPPER}} .wgl-infobox_content' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'tab_content_color_hover',
            [ 'label' => esc_html__( 'Hover' , 'littledino-core' ) ]
        );

        $this->add_control(
            'ib_content_color_hover',
            [
                'label' => esc_html__( 'Color', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'default' => $main_font_color,
                'selectors' => [
                    '{{WRAPPER}}:hover .wgl-infobox_content' => 'color: {{VALUE}};'
                ],
            ]
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();


        /*-----------------------------------------------------------------------------------*/
        /*  STYLE -> BUTTON
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'section_style_button',
            [
                'label' => esc_html__( 'Button', 'littledino-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [ 'add_read_more!' => '' ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'custom_fonts_button',
                'fields_options' => [
                    'typography' => ['default' => 'yes'],
                    'font_family' => ['default' => \Wgl_Addons_Elementor::$typography_1['font_family']],
                    'font_weight' => ['default' => \Wgl_Addons_Elementor::$typography_1['font_weight']],
                ],
                'selector' => '{{WRAPPER}} .wgl-infobox_button',
            ]
        );

        $this->add_responsive_control(
            'ib_button_padding',
            [
                'label' => esc_html__( 'Padding', 'littledino-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-infobox_button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'ib_button_border',
            [
                'label' => esc_html__( 'Border Radius', 'littledino-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-infobox_button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],

            ]
        );

        $this->start_controls_tabs( 'tabs_button_colors' );

        $this->start_controls_tab(
            'tab_button_color_idle',
            [ 'label' => esc_html__( 'Idle' , 'littledino-core' ) ]
        );

        $this->add_control(
            'ib_button_bg_idle',
            [
                'label' => esc_html__( 'Background Color', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .wgl-infobox_button' => 'background: {{VALUE}};',
                ],
            ]
        );


        $this->add_control(
            'ib_button_color_idle',
            [
                'label' => esc_html__( 'Color', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'default' => $theme_color,
                'selectors' => [
                    '{{WRAPPER}} .wgl-infobox_button' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'button_border',
                'label' => esc_html__( 'Border Type', 'littledino-core' ),
                'selector' => '{{WRAPPER}} .wgl-infobox_button',
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'button_shadow',
                'selectors' => '{{WRAPPER}} .wgl-infobox_button',
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'tab_button_color_hover',
            [ 'label' => esc_html__( 'Hover' , 'littledino-core' ) ]
        );

        $this->add_control(
            'ib_button_bg_hover',
            [
                'label' => esc_html__( 'Background Color', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .wgl-infobox_button:hover' => 'background: {{VALUE}};'
                ],
            ]
        );

        $this->add_control(
            'ib_button_color_hover',
            [
                'label' => esc_html__( 'Color', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'default' => $theme_color,
                'selectors' => [
                    '{{WRAPPER}} .wgl-infobox_button:hover' => 'color: {{VALUE}};'
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'button_border_hover',
                'label' => esc_html__( 'Border Type', 'littledino-core' ),
                'selector' => '{{WRAPPER}} .wgl-infobox_button:hover',
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'button_shadow_hover',
                'selector' => '{{WRAPPER}} .wgl-infobox_button:hover',
            ]
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();

        $this->add_control(
            'h_ib_b_dashes',
            [
                'label' => esc_html__( 'Inner Dashes', 'littledino-core' ),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'ib_b_dashes_switch',
            [
                'label' => esc_html__( 'Use inner dashed border?', 'littledino-core' ),
                'type' => Controls_Manager::SWITCHER,
                'return_value' => 'yes',
            ]
        );

        $this->add_control(
            'ib_b_dashes_anim_switch',
            [
                'label' => esc_html__( 'Use running animation on Hover state?', 'littledino-core' ),
                'type' => Controls_Manager::SWITCHER,
                'condition' => [ 'ib_b_dashes_switch' => 'yes' ],
            ]
        );

        $this->add_control(
            'ib_b_dashes_color',
            [
                'label' => esc_html__( 'Color', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'condition' => [ 'ib_b_dashes_switch' => 'yes' ],
                'default' => $theme_color,
                'selectors' => [
                    '{{WRAPPER}} .wgl-infobox_button .btn-dashes' => 'stroke: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'ib_b_dashes_disatance',
            [
                'label' => esc_html__( 'Offset', 'littledino-core' ),
                'type' => Controls_Manager::SLIDER,
                'condition' => [ 'ib_b_dashes_switch' => 'yes' ],
                'label_block' => true,
                'range' => [ 'px' => [ 'max' => 35 ] ],
                'default' => [ 'size' => 3, 'unit' => 'px' ],
            ]
        );

        $this->add_control(
            'ib_b_dashes_radius',
            [
                'label' => esc_html__( 'Border Radius', 'littledino-core' ),
                'type' => Controls_Manager::SLIDER,
                'condition' => [ 'ib_b_dashes_switch' => 'yes' ],
                'label_block' => true,
                'size_units' => [ 'px', '%' ],
                'range' => [
                    'px' => [ 'max' => 50 ],
                    '%' => [ 'max' => 50 ],
                ],
                'default' => [ 'size' => 5, 'unit' => 'px' ],
            ]
        );

        $this->end_controls_section();


        /*-----------------------------------------------------------------------------------*/
        /*  STYLE -> INNER DASHES
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'section_style_dashes',
            [
                'label' => esc_html__( 'Inner Dashes', 'littledino-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [ 'inner_dashes_switch' => 'yes' ],
            ]
        );

        $this->start_controls_tabs( 'tabs_dashes_colors' );

        $this->start_controls_tab(
            'tab_dashes_colors_idle',
            [ 'label' => esc_html__( 'Idle', 'littledino-core' ) ]
        );

        $this->add_control(
            'dashes_color_idle',
            [
                'label' => esc_html__( 'Color', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .inner-dashed-border' => 'stroke: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'tab_dashes_colors_hover',
            [ 'label' => esc_html__( 'Hover', 'littledino-core' ) ]
        );

        $this->add_control(
            'dashes_color_hover',
            [
                'label' => esc_html__( 'Color', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'default' => $theme_color,
                'selectors' => [
                    '{{WRAPPER}}:hover .inner-dashed-border' => 'stroke: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();

        $this->add_control(
            'dashes_disatance',
            [
                'label' => esc_html__( 'Offset', 'littledino-core' ),
                'type' => Controls_Manager::SLIDER,
                'label_block' => true,
                'separator' => 'before',
                'range' => [ 'px' => [ 'max' => 40 ] ],
                'default' => [ 'size' => 5, 'unit' => 'px' ],
            ]
        );

        $this->add_control(
            'dashes_radius',
            [
                'label' => esc_html__( 'Border Radius', 'littledino-core' ),
                'type' => Controls_Manager::SLIDER,
                'label_block' => true,
                'size_units' => [ 'px', '%' ],
                'range' => [
                    'px' => [ 'max' => 50 ],
                    '%' => [ 'max' => 50 ],
                ],
                'default' => [ 'size' => 30, 'unit' => 'px' ],
            ]
        );

        $this->add_control(
            'dashes_anim_switch',
            [
                'label' => esc_html__( 'Use running animation on Hover state?', 'littledino-core' ),
                'type' => Controls_Manager::SWITCHER,
            ]
        );

        $this->end_controls_section();
    }

    protected function render() {

        $atts = $this->get_settings_for_display();

        $info_box = new WglInfoBoxes();
        echo $info_box->render($this, $atts);

    }

    public function wpml_support_module() {
        add_filter( 'wpml_elementor_widgets_to_translate',  [$this, 'wpml_widgets_to_translate_filter']);
    }

    public function wpml_widgets_to_translate_filter( $widgets ){
        return \WglAddons\Includes\Wgl_WPML_Settings::get_translate(
            $this, $widgets
        );
    }
}