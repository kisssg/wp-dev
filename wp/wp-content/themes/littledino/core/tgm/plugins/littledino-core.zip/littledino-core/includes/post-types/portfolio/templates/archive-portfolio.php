<?php
if (!class_exists('LittleDino_Theme_Helper')) {
    return;
}

/**
 * Template for Portfolio CPT archive page
 *
 * @package littledino-core\includes\post-types
 * @author WebGeniusLab <webgeniuslab@gmail.com>
 * @since 1.0.0
 * @version 1.0.5
 */

use WglAddons\Templates\WglPortfolio;

$tax_obj = get_queried_object();
$term_id = $tax_obj->term_id ?? '';

$taxonomies = [];

if ($term_id) {
    $taxonomies[] = $tax_obj->taxonomy . ': ' . $tax_obj->slug;
    $tax_description = $tax_obj->description;
}

$sb = LittleDino_Theme_Helper::render_sidebars('portfolio_list');
$row_class = $sb['row_class'] ?? '';
$column = $sb['column'] ?? '';
$container_class = $sb['container_class'] ?? '';

$defaults = array(
    'add_animation' => null,
    'navigation' => 'pagination',
    'nav_align' => 'center',
    'click_area' => 'single',
    'posts_per_row' => LittleDino_Theme_Helper::get_option('portfolio_list_columns'),
    'show_portfolio_title' => LittleDino_Theme_Helper::get_option('portfolio_list_show_title'),
    'show_content' => LittleDino_Theme_Helper::get_option('portfolio_list_show_content'),
    'show_meta_categories' => LittleDino_Theme_Helper::get_option('portfolio_list_show_cat'),
    'show_filter' => false,
    'crop_images' => 'yes',
    'items_load' => '4',
    'grid_gap' => '30px',
    'add_overlay' => 'true',
    'portfolio_layout' => 'masonry',
    'custom_overlay_color' => 'rgba(34,35,40,.7)',
    'number_of_posts' => '12',
    'order_by' => 'menu_order',
    'order' => 'ASC',
    'post_type' => 'portfolio',
    'taxonomies' => $taxonomies,
    'info_position' => 'inside_image',
    'image_anim' => 'bordered',
    'single_link_title' => 'yes',
    'gallery_mode' => false,

    'add_divider' => 'yes',
    'b_dashed_anim_switch' => 'yes',
    'b_dashed_color' => '#ffffff',
    'b_dashed_disatance' => '20px',

    'css' => '',
    'autoplay' => true,
    'autoplay_speed' => '5000',
    'multiple_items' => true,
    'use_pagination' => false,
    'view_style' => 'standard',

    'grid_gap' => '30px',
    'featured_render' => '',
    'icon_pack' => 'flaticon',
    'icon_flaticon' => 'flaticon-footprint-1',
    'dashes_offset' => ['size' => 35, 'unit' => 'px'],
    'dashes_anim_switch' => true,
);

// Render
get_header();
?>
<div class="wgl-container<?php echo apply_filters('littledino_container_class', $container_class); ?>">
<div class="row<?php echo apply_filters('littledino_row_class', $row_class); ?>">
    <div id='main-content' class="wgl_col-<?php echo apply_filters('littledino_column_class', $column); ?>">
        <?php
        if (!empty($term_id)) {
            echo '<div class="portfolio_archive-cat">',
                '<h4 class="archive__tax_title">',
                get_the_archive_title(),
                '</h4>',
                (isset($tax_description) && !empty($tax_description) ? '<div class="archive__tax_description">' . esc_html($tax_description) . '</div>' : ''),
                '</div>';
        }
        $portfolio_render = new WglPortfolio();
        echo $portfolio_render->render($defaults);

    echo '</div>';

    // Sidebar
    echo (!empty($sb['content'])) ? $sb['content'] : '';

echo '</div>';
echo '</div>'; // wgl-container

get_footer();
