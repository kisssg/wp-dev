<?php
namespace WglAddons\Widgets;

defined('ABSPATH') || exit; // If this file is called directly, abort.

use Elementor\{Widget_Base, Controls_Manager, Control_Media, Utils, Repeater};
use WglAddons\Includes\Wgl_Carousel_Settings;

class Wgl_Clients extends Widget_Base
{
    public function get_name() {
        return 'wgl-clients';
    }

    public function get_title() {
        return esc_html__( 'WGL Clients', 'littledino-core' );
    }

    public function get_icon() {
        return 'wgl-clients';
    }

    public function get_script_depends() {
        return [
            'slick',
        ];
    }

    public function get_categories() {
        return [ 'wgl-extensions' ];
    }

    protected function register_controls()
    {
        /*-----------------------------------------------------------------------------------*/
        /*  Content
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'wgl_clients_section',
            array(
                'label' => esc_html__('Clients Settings', 'littledino-core'),
            )
        );

        $this->add_control('item_grid',
            array(
                'label' => esc_html__('Columns Amount', 'littledino-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '1' => esc_html__('One Column', 'littledino-core'),
                    '2' => esc_html__('Two Columns', 'littledino-core'),
                    '3' => esc_html__('Three Columns', 'littledino-core'),
                    '4' => esc_html__('Four Columns', 'littledino-core'),
                    '5' => esc_html__('Five Columns', 'littledino-core'),
                    '6' => esc_html__('Six Columns', 'littledino-core'),
                ],
                'default' => '1',
            )
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'thumbnail',
            array(
                'label' => esc_html__( 'Thumbnail', 'littledino-core' ),
                'type' => Controls_Manager::MEDIA,
                'label_block' => true,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
            )
        );

        $repeater->add_control(
            'hover_thumbnail',
            array(
                'label' => esc_html__( 'Hover Thumbnail', 'littledino-core' ),
                'type' => Controls_Manager::MEDIA,
                'label_block' => true,
                'default' => [
                    'url' => '',
                ],
                'description' => esc_html__( 'Need for \'Exchange Images\' and \'Shadow\' animations only.', 'littledino' ),
            )
        );

        $repeater->add_control('client_link',
            array(
                'label' => esc_html__('Add Link', 'littledino-core'),
                'type' => Controls_Manager::URL,
                'label_block' => true,
            )
        );

        $this->add_control(
            'list',
            array(
                'label' => esc_html__( 'Items', 'littledino-core' ),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
            )
        );

        $this->add_control('item_anim',
            array(
                'label' => esc_html__('Thumbnail Animation', 'littledino-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'grayscale' => esc_html__('Grayscale', 'littledino-core'),
                    'opacity' => esc_html__('Opacity', 'littledino-core'),
                    'zoom' => esc_html__('Zoom', 'littledino-core'),
                    'contrast' => esc_html__('Contrast', 'littledino-core'),
                    'blur' => esc_html__('Blur', 'littledino-core'),
                    'invert' => esc_html__('Invert', 'littledino-core'),
                    'ex_images' => esc_html__('Exchange Images', 'littledino-core'),
                ],
                'default' => 'grayscale',
            )
        );

        $this->add_control(
            'item_align',
            array(
                'label' => esc_html__( 'Alignment', 'littledino-core' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'flex-start' => [
                        'title' => esc_html__( 'Left', 'littledino-core' ),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__( 'Center', 'littledino-core' ),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'flex-end' => [
                        'title' => esc_html__( 'Right', 'littledino-core' ),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'label_block' => false,
                'default' => 'center',
                'toggle' => true,
                'selectors' => [
                    '{{WRAPPER}} .clients_image' => 'justify-content: {{VALUE}};',
                ],
            )
        );

        $this->add_control(
            'item_align_v',
            array(
                'label' => esc_html__( 'Vertical Alignment', 'littledino-core' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'flex-start' => [
                        'title' => esc_html__( 'Top', 'littledino-core' ),
                        'icon' => 'eicon-v-align-top',
                    ],
                    'center' => [
                        'title' => esc_html__( 'Center', 'littledino-core' ),
                        'icon' => 'eicon-v-align-middle',
                    ],
                    'flex-end' => [
                        'title' => esc_html__( 'Bottom', 'littledino-core' ),
                        'icon' => 'eicon-v-align-bottom',
                    ],
                ],
                'label_block' => false,
                'default' => 'center',
                'toggle' => true,
                'selectors' => [
                    '{{WRAPPER}} .wgl-clients' => 'align-items: {{VALUE}};',
                    '{{WRAPPER}} .slick-track' => 'align-items: {{VALUE}}; display: flex;',
                ],
            )
        );

        $this->end_controls_section();

        /*-----------------------------------------------------------------------------------*/
        /*  Carousel options
        /*-----------------------------------------------------------------------------------*/

        Wgl_Carousel_Settings::options($this);
    }

    /**
     * @since 1.0.0
     * @version 1.0.5
     */
    protected function render()
    {
        $content = '';
        $carousel_options = array();
        $settings = $this->get_settings_for_display();
        extract($settings);

        if ((bool)$use_carousel) {
            // carousel options array
            $carousel_options = array(
                'slide_to_show' => $item_grid,
                'autoplay' => $autoplay,
                'autoplay_speed' => $autoplay_speed,
                'fade_animation' => $fade_animation,
                'slides_to_scroll' => $slides_to_scroll,
                'infinite' => true,
                'use_pagination' => $use_pagination,
                'pag_type' => $pag_type,
                'pag_offset' => $pag_offset,
                'pag_align' => $pag_align,
                'custom_pag_color' => $custom_pag_color,
                'pag_color' => $pag_color,
                'use_prev_next' => $use_prev_next,
                'prev_next_position' => $prev_next_position,
                'custom_prev_next_color' => $custom_prev_next_color,
                'prev_next_color' => $prev_next_color,
                'prev_next_color_hover' => $prev_next_color_hover,
                'prev_next_bg_idle' => $prev_next_bg_idle,
                'prev_next_bg_hover' => $prev_next_bg_hover,
                'custom_resp' => $custom_resp,
                'resp_medium' => $resp_medium,
                'resp_medium_slides' => $resp_medium_slides,
                'resp_tablets' => $resp_tablets,
                'resp_tablets_slides' => $resp_tablets_slides,
                'resp_mobile' => $resp_mobile,
                'resp_mobile_slides' => $resp_mobile_slides,
            );

            wp_enqueue_script( 'slick', get_template_directory_uri() . '/js/slick.min.js' );
        }

        $this->add_render_attribute( 'clients', [
			'class' => [
                'wgl-clients',
                'clearfix',
                'anim-'.$item_anim,
                'items-'.$item_grid,
            ],
            'data-carousel' => $use_carousel
        ] );

        foreach ( $settings['list'] as $index => $item ) {

            if (!empty($item['client_link']['url'])) {
                $client_link = $this->get_repeater_setting_key('client_link', 'list', $index);
                $this->add_render_attribute($client_link, 'class', 'image_link image_wrapper');
                $this->add_link_attributes($client_link, $item['client_link']);
            }

            $client_image = $this->get_repeater_setting_key( 'thumbnail', 'list' , $index );
            $this->add_render_attribute( $client_image, [
                'class' => 'main_image',
                'src' => esc_url($item['thumbnail']['url']),
                'alt' => Control_Media::get_image_alt( $item['thumbnail'] ),
            ] );

            $client_hover_image = $this->get_repeater_setting_key( 'hover_thumbnail', 'list' , $index );
            $this->add_render_attribute( $client_hover_image, [
                'class' => 'hover_image',
                'src' => esc_url($item['hover_thumbnail']['url']),
                'alt' => Control_Media::get_image_alt( $item['hover_thumbnail'] ),
            ] );

            ob_start();

            ?><div class="clients_image"><?php
                if ( !empty($item['client_link']['url']) ) : ?><a <?php echo $this->get_render_attribute_string( $client_link ); ?>><?php
                else : ?><div class="image_wrapper"><?php
                endif;
                    if (!empty($item['hover_thumbnail']['url']) && $item_anim == 'ex_images') : ?><img <?php echo $this->get_render_attribute_string( $client_hover_image ); ?> /><?php endif;
                    ?><img <?php echo $this->get_render_attribute_string( $client_image ); ?> /><?php
                if ( !empty($item['client_link']['url']) ) : ?></a><?php
                else : ?></div><?php
                endif;
            ?></div> <?php

            $content .= ob_get_clean();
        }

        ?><div <?php echo $this->get_render_attribute_string( 'clients' ); ?>><?php
            if((bool)$use_carousel) : echo Wgl_Carousel_Settings::init($carousel_options, $content, false);
            else : echo $content;
            endif;
        ?></div><?php
    }

    public function wpml_support_module() {
        add_filter( 'wpml_elementor_widgets_to_translate',  [$this, 'wpml_widgets_to_translate_filter']);
    }

    public function wpml_widgets_to_translate_filter( $widgets ){
        return \WglAddons\Includes\Wgl_WPML_Settings::get_translate(
            $this, $widgets
        );
    }
}
