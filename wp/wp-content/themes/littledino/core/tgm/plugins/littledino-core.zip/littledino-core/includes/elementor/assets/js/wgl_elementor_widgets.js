(function( $ ) {
    "use strict";

    jQuery(window).on( 'elementor/frontend/init', function (){
        if ( window.elementorFrontend.isEditMode() ) {
            window.elementorFrontend.hooks.addAction( 'frontend/element_ready/wgl-blog.default',
                function( $scope ){ 
                    littledino_parallax_video();
                    littledino_blog_masonry_init();
                    littledino_carousel_slick(); 
                }
            );            

            window.elementorFrontend.hooks.addAction( 'frontend/element_ready/wgl-blog-hero.default',
                function( $scope ){ 
                    littledino_parallax_video();
                	littledino_blog_masonry_init();
                	littledino_carousel_slick(); 
                }
            );            

            window.elementorFrontend.hooks.addAction( 'frontend/element_ready/wgl-carousel.default',
                function( $scope ){ 
                    littledino_carousel_slick();  
                }
            );            

            window.elementorFrontend.hooks.addAction( 'frontend/element_ready/wgl-portfolio.default',
                function( $scope ){ 
                    littledino_isotope();
                	littledino_carousel_slick();
                    littledino_scroll_animation();
                    littledino_wgl_dashes();  
                }
            );

            window.elementorFrontend.hooks.addAction( 'frontend/element_ready/wgl-progress-bar.default',
                function( $scope ){ 
                    littledino_progress_bars_init();
                }
            ); 

            window.elementorFrontend.hooks.addAction( 'frontend/element_ready/wgl-testimonials.default',
                function( $scope ) {
                	littledino_carousel_slick();
                }
            );

            window.elementorFrontend.hooks.addAction( 'frontend/element_ready/wgl-toggle-accordion.default',
                function( $scope ) {
                    littledino_accordion_init();
                }
            ); 

            window.elementorFrontend.hooks.addAction( 'frontend/element_ready/wgl-tabs.default',
                function( $scope ){ 
                    littledino_tabs_init();
                }
            ); 

            window.elementorFrontend.hooks.addAction( 'frontend/element_ready/wgl-clients.default',
                function( $scope ){ 
                	littledino_carousel_slick();
                }
            );

            window.elementorFrontend.hooks.addAction( 'frontend/element_ready/wgl-image-layers.default',
                function( $scope ){ 
                	littledino_img_layers();
                }
            );

            window.elementorFrontend.hooks.addAction( 'frontend/element_ready/wgl-video-popup.default',
                function( $scope ){ 
                    littledino_videobox_init();
                }
            );          

            window.elementorFrontend.hooks.addAction( 'frontend/element_ready/wgl-countdown.default',
                function( $scope ){ 
                	littledino_countdown_init();
                }
            );

            window.elementorFrontend.hooks.addAction( 'frontend/element_ready/wgl-time-line-vertical.default',
                function( $scope ){ 
                	littledino_init_timeline_appear();
                }
            );

            window.elementorFrontend.hooks.addAction( 'frontend/element_ready/wgl-striped-services.default',
                function( $scope ){ 
                	littledino_striped_services_init();
                }
            );

            window.elementorFrontend.hooks.addAction( 'frontend/element_ready/wgl-image-comparison.default',
                function( $scope ){ 
                	littledino_image_comparison();  
                }
            );

            window.elementorFrontend.hooks.addAction( 'frontend/element_ready/wgl-counter.default',
                function( $scope ) {
                	littledino_counter_init();  
                }
            );

            window.elementorFrontend.hooks.addAction( 'frontend/element_ready/wgl-double-headings.default',
                function( $scope ) {
                    littledino_multi_headings();  
                }
            );            

            window.elementorFrontend.hooks.addAction( 'frontend/element_ready/wgl-button.default',
                function( $scope ) {
                    littledino_wgl_dashes();
                }
            );

            window.elementorFrontend.hooks.addAction( 'frontend/element_ready/wgl-pricing-table.default',
                function( $scope ) {
                    littledino_wgl_dashes();
                }
            );

            window.elementorFrontend.hooks.addAction( 'frontend/element_ready/wgl-info-box.default',
                function( $scope ) {
                    littledino_wgl_dashes();
                }
            );

            window.elementorFrontend.hooks.addAction( 'frontend/element_ready/wgl-working-hours.default',
                function( $scope ) {
                    littledino_wgl_dashes();
                }
            );
            
            window.elementorFrontend.hooks.addAction( 'frontend/element_ready/wgl-video-popup.default',
                function( $scope ) {
                    littledino_wgl_dashes();
                }
            );
        }
    });

})( jQuery );

