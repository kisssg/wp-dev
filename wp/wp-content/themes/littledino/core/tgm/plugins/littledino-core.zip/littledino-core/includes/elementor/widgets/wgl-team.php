<?php
namespace WglAddons\Widgets;

use WglAddons\Includes\Wgl_Loop_Settings;
use WglAddons\Includes\Wgl_Carousel_Settings;
use WglAddons\Templates\WglTeam;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Core\Schemes\Color;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Group_Control_Background;

if ( ! defined( 'ABSPATH' ) ) exit; // If this file is called directly, abort.

class Wgl_Team extends Widget_Base {

    public function get_name() {
        return 'wgl-team';
    }

    public function get_title() {
        return esc_html__( 'WGL Team', 'littledino-core' );
    }

    public function get_icon() {
        return 'wgl-team';
    }

    public function get_categories() {
        return [ 'wgl-extensions' ];
    }

    protected function register_controls() {
        $theme_color = esc_attr(\LittleDino_Theme_Helper::get_option('theme-custom-color'));
        $theme_color_secondary = esc_attr(\LittleDino_Theme_Helper::get_option('theme-secondary-color'));
        $h_font_color = \LittleDino_Theme_Helper::get_option('header-font')['color'];

        /* Start General Settings Section */
        $this->start_controls_section(
            'wgl_team_section',
            [ 'label' => esc_html__('Team Posts Settings', 'littledino-core') ]
        );

        $this->add_control(
            'posts_per_line',
            [
                'label' => esc_html__('Columns in Row', 'littledino-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '1' => esc_html__('1', 'littledino-core'),
                    '2' => esc_html__('2', 'littledino-core'),
                    '3' => esc_html__('3', 'littledino-core'),
                    '4' => esc_html__('4', 'littledino-core'),
                    '5' => esc_html__('5', 'littledino-core'),
                ],
                'default' => '3',
            ]
        );

        $this->add_control(
            'info_align',
            [
                'label' => esc_html__( 'Team Info Alignment', 'littledino-core' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'left' => esc_html__( 'Left', 'littledino-core' ),
                    'center' => esc_html__( 'Center', 'littledino-core' ),
                    'right' => esc_html__( 'Right', 'littledino-core' ),
                ],
                'default' => 'left',
            ]
        );

        $this->add_control(
            'grayscale_anim',
            [
                'label' => esc_html__('Add Grayscale Animation','littledino-core' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'On', 'littledino-core' ),
                'label_off' => esc_html__( 'Off', 'littledino-core' ),
                'return_value' => 'yes',
            ]
        );

        $this->add_control(
            'info_anim',
            [
                'label' => esc_html__('Add Info Fade Animation','littledino-core' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'On', 'littledino-core' ),
                'label_off' => esc_html__( 'Off', 'littledino-core' ),
                'return_value' => 'yes',
            ]
        );

        $this->add_control(
            'single_link_wrapper',
            [
                'label' => esc_html__('Add Link for Image','littledino-core' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'On', 'littledino-core' ),
                'label_off' => esc_html__( 'Off', 'littledino-core' ),
                'return_value' => 'yes',
            ]
        );

        $this->add_control(
            'single_link_heading',
            [
                'label' => esc_html__('Add Link for Heading','littledino-core' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'On', 'littledino-core' ),
                'label_off' => esc_html__( 'Off', 'littledino-core' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'hide_title',
            [
                'label' => esc_html__('Hide Title','littledino-core' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'On', 'littledino-core' ),
                'label_off' => esc_html__( 'Off', 'littledino-core' ),
                'return_value' => 'yes',
            ]
        );

        $this->add_control(
            'hide_department',
            [
                'label' => esc_html__('Hide Department','littledino-core' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'On', 'littledino-core' ),
                'label_off' => esc_html__( 'Off', 'littledino-core' ),
                'return_value' => 'yes',
            ]
        );

        $this->add_control(
            'hide_since',
            [
                'label' => esc_html__('Hide Since','littledino-core' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'On', 'littledino-core' ),
                'label_off' => esc_html__( 'Off', 'littledino-core' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'hide_soc_icons',
            [
                'label' => esc_html__('Hide Social Icons','littledino-core' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'On', 'littledino-core' ),
                'label_off' => esc_html__( 'Off', 'littledino-core' ),
                'return_value' => 'yes',
            ]
        );

        $this->add_control(
            'hide_content',
            [
                'label' => esc_html__('Hide Content','littledino-core' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'On', 'littledino-core' ),
                'label_off' => esc_html__( 'Off', 'littledino-core' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'letter_count',
            [
                'label' => esc_html__('Content Letters Count', 'littledino-core'),
                'type' => Controls_Manager::NUMBER,
                'condition' => [ 'hide_content!' => 'yes' ],
                'min' => 1,
                'step' => 1,
                'default' => '100',
            ]
        );

        $this->end_controls_section();

        Wgl_Carousel_Settings::options($this);


        /*-----------------------------------------------------------------------------------*/
        /*  Build Query Section
        /*-----------------------------------------------------------------------------------*/

        Wgl_Loop_Settings::init(
            $this,
            [
                'post_type' => 'team',
                'hide_cats' => true,
                'hide_tags' => true
            ]
        );


        /*-----------------------------------------------------------------------------------*/
        /*  STYLE -> ITEMS STYLE
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'item_style_section',
            [
                'label' => esc_html__( 'Items Style', 'littledino-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'item_gap',
            [
                'label' => esc_html__( 'Gap Items', 'littledino-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'default' => [
                    'top' => 0,
                    'left' => 15,
                    'right' => 15,
                    'bottom' => 55,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .wgl_module_team .team-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                    '{{WRAPPER}} .wgl_module_team .team-items_wrap' => 'margin-left: -{{LEFT}}{{UNIT}}; margin-right: -{{RIGHT}}{{UNIT}}; margin-bottom: -{{BOTTOM}}{{UNIT}}',
                ],
            ]
        );

        $this->end_controls_section();


        /*-----------------------------------------------------------------------------------*/
        /*  STYLE -> BACKGROUND
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'background_style_section',
            array(
                'label' => esc_html__( 'Background', 'littledino-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
            )
        );

        $this->add_control(
            'bg_color_type',
            array(
                'label' => esc_html__('Customize Backgrounds','littledino-core' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'On', 'littledino-core' ),
                'label_off' => esc_html__( 'Off', 'littledino-core' ),
                'return_value' => 'yes',
            )
        );

        $this->start_controls_tabs( 'background_color_tabs' );

        $this->start_controls_tab(
            'custom_background_color_normal',
            array(
                'label' => esc_html__( 'Normal' , 'littledino-core' ),
                'condition' => [ 'bg_color_type' => 'yes' ],
            )
        );

        $this->add_control(
            'background_color',
            array(
                'label' => esc_html__( 'Background Idle', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'condition' => [ 'bg_color_type' => 'yes' ],
                'default' => $theme_color,
                'selectors' => array(
                    '{{WRAPPER}} .team-item_content' => 'background: {{VALUE}}',
                ),
            )
        );


        $this->end_controls_tab();

        $this->start_controls_tab(
            'custom_background_color_hover',
            array(
                'label' => esc_html__( 'Hover' , 'littledino-core' ),
                'condition' => [ 'bg_color_type' => 'yes' ],
            )
        );

        $this->add_control(
            'background_hover_color',
            array(
                'label' => esc_html__( 'Background Hover', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'condition' => [ 'bg_color_type' => 'yes' ],
                'default' => $theme_color,
                'selectors' => array(
                    '{{WRAPPER}} .team-item_content:hover' => 'background: {{VALUE}}',
                ),
            )
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();

        $this->start_controls_section(
            'title_style_section',
            array(
                'label' => esc_html__( 'Title', 'littledino-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
            )
        );

        $this->add_control(
            'custom_title_color',
            array(
                'label' => esc_html__('Customize Colors','littledino-core' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'On', 'littledino-core' ),
                'label_off' => esc_html__( 'Off', 'littledino-core' ),
                'return_value' => 'yes',
            )
        );

        $this->start_controls_tabs( 'title_color_tabs' );

        $this->start_controls_tab(
            'custom_title_color_normal',
            array(
                'label' => esc_html__( 'Normal' , 'littledino-core' ),
                'condition' => [ 'custom_title_color' => 'yes' ],
            )
        );

        $this->add_control(
            'title_color',
            array(
                'label' => esc_html__( 'Title Idle', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'condition' => [ 'custom_title_color' => 'yes' ],
                'default' => $h_font_color,
                'selectors' => array(
                    '{{WRAPPER}} .team-title' => 'color: {{VALUE}}',
                ),
            )
        );


        $this->end_controls_tab();

        $this->start_controls_tab(
            'custom_title_color_hover',
            array(
                'label' => esc_html__( 'Hover' , 'littledino-core' ),
                'condition' => [ 'custom_title_color' => 'yes' ],
            )
        );

        $this->add_control(
            'title_hover_color',
            array(
                'label' => esc_html__( 'Title Hover', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'condition' => [ 'custom_title_color' => 'yes' ],
                'default' => $theme_color,
                'selectors' => array(
                    '{{WRAPPER}} .team-title:hover' => 'color: {{VALUE}}',
                ),
            )
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();

        $this->start_controls_section(
            'department_style_section',
            [
                'label' => esc_html__( 'Department', 'littledino-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'custom_depart_color',
            array(
                'label' => esc_html__('Customize Color','littledino-core' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'On', 'littledino-core' ),
                'label_off' => esc_html__( 'Off', 'littledino-core' ),
                'return_value' => 'yes',
            )
        );

        $this->add_control(
            'depart_color',
            array(
                'label' => esc_html__( 'Department Color', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'condition' => [ 'custom_depart_color' => 'yes' ],
                'default' => $theme_color_secondary,
                'selectors' => [
                    '{{WRAPPER}} .team-department' => 'color: {{VALUE}}',
                ],
            )
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'soc_icons_style_section',
            array(
                'label' => esc_html__( 'Social Icons', 'littledino-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
            )
        );

        $this->add_control(
            'custom_soc_color',
            array(
                'label' => esc_html__('Customize Colors','littledino-core' ),

                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'On', 'littledino-core' ),
                'label_off' => esc_html__( 'Off', 'littledino-core' ),
                'return_value' => 'yes',
            )
        );

        $this->start_controls_tabs( 'soc_color_tabs' );

        $this->start_controls_tab(
            'custom_soc_color_normal',
            array(
                'label' => esc_html__( 'Normal' , 'littledino-core' ),
                'condition' => [ 'custom_soc_color' => 'yes' ],
            )
        );

        $this->add_control(
            'soc_color',
            array(
                'label' => esc_html__( 'Icon Idle', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'condition' => [ 'custom_soc_color' => 'yes' ],
                'default' => $h_font_color,
                'selectors' => array(
                    '{{WRAPPER}} .team-info_icons' => 'color: {{VALUE}}',
                ),
            )
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'custom_soc_color_hover',
            array(
                'label' => esc_html__( 'Hover' , 'littledino-core' ),
                'condition' => [ 'custom_soc_color' => 'yes' ],
            )
        );

        $this->add_control(
            'soc_hover_color',
            array(
                'label' => esc_html__( 'Icon Hover', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'default' => $theme_color,
                'selectors' => array(
                    '{{WRAPPER}} .team-icon:hover' => 'color: {{VALUE}}',
                ),
                'condition' => [ 'custom_soc_color' => 'yes' ],
            )
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();

        $this->add_control(
            'custom_soc_bg_color',
            array(
                'label' => esc_html__('Customize Backgrounds','littledino-core' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'On', 'littledino-core' ),
                'label_off' => esc_html__( 'Off', 'littledino-core' ),
                'return_value' => 'yes',
            )
        );

        $this->start_controls_tabs( 'soc_background_tabs' );

        $this->start_controls_tab(
            'custom_soc_bg_normal',
            array(
                'label' => esc_html__( 'Normal' , 'littledino-core' ),
                'condition' => [ 'custom_soc_bg_color' => 'yes' ],
            )
        );

        $this->add_control(
            'soc_bg_color',
            array(
                'label' => esc_html__( 'Background Idle', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'default' => '#f3f3f3',
                'selectors' => array(
                    '{{WRAPPER}} .team-info_icons' => 'background: {{VALUE}}',
                ),
                'condition' => [ 'custom_soc_bg_color' => 'yes' ],
            )
        );


        $this->end_controls_tab();

        $this->start_controls_tab(
            'custom_soc_bg_hover',
            array(
                'label' => esc_html__( 'Hover' , 'littledino-core' ),
                'condition' => [ 'custom_soc_bg_color' => 'yes' ],
            )
        );

        $this->add_control(
            'soc_bg_hover_color',
            array(
                'label' => esc_html__( 'Background Hover', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'condition' => [ 'custom_soc_bg_color' => 'yes' ],
                'default' => '#f3f3f3',
                'selectors' => array(
                    '{{WRAPPER}} .team-item_content:hover .team-info_icons' => 'background: {{VALUE}}',
                ),
            )
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();
    }

    protected function render() {
        $atts = $this->get_settings_for_display();

        $team = new WglTeam();
        echo $team->render($atts);
    }

    public function wpml_support_module() {
        add_filter( 'wpml_elementor_widgets_to_translate',  [$this, 'wpml_widgets_to_translate_filter']);
    }

    public function wpml_widgets_to_translate_filter( $widgets ){
        return \WglAddons\Includes\Wgl_WPML_Settings::get_translate(
            $this, $widgets
        );
    }
}