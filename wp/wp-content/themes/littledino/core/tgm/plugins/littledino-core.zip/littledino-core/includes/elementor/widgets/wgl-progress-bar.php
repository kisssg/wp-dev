<?php

namespace WglAddons\Widgets;

if ( ! defined( 'ABSPATH' ) ) exit; /// Abort, if accessed directly.

use WglAddons\Includes\Wgl_Icons;
use WglAddons\Includes\Wgl_Loop_Settings;
use WglAddons\Includes\Wgl_Carousel_Settings;
use WglAddons\Templates\WglProgressBar;
use Elementor\Widget_Base;
use Elementor\Utils;
use Elementor\Controls_Manager;
use Elementor\Core\Schemes\Color;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Box_Shadow;


class Wgl_Progress_Bar extends Widget_Base {

    public function get_name() {
        return 'wgl-progress-bar';
    }

    public function get_title() {
        return esc_html__( 'WGL Progress Bar', 'littledino-core' );
    }

    public function get_icon() {
        return 'wgl-progress-bar';
    }

    public function get_categories() {
        return [ 'wgl-extensions' ];
    }

    public function get_script_depends() {
        return [ 'appear' ];
    }

    protected function register_controls() {
        $theme_color = esc_attr(\LittleDino_Theme_Helper::get_option('theme-custom-color'));
        $second_color = esc_attr(\LittleDino_Theme_Helper::get_option('theme-secondary-color'));
        $third_color = esc_attr(\LittleDino_Theme_Helper::get_option('theme-third-color'));
        $header_font_color = esc_attr(\LittleDino_Theme_Helper::get_option('header-font')['color']);
        $main_font_color = esc_attr(\LittleDino_Theme_Helper::get_option('main-font')['color']);


        /*-----------------------------------------------------------------------------------*/
        /*  CONTENT -> GENERAL
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'section_content_progress_bar',
            [ 'label' => esc_html__( 'General', 'littledino-core' ) ]
        );

        $this->add_control(
            'progress_title',
            [
                'label' => esc_html__( 'Title', 'littledino-core' ),
                'type' => Controls_Manager::TEXT,
                'placeholder' => esc_attr__( 'Type your title', 'littledino-core' ),
                'default' => esc_html__( 'Lorem ipsum', 'littledino-core' ),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'value',
            [
                'label' => esc_html__( 'Value', 'littledino-core' ),
                'type' => Controls_Manager::SLIDER,
                'default' => [ 'size' => 50, 'unit' => '%' ],
                'label_block' => true,
            ]
        );

        $this->add_control(
            'units',
            [
                'label' => esc_html__( 'Value Suffix', 'littledino-core' ),
                'type' => Controls_Manager::TEXT,
                'placeholder' => esc_attr__( 'Your value suffix', 'littledino-core' ),
                'description' => esc_html__( 'For example: %, px, points, etc.', 'littledino-core' ),
                'default' => esc_html__( '%', 'littledino-core' ),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'color_animation',
            [
                'label' => esc_html__( 'Infinite color animation', 'littledino-core' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Use', 'littledino-core' ),
                'label_off' => esc_html__( 'Unuse', 'littledino-core' ),
                'default' => 'yes',
                'return_value' => 'yes',
            ]
        );

        $this->add_control(
            'color_animation_duration',
            [
                'label' => esc_html__( 'Animation Duration', 'littledino-core' ),
                'type' => Controls_Manager::SLIDER,
                'condition' => [ 'color_animation' => 'yes' ],
                'range' => [
                    's' => [
                        'min' => 0.1,
                        'max' => 5,
                        'step' => 0.1,
                    ],
                ],
                'default' => [ 'size' => 2, 'unit' => 's' ],
                'selectors' => [
                    '{{WRAPPER}} .progress_bar.animated' => 'animation-duration: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();


        /*-----------------------------------------------------------------------------------*/
        /*  STYLE -> TITLE
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'section_style_title',
            [
                'label' => esc_html__( 'Title', 'littledino-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'progress_title_typo',
                'fields_options' => [
                    'typography' => ['default' => 'yes'],
                    'font_family' => ['default' => \Wgl_Addons_Elementor::$typography_1['font_family']],
                    'font_weight' => ['default' => \Wgl_Addons_Elementor::$typography_1['font_weight']],
                ],
                'selector' => '{{WRAPPER}} .progress_label',
            ]
        );

        $this->add_control(
            'progress_title_tag',
            [
                'label' => esc_html__( 'Title HTML Tag', 'littledino-core' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'h1' => '‹h1›',
                    'h2' => '‹h2›',
                    'h3' => '‹h3›',
                    'h4' => '‹h4›',
                    'h5' => '‹h5›',
                    'h6' => '‹h6›',
                    'div' => '‹div›',
                ],
                'default' => 'div',
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'custom_title_color',
            [
                'label' => esc_html__( 'Color', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'default' => $header_font_color,
                'selectors' => [
                    '{{WRAPPER}} .progress_label' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'title_margin',
            [
                'label' => esc_html__( 'Margin', 'littledino-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'default' => [
                    'top' => 8,
                    'right' => 0,
                    'bottom' => 9,
                    'left' => 0,
                ],
                'selectors' => [
                    '{{WRAPPER}} .progress_label' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();


        /*-----------------------------------------------------------------------------------*/
        /*  STYLE -> VALUE
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'section_style_value',
            [
                'label' => esc_html__( 'Value', 'littledino-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'progress_value_typo',
                'fields_options' => [
                    'typography' => ['default' => 'yes'],
                    'font_family' => ['default' => \Wgl_Addons_Elementor::$typography_1['font_family']],
                    'font_weight' => ['default' => \Wgl_Addons_Elementor::$typography_1['font_weight']],
                ],
                'selector' => '{{WRAPPER}} .progress_value_wrap',
            ]
        );

        $this->add_control(
            'custom_value_color',
            [
                'label' => esc_html__( 'Color', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'default' => $header_font_color,
                'selectors' => [
                    '{{WRAPPER}} .progress_value_wrap' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'custom_value_color_bg',
            [
                'label' => esc_html__( 'Background Color', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .progress_value_wrap' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'value_margin',
            [
                'label' => esc_html__( 'Margin', 'littledino-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .progress_value_wrap' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'value_border_radius',
            [
                'label' => esc_html__( 'Border Radius', 'littledino-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .progress_value_wrap' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'value_pos',
            [
                'label' => esc_html__( 'Value Position', 'littledino-core' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'fixed' => esc_html__( 'Fixed', 'littledino-core' ),
                    'dynamic' => esc_html__( 'Dynamic', 'littledino-core' ),
                ],
                'default' => 'fixed',
            ]
        );

        $this->end_controls_section();

        /*-----------------------------------------------------------------------------------*/
        /*  STYLE -> BAR
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'section_style_bar',
            [
                'label' => esc_html__( 'Bar', 'littledino-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'bar_height',
            [
                'label' => esc_html__( 'Height', 'littledino-core' ),
                'type' => Controls_Manager::SLIDER,
                'range' => [
                    'px' => [
                        'min' => 1,
                        'max' => 50,
                    ],
                ],
                'default' => [ 'size' => 10, 'unit' => 'px' ],
                'label_block' => true,
                'selectors' => [
                    '{{WRAPPER}} .progress_bar_wrap' => 'height: calc({{SIZE}}{{UNIT}} + 6px);',
                    '{{WRAPPER}} .progress_bar' => 'height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'bar_bg_color',
            [
                'label' => esc_html__( 'Background Bar Color', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .progress_bar_wrap' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'bar_color',
            [
                'label' => esc_html__( 'Bar Color', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'default' => $theme_color,
                'selectors' => [
                    '{{WRAPPER}} .progress_bar_wrap' => 'border-color: {{VALUE}};',
                    '{{WRAPPER}} .progress_bar' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'bar_animation_color',
            [
                'label' => esc_html__( 'Secondary Bar Color', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'condition' => [ 'color_animation' => 'yes' ],
                'default' => 'rgba(255, 255, 255, 0.35)',
                'selectors' => [
                    '{{WRAPPER}} .progress_bar.animated' => 'background-image: linear-gradient(0.325turn, {{VALUE}} 25%, transparent 25%, transparent 50%, {{VALUE}} 50%, {{VALUE}} 75%, transparent 75%);',
                ],
            ]
        );

        $this->add_responsive_control(
            'bar_padding',
            [
                'label' => esc_html__( 'Padding', 'littledino-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .progress_bar_wrap' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'bar_margin',
            [
                'label' => esc_html__( 'Margin', 'littledino-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .progress_bar_wrap' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'bar_border_radius',
            [
                'label' => esc_html__( 'Border Radius', 'littledino-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'default' => [
                    'top' => 5,
                    'right' => 5,
                    'bottom' => 5,
                    'left' => 5,
                    'units' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .progress_bar_wrap' => 'border-radius: calc({{TOP}}{{UNIT}} * 1.6) calc({{RIGHT}}{{UNIT}} * 1.6) calc({{BOTTOM}}{{UNIT}} * 1.6) calc({{LEFT}}{{UNIT}} * 1.6);',
                    '{{WRAPPER}} .progress_bar' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'bar_box_shadow',
                'selector' => '{{WRAPPER}} .progress_bar_wrap',
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'border',
                'selector' => '{{WRAPPER}} .progress_bar_wrap',
                'separator' => 'before',
            ]
        );

        $this->end_controls_section();

    }

    public function render() {

        $_s = $this->get_settings_for_display();

        wp_enqueue_script('appear', get_template_directory_uri() . '/js/jquery.appear.js', array(), false, false);

        $this->add_render_attribute(
            [
                'progress_bar' => [
                    'class' => [
                        'wgl-progress_bar',
                        $_s['value_pos'] == 'dynamic' ? 'dynamic-value' : '',
                    ],
                ],
                'bar' => [
                    'class' => [
                        'progress_bar',
                        $_s['color_animation'] == 'yes' ? 'animated' : '',
                    ],
                    'data-width' => esc_attr( (int)$_s['value']['size'] ),
                ],
                'label' => [
                    'class' => 'progress_label',
                ],
            ]
        );

        $title_tag = esc_attr( $_s['progress_title_tag'] );
        $value = (int)$_s['value']['size'];
        $units = $_s['units'];

        printf( '<div %s>', $this->get_render_attribute_string( 'progress_bar' ) );
            ?>
            <div class="progress_wrap">
                <div class="progress_label_wrap"><?php
                    if ( $_s['progress_title'] ) :
                        printf( '<%1$s %2$s>%3$s</%1$s>',
                            $title_tag,
                            $this->get_render_attribute_string( 'label' ),
                            esc_html($_s['progress_title'])
                        );
                    endif;
                    ?>
                    <div class="progress_value_wrap"><?php
                        if ( $value ) printf( '<span class="progress_value">%s</span>', esc_html( $value ) );
                        if ( $units ) printf( '<span class="progress_units">%s</span>', esc_html( $units ) );
                        ?>
                    </div>
                </div>
                <div class="progress_bar_wrap"><?php
                    printf( '<span %s></span>', $this->get_render_attribute_string( 'bar' ) );
                    ?>
                </div>
            </div>
        </div>
        <?php
    }

    public function wpml_support_module() {
        add_filter( 'wpml_elementor_widgets_to_translate',  [$this, 'wpml_widgets_to_translate_filter']);
    }

    public function wpml_widgets_to_translate_filter( $widgets ){
        return \WglAddons\Includes\Wgl_WPML_Settings::get_translate(
            $this, $widgets
        );
    }
}