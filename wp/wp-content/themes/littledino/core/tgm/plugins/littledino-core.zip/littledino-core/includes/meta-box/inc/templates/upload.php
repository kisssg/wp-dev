<script id="tmpl-rwmb-upload-area" type="text/html">
	<div class="rwmb-upload-inside">
		<h3>{{{ i18nRwmbMedia.uploadInstructions }}}</h3>
		<p>{{{ i18nRwmbMedia.or }}}</p>
		<p><a href="#" class="rwmb-browse-button button button-hero" id="{{{ _.uniqueId( 'rwmb-upload-browser-') }}}">{{{ i18nRwmbMedia.select }}}</a></p>
	</div>
</script>
