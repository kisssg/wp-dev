<?php

namespace WglAddons\Widgets;

if ( ! defined( 'ABSPATH' ) ) exit; // Abort, if accessed directly.

use WglAddons\Includes\Wgl_Icons;
use WglAddons\Includes\Wgl_Carousel_Settings;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Control_Media;
use Elementor\Core\Schemes\Color;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Group_Control_Background;
use Elementor\Utils;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Css_Filter;
use Elementor\Repeater;


class Wgl_Working_Hours extends Widget_Base {

	public function get_name() {
		return 'wgl-working-hours';
	}

	public function get_title() {
		return esc_html__( 'WGL Working Hours', 'littledino-core' );
	}

	public function get_icon() {
		return 'wgl-working-hours';
	}

	public function get_categories() {
		return [ 'wgl-extensions' ];
	}

	public function get_script_depends() {
		return [ 'appear' ];
	}

	protected function register_controls() {
		$theme_color = esc_attr(\LittleDino_Theme_Helper::get_option('theme-custom-color'));
		$second_color = esc_attr(\LittleDino_Theme_Helper::get_option('theme-secondary-color'));
		$third_color = esc_attr(\LittleDino_Theme_Helper::get_option('theme-third-color'));
		$h_font_color = esc_attr(\LittleDino_Theme_Helper::get_option('header-font')['color']);
		$main_font_color = esc_attr(\LittleDino_Theme_Helper::get_option('main-font')['color']);


		/*-----------------------------------------------------------------------------------*/
		/*  CONTENT -> GENERAL
		/*-----------------------------------------------------------------------------------*/

		$this->start_controls_section(
			'wgl_working_section',
			[ 'label' => esc_html__( 'General', 'littledino-core' ) ]
		);

		$this->add_control(
			'wh_title',
			[
				'label' => esc_html__( 'Title', 'littledino-core' ),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__( 'Open Hours', 'littledino-core' ),
			]
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'wh_day',
			[
				'label' => esc_html__( 'Day', 'littledino-core' ),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__( 'Monday', 'littledino-core' ),
			]
		);

		$repeater->add_control(
			'wh_hours',
			[
				'label' => esc_html__( 'Hours', 'littledino-core' ),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__( '8 am - 7pm', 'littledino-core' ),
			]
		);

		$repeater->add_control(
			'custom_colors',
			[
				'label' => esc_html__( 'Custom Colors','littledino-core' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'On', 'littledino-core' ),
				'label_off' => esc_html__( 'Off', 'littledino-core' ),
				'return_value' => 'yes',
			]
		);

		$repeater->add_control(
			'day_color',
			[
				'label' => esc_html__( 'Day Color', 'littledino-core' ),
				'type' => Controls_Manager::COLOR,
				'condition' => [ 'custom_colors' => 'yes' ],
				'default' => $main_font_color,
			]
		);

		$repeater->add_control(
			'hours_color',
			[
				'label' => esc_html__( 'Hours Color', 'littledino-core' ),
				'type' => Controls_Manager::COLOR,
				'condition' => [ 'custom_colors' => 'yes' ],
				'default' => $second_color,
			]
		);

		$this->add_control(
			'items',
			[
				'label' => esc_html__( 'Work Schedule', 'littledino-core' ),
				'type' => Controls_Manager::REPEATER,
				'default' => [
					[
						'wh_day' => esc_html__( 'Mon - Fri', 'littledino-core'),
						'wh_hours' => esc_html__( '8 am - 7pm', 'littledino-core'),

					], [
						'wh_day' => esc_html__( 'Saturday', 'littledino-core'),
						'wh_hours' => esc_html__( '9 am - 4pm', 'littledino-core'),
					], [
						'wh_day' => esc_html__( 'Sunday', 'littledino-core'),
						'wh_hours' => esc_html__( 'Closed', 'littledino-core'),
					],
				],
				'fields' => $repeater->get_controls(),
				'title_field' => '{{wh_day}}',
			]
		);

		$this->end_controls_section();


		/*-----------------------------------------------------------------------------------*/
		/*  STYLE -> GENERAL
		/*-----------------------------------------------------------------------------------*/

		$this->start_controls_section(
			'style_section_item',
			[
				'label' => esc_html__( 'General', 'littledino-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'title_margin',
			[
				'label' => esc_html__( 'Title Margin', 'littledino-core' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'default' => [
					'top' => 0,
					'left' => 0,
					'right' => 0,
					'bottom' => 6,
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}} .wh__title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'wh_margin',
			[
				'label' => esc_html__( 'Item Margin', 'littledino-core' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'default' => [
					'top' => 0,
					'left' => 0,
					'right' => 0,
					'bottom' => 6,
					'unit' => 'px',
				],
				'selectors' => [
					'{{WRAPPER}} .wh__item' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'line_color',
			[
				'label' => esc_html__( 'Intermediate Line Color', 'littledino-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '#e5e5e5',
				'selectors' => [
					'{{WRAPPER}} .wh__item:after' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();


		/*-----------------------------------------------------------------------------------*/
		/*  STYLE -> TITLE
		/*-----------------------------------------------------------------------------------*/

		$this->start_controls_section(
			'style_section_title',
			[
				'label' => esc_html__( 'Title', 'littledino-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [ 'wh_title!' => '' ],
			]
		);

		$this->add_control(
			'wh_alignment',
			[
				'label' => esc_html__( 'Alignment', 'littledino-core' ),
				'type' => Controls_Manager::CHOOSE,

				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'littledino-core' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'littledino-core' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'littledino-core' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'default' => 'center',
				'selectors' => [
					'{{WRAPPER}}' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'title_color',
			[
				'label' => esc_html__( 'Color', 'littledino-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => $h_font_color,
				'selectors' => [
					'{{WRAPPER}} .wh__title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'wh-title',
				'selector' => '{{WRAPPER}} .wh__title',
			]
		);

		$this->end_controls_section();


		/*-----------------------------------------------------------------------------------*/
		/*  STYLE -> DAYS
		/*-----------------------------------------------------------------------------------*/

		$this->start_controls_section(
			'style_section_days',
			[
				'label' => esc_html__( 'Days', 'littledino-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'day_typo',
				'selector' => '{{WRAPPER}} .wh__day',
			]
		);

		$this->add_control(
			'day_color',
			[
				'label' => esc_html__( 'Color', 'littledino-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => $main_font_color,
				'selectors' => [
					'{{WRAPPER}} .wh__day' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'day_margin',
			[
				'label' => esc_html__( 'Margin', 'littledino-core' ),
				'type' => Controls_Manager::DIMENSIONS,
				'separator' => 'after',
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .wh__day' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();


		/*-----------------------------------------------------------------------------------*/
		/*  STYLE -> HOURS
		/*-----------------------------------------------------------------------------------*/

		$this->start_controls_section(
			'style_section_hours',
			[
				'label' => esc_html__( 'Hours', 'littledino-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'hours_typo',
				'selector' => '{{WRAPPER}} .wh__hours',
			]
		);

		$this->add_control(
			'hours_color',
			[
				'label' => esc_html__( 'Color', 'littledino-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => $second_color,
				'selectors' => [
					'{{WRAPPER}} .wh__hours' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'hours_margin',
			[
				'label' => esc_html__( 'Margin', 'littledino-core' ),
				'type' => Controls_Manager::DIMENSIONS,
				'separator' => 'after',
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .wh__hours' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();


		/*-----------------------------------------------------------------------------------*/
		/*  STYLE -> INNER DASHES
		/*-----------------------------------------------------------------------------------*/

		$this->start_controls_section(
			'section_style_dashed_border',
			[
				'label' => esc_html__( 'Inner Dashes', 'littledino-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'wh_dashed_switch',
			[
				'label' => esc_html__( 'Use inner dashed border?', 'littledino-core' ),
				'type' => Controls_Manager::SWITCHER,
			]
		);

		$this->add_control(
			'wh_dashed_anim_switch',
			[
				'label' => esc_html__( 'Use running animation on Hover state?', 'littledino-core' ),
				'type' => Controls_Manager::SWITCHER,
				'condition' => [ 'wh_dashed_switch' => 'yes' ],
				'default' => 'yes',
			]
		);

		$this->add_control(
			'wh_dashed_color',
			[
				'label' => esc_html__( 'Color', 'littledino-core' ),
				'type' => Controls_Manager::COLOR,
				'condition' => [ 'wh_dashed_switch' => 'yes' ],
				'default' => '#e5e5e5',
				'selectors' => [
					'{{WRAPPER}} .inner-dashed-border' => 'stroke: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'wh_dashed_disatance',
			[
				'label' => esc_html__( 'Offset', 'littledino-core' ),
				'type' => Controls_Manager::SLIDER,
				'condition' => [ 'wh_dashed_switch' => 'yes' ],
				'label_block' => true,
				'range' => [ 'px' => [ 'max' => 35 ] ],
				'default' => [
					'size' => 0,
					'unit' => 'px',
				],
			]
		);

		$this->add_control(
			'wh_dashes_radius',
			[
				'label' => esc_html__( 'Border Radius', 'littledino-core' ),
				'type' => Controls_Manager::SLIDER,
				'condition' => [ 'wh_dashed_switch' => 'yes' ],
				'label_block' => true,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [ 'max' => 50 ],
					'%' => [ 'max' => 50 ],
				],
				'default' => [
					'size' => 10,
					'unit' => 'px',
				],
			]
		);

		$this->end_controls_section();

	}

	protected function render() {

		$_s = $this->get_settings_for_display();

		$rect = [];
		if ( $_s['wh_dashed_switch'] ) :

			if ( $_s['wh_dashed_disatance']['size'] ) $rect['x/y'] = $_s['wh_dashed_disatance']['size'] . $_s['wh_dashed_disatance']['unit'];
			if ( $_s['wh_dashes_radius']['size'] ) $rect['rx/ry'] = $_s['wh_dashed_disatance']['size'] . $_s['wh_dashed_disatance']['unit'];

		endif;

		$this->add_render_attribute(
			[
				'wrapper' => [
					'class' => 'wgl-working-hours',
				],
				'svg' => [
					'class' => [
						'wgl-dashes inner-dashed-border',
						($_s['wh_dashed_anim_switch'] ? 'animated-dashes' : '')
					],
				],
				'rect' => [
					'x' => !empty($rect['x/y']) ? $rect['x/y'] : '',
					'y' => !empty($rect['x/y']) ? $rect['x/y'] : '',
					'rx' => !empty($rect['rx/ry']) ? $rect['rx/ry'] : '',
					'ry' => !empty($rect['rx/ry']) ? $rect['rx/ry'] : '',
					'width' => '0',
					'height' => '0',
				],
			]
		);

		printf( '<div %s>', $this->get_render_attribute_string( 'wrapper' ) );

		if ( $_s['wh_title'] )
			printf( '<h3 class="wh__title">%s</h3>', $_s['wh_title'] );

		foreach ( $_s['items'] as $index => $item ) :

			$_day = $this->get_repeater_setting_key( 'wh_day', 'items' , $index );
			$_hours = $this->get_repeater_setting_key( 'wh_hours', 'items' , $index );

			$this->add_render_attribute(
				[
					$_day => [
						'class' => 'wh__day',
						'style' => $item['custom_colors'] ? 'color: '.esc_attr($item['day_color']).';' : '',
					],
					$_hours => [
						'class' => 'wh__hours',
						'style' => $item['custom_colors'] ? 'color: '.esc_attr($item['hours_color']).';' : '',
					],
				]
			);

			?>
			<div class="wh__item"><?php
				if ( $item['wh_day'] )
					printf( '<div %s>%s</div>',
						$this->get_render_attribute_string( $_day ),
						esc_html($item['wh_day'])
					);
				if ( $item['wh_hours'] )
					printf( '<div %s>%s</div>',
						$this->get_render_attribute_string( $_hours ),
						esc_html($item['wh_hours'])
					);
				?>
			</div><?php

		endforeach;

		if ( $_s['wh_dashed_switch'] )
			printf( '<svg %s><rect %s></rect></svg>',
				$this->get_render_attribute_string( 'svg' ),
				$this->get_render_attribute_string( 'rect' )
			);
		?>
		</div><?php
	}

	public function wpml_support_module() {
        add_filter( 'wpml_elementor_widgets_to_translate',  [$this, 'wpml_widgets_to_translate_filter']);
    }

    public function wpml_widgets_to_translate_filter( $widgets ){
        return \WglAddons\Includes\Wgl_WPML_Settings::get_translate(
            $this, $widgets
        );
    }
}