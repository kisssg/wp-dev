<?php

namespace WglAddons\Widgets;

if ( ! defined( 'ABSPATH' ) ) exit; // Abort, if accessed directly.

use WglAddons\Includes\Wgl_Icons;
use WglAddons\Includes\Wgl_Carousel_Settings;
use WglAddons\Includes\Wgl_Elementor_Helper;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Core\Schemes\Color;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Group_Control_Background;
use Elementor\Utils;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Css_Filter;



class Wgl_Counter extends Widget_Base {

    public function get_name() {
        return 'wgl-counter';
    }

    public function get_title() {
        return esc_html__( 'WGL Counter', 'littledino-core' );
    }

    public function get_icon() {
        return 'wgl-counter';
    }

    public function get_categories() {
        return [ 'wgl-extensions' ];
    }

    public function get_script_depends() {
        return [ 'appear' ];
    }

    protected function register_controls() {
        $theme_color = esc_attr(\LittleDino_Theme_Helper::get_option('theme-custom-color'));
        $second_color = esc_attr(\LittleDino_Theme_Helper::get_option('theme-secondary-color'));
        $third_color = esc_attr(\LittleDino_Theme_Helper::get_option('theme-third-color'));
        $header_font_color = esc_attr(\LittleDino_Theme_Helper::get_option('header-font')['color']);
        $main_font_color = esc_attr(\LittleDino_Theme_Helper::get_option('main-font')['color']);


        /*-----------------------------------------------------------------------------------*/
        /*  CONTENT -> GENERAL
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'section_content_general',
            [ 'label' => esc_html__( 'General', 'littledino-core' ) ]
        );

        Wgl_Icons::init(
            $this,
            [
                'label' => esc_html__( 'Counter', 'littledino-core' ),
                'output' => '',
            ]
        );

        $this->add_control(
            'start_value',
            [
                'label' => esc_html__( 'Start Value', 'littledino-core' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 0,
                'step' => 10,
                'default' => 0,
                'separator' => 'before'
            ]
        );

        $this->add_control(
            'end_value',
            [
                'label' => esc_html__( 'End Value', 'littledino-core' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 1,
                'step' => 10,
                'default' => 120,
            ]
        );

        $this->add_control(
            'prefix',
            [
                'label' => esc_html__( 'Counter Prefix', 'littledino-core' ),
                'type' => Controls_Manager::TEXT,
            ]
        );

        $this->add_control(
            'suffix',
            [
                'label' => esc_html__( 'Counter Suffix', 'littledino-core' ),
                'type' => Controls_Manager::TEXT,
                'placeholder' => esc_attr__( '+', 'littledino-core' ),
            ]
        );

        $this->add_control(
            'speed',
            [
                'label' => esc_html__( 'Animation Speed', 'littledino-core' ),
                'type' => Controls_Manager::NUMBER,
                'min' => 100,
                'step' => 100,
                'default' => 2000,
            ]
        );

        $this->add_control(
            'c_title',
            [
                'label'         => esc_html__('Title', 'littledino-core'),
                'type'          => Controls_Manager::TEXT,
                'label_block'   => true,
                'default'       => esc_html__('This is the heading​', 'littledino-core'),
            ]
        );

        $this->add_control(
            'c_alignment',
            [
                'label' => esc_html__( 'Alignment', 'littledino-core' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => esc_html__( 'Left', 'littledino-core' ),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__( 'Center', 'littledino-core' ),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__( 'Right', 'littledino-core' ),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'default' => 'center',
                'toggle' => true,
            ]
        );

        $this->end_controls_section();


        /*-----------------------------------------------------------------------------------*/
        /*  STYLE -> ICON/IMAGE
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'section_style_icon',
            [
                'label' => esc_html__( 'Icon/Image', 'littledino-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [ 'icon_type!' => '' ],
            ]
        );

        $this->add_control(
            'primary_color',
            [
                'label' => esc_html__( 'Icon Color', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'condition' => [ 'icon_type' => 'font' ],
                'default' => $second_color,
                'selectors' => [
                    '{{WRAPPER}} .wgl-icon' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'c_icon_size',
            [
                'label' => esc_html__( 'Icon Size', 'littledino-core' ),
                'type' => Controls_Manager::SLIDER,
                'condition' => [ 'icon_type'   => 'font' ],
                'range' => [
                    'px' => [
                        'min' => 15,
                        'max' => 100,
                    ],
                ],
                'default'   => [
                    'unit' => 'px',
                    'size' => 40,
                ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-icon' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'c_icon_space',
            [
                'label' => esc_html__( 'Margin', 'littledino-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .counter__media-wrap' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'c_icon_padding',
            [
                'label' => esc_html__( 'Padding', 'littledino-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .counter__media-wrap' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'c_icon_border_radius',
            [
                'label' => esc_html__( 'Border Radius', 'littledino-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .counter__media-wrap' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'media',
                'label' => esc_html__( 'Background', 'littledino-core' ),
                'types' => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .counter__media-wrap',
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'counter_icon_border',
                'selector' => '{{WRAPPER}} .counter__media-wrap'
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'counter_icon_shadow',
                'selector' => '{{WRAPPER}} .counter__media-wrap',
            ]
        );

        $this->end_controls_section();


        /*-----------------------------------------------------------------------------------*/
        /*  STYLE -> VALUE
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'section_style_value',
            [
                'label' => esc_html__( 'Value', 'littledino-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'value_offset',
            [
                'label' => esc_html__( 'Value Offset', 'littledino-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'selectors' => [
                    '{{WRAPPER}} .counter__value-wrap' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'custom_fonts_value',
                'selector' => '{{WRAPPER}} .counter__value-wrap',
            ]
        );

        $this->add_control(
            'value_color',
            [
                'label' => esc_html__( 'Color', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'default' => $third_color,
                'selectors' => [
                    '{{WRAPPER}} .counter__value-wrap' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();


        /*-----------------------------------------------------------------------------------*/
        /*  STYLE -> TITLE
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'title_style_section',
            [
                'label' => esc_html__( 'Title', 'littledino-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'c_title_tag',
            [
                'label' => esc_html__( 'HTML Tag', 'littledino-core' ),
                'type' => Controls_Manager::SELECT,
                'default' => 'h3',
                'description' => esc_html__( 'Choose your tag for counter title', 'littledino-core' ),
                'options' => [
                    'h1' => '‹h1›',
                    'h2' => '‹h2›',
                    'h3' => '‹h3›',
                    'h4' => '‹h4›',
                    'h5' => '‹h5›',
                    'h6' => '‹h6›',
                    'div' => '‹div›',
                    'span' => '‹span›',
                ],
            ]
        );

        $this->add_responsive_control(
            'title_margin',
            [
                'label' => esc_html__( 'Margin', 'littledino-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'default'   => [
                    'top' => 1,
                    'right' => 0,
                    'bottom' => 0,
                    'left' => 0,
                    'unit' => 'px',
                    'isLinked' => false,
                ],
                'selectors' => [
                    '{{WRAPPER}} .counter__title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'custom_fonts_title',
                'selector' => '{{WRAPPER}} .counter__title',
            ]
        );

        $this->add_control(
            'title_color',
            [
                'label' => esc_html__( 'Color', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'default' => $header_font_color,
                'selectors' => [
                    '{{WRAPPER}} .counter__title' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();


        /*-----------------------------------------------------------------------------------*/
        /*  STYLE -> MODULE
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'section_style_item',
            [
                'label' => esc_html__( 'Module', 'littledino-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'c_offset',
            [
                'label' => esc_html__( 'Margin', 'littledino-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-counter' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'c_padding',
            [
                'label' => esc_html__( 'Padding', 'littledino-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-counter' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'c_border_radius',
            [
                'label' => esc_html__( 'Border Radius', 'littledino-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-counter' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->start_controls_tabs( 'counter_color_tab' );

        $this->start_controls_tab(
            'custom_counter_color_normal',
            [ 'label' => esc_html__( 'Normal' , 'littledino-core' ) ]
        );

        $this->add_control(
            'c_bg_color',
            [
                'label' => esc_html__( 'Background Color', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}} .wgl-counter' => 'background-color: {{VALUE}};'
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'counter_idle',
                'label' => esc_html__( 'Border Type', 'littledino-core' ),
                'selector' => '{{WRAPPER}} .wgl-counter',
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'counter_idle',
                'selector' =>  '{{WRAPPER}} .wgl-counter',
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'c_color_hover',
            [ 'label' => esc_html__( 'Hover' , 'littledino-core' ) ]
        );

        $this->add_control(
            'c_bg_color_hover',
            [
                'label' => esc_html__( 'Background Color', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'default' => '',
                'selectors' => [
                    '{{WRAPPER}}:hover .wgl-counter' => 'background-color: {{VALUE}};'
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'counter_hover',
                'label' => esc_html__( 'Border Type', 'littledino-core' ),
                'selector' => '{{WRAPPER}}:hover .wgl-counter',
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'counter_hover',
                'selector' => '{{WRAPPER}}:hover .wgl-counter',
            ]
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();
    }


    public function render() {

        $_s = $this->get_settings_for_display();

        $this->add_render_attribute(
            [
                'counter' => [
                    'class' => [
                        'wgl-counter',
                        'align-'.$_s['c_alignment']
                    ],
                ],
                'counter-value' => [
                    'class' => 'counter__value',
                    'data-start-value' => $_s['start_value'],
                    'data-end-value' => $_s['end_value'],
                    'data-speed' => $_s['speed'],
                ]
            ]
        );

        // Media
        ob_start();
        if (!empty($_s['icon_type'])) {
            $icons = new Wgl_Icons;
            echo $icons->build($this, $_s, []);
        }
        $counter_media = ob_get_clean();


        printf( '<div %s>', $this->get_render_attribute_string( 'counter' ) ); ?>
            <div class="counter__wrap"><?php
                if ( !empty($_s['icon_type']) ) : ?>
                    <div class="counter__media-wrap"><?php
                        if ( !empty($counter_media) ) echo $counter_media;
                        ?>
                    </div>
                    <?php
                endif; ?>
                <div class="counter__content-wrap">
                    <div class="counter__value-wrap"><?php
                        if ( !empty($_s['prefix']) )
                            printf( '<span class="counter__prefix">%s</span>', esc_html($_s['prefix']) );

                        if ( !empty($_s['end_value']) )
                            printf( '<span %s>%s</span>',
                                $this->get_render_attribute_string( 'counter-value' ),
                                esc_html($_s['start_value'])
                            );

                        if ( !empty($_s['suffix']) )
                            printf( '<span class="counter__suffix">%s</span>', esc_html($_s['suffix']) );
                        ?>
                    </div>
                    <?php
                    if ( !empty($_s['c_title']) )
                        printf( '<%1$s class="counter__title">%2$s</%1$s>',
                            esc_attr($_s['c_title_tag']),
                            esc_html($_s['c_title'])
                        );
                    ?>
                </div>
            </div>
        </div>

        <?php
    }

    public function wpml_support_module() {
        add_filter( 'wpml_elementor_widgets_to_translate',  [$this, 'wpml_widgets_to_translate_filter']);
    }

    public function wpml_widgets_to_translate_filter( $widgets ){
        return \WglAddons\Includes\Wgl_WPML_Settings::get_translate(
            $this, $widgets
        );
    }

}