<?php

namespace WglAddons\Widgets;

if ( ! defined( 'ABSPATH' ) ) exit; // Abort, if accessed directly.

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Control_Media;
use Elementor\Core\Schemes\Color;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Group_Control_Background;
use Elementor\Utils;
use Elementor\Group_Control_Css_Filter;


class Wgl_Double_Headings extends Widget_Base {

    public function get_name() {
        return 'wgl-double-headings';
    }

    public function get_title() {
        return esc_html__( 'WGL Double Headings', 'littledino-core' );
    }

    public function get_icon() {
        return 'wgl-double-headings';
    }

    public function get_categories() {
        return [ 'wgl-extensions' ];
    }

    public function get_script_depends() {
        return [ 'appear' ];
    }

    protected function register_controls() {
        $theme_color = esc_attr(\LittleDino_Theme_Helper::get_option('theme-custom-color'));
        $second_color = esc_attr(\LittleDino_Theme_Helper::get_option('theme-secondary-color'));
        $third_color = esc_attr(\LittleDino_Theme_Helper::get_option('theme-third-color'));
        $h_font_color = esc_attr(\LittleDino_Theme_Helper::get_option('header-font')['color']);
        $main_font_color = esc_attr(\LittleDino_Theme_Helper::get_option('main-font')['color']);


        /*-----------------------------------------------------------------------------------*/
        /*  CONTENT -> GENERAL
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'wgl_double_headings_section',
            [ 'label' => esc_html__( 'General', 'littledino-core' ) ]
        );

        $this->add_control(
            'title_1',
            [
                'label' => esc_html__( 'Title 1st Part', 'littledino-core' ),
                'type' => Controls_Manager::TEXTAREA,
                'rows' => 1,
                'placeholder' => esc_attr__( 'This is the heading​', 'littledino-core' ),
                'default' => esc_html__( 'This is the heading​', 'littledino-core' ),
            ]
        );

        $this->add_control(
            'title_2',
            [
                'label' => esc_html__( 'Title 2nd Part', 'littledino-core' ),
                'type' => Controls_Manager::TEXTAREA,
                'rows' => 1,
                'placeholder' => esc_attr__( '2nd Part', 'littledino-core' ),
            ]
        );

        $this->add_control(
            'title_3',
            [
                'label' => esc_html__( 'Title 3rd Part', 'littledino-core' ),
                'type' => Controls_Manager::TEXTAREA,
                'separator' => 'after',
                'rows' => 1,
                'placeholder' => esc_attr__( '3rd Part', 'littledino-core' ),
            ]
        );

        $this->add_control(
            'sub_pos',
            [
                'label' => esc_html__( 'Subtitle Position', 'littledino-core' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'column' => esc_html__( 'Top', 'littledino-core' ),
                    'column-reverse' => esc_html__( 'Bottom', 'littledino-core' ),
                ],
                'default' => 'column',
                'selectors' => [
                    '{{WRAPPER}} .wgl-double_heading' => 'flex-direction: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'subtitle',
            [
                'label' => esc_html__( 'Subtitle', 'littledino-core' ),
                'type' => Controls_Manager::TEXT,
                'separator' => 'after',
                'placeholder' => esc_attr__( 'Subtitle', 'littledino-core' ),
            ]
        );

        $this->add_responsive_control(
            'align',
            [
                'label' => esc_html__( 'Alignment', 'littledino-core' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => esc_html__( 'Left', 'littledino-core' ),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__( 'Center', 'littledino-core' ),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__( 'Right', 'littledino-core' ),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'default' => 'left',
            ]
        );

        $this->add_control(
            'title_tag',
            [
                'label' => esc_html__( 'Title Tag', 'littledino-core' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'h1' => '‹h1›',
                    'h2' => '‹h2›',
                    'h3' => '‹h3›',
                    'h4' => '‹h4›',
                    'h5' => '‹h5›',
                    'h6' => '‹h6›',
                    'div' => '‹div›',
                    'span' => '‹span›',
                ],
                'default' => 'h3',
            ]
        );

        $this->add_control(
            'link',
            [
                'label' => esc_html__( 'Link', 'littledino-core' ),
                'type' => Controls_Manager::URL,
                'placeholder' => esc_attr__( 'https://your-link.com', 'littledino-core' ),
            ]
        );

        $this->end_controls_section();


        /*-----------------------------------------------------------------------------------*/
        /*  STYLE -> TITLE 1ST PART
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'section_style_1st_title',
            [
                'label' => esc_html__( 'Title 1st Part', 'littledino-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_1_typo',
                'selector' => '{{WRAPPER}} .dbl-title__1',
            ]
        );

        $this->add_control(
            'title_1_color',
            [
                'label' => esc_html__( 'Color', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'default' => $h_font_color,
                'selectors' => [
                    '{{WRAPPER}} .dbl-title__1' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'title_1_bg',
            [
                'label' => esc_html__( 'Background Color', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'default' => 'rgba('.\LittleDino_Theme_Helper::hexToRGB($theme_color).', 0.5)',
                'selectors' => [
                    '{{WRAPPER}} .dbl-title__1' => 'background-image: linear-gradient(to top, {{VALUE}}, {{VALUE}});',
                ],
            ]
        );

        $this->add_responsive_control(
            'title_1_display',
            [
                'label' => esc_html__( 'Display', 'littledino-core' ),
                'type' => Controls_Manager::SELECT,
                'separator' => 'after',
                'prefix_class' => 'dbl-1st-%s',
                'options' => [
                    'block' => esc_html__( 'Block', 'littledino-core' ),
                    'inline' => esc_html__( 'Inline', 'littledino-core' ),
                ],
                'default' => 'block',
                'selectors' => [
                    '{{WRAPPER}} .title-1__wrap' => 'display: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();


        /*-----------------------------------------------------------------------------------*/
        /*  STYLE -> TITLE 2ND PART
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'section_style_2nd_title',
            [
                'label' => esc_html__( 'Title 2nd Part', 'littledino-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [ 'title_2!' => '' ],
            ]
        );


        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_2_typo',
                'selector' => '{{WRAPPER}} .dbl-title__2',
            ]
        );

        $this->add_control(
            'title_2_color',
            [
                'label' => esc_html__( 'Color', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'default' => $h_font_color,
                'selectors' => [
                    '{{WRAPPER}} .dbl-title__2' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'title_2_bg',
            [
                'label' => esc_html__( 'Background Color', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'default' => 'rgba('.\LittleDino_Theme_Helper::hexToRGB($second_color).', 0.5)',
                'selectors' => [
                    '{{WRAPPER}} .dbl-title__2' => 'background-image: linear-gradient(to top, {{VALUE}}, {{VALUE}});',
                ],
            ]
        );

        $this->add_responsive_control(
            'title_2_display',
            [
                'label' => esc_html__( 'Display', 'littledino-core' ),
                'type' => Controls_Manager::SELECT,
                'separator' => 'after',
                'prefix_class' => 'dbl-2nd-%s',
                'options' => [
                    'block' => esc_html__( 'Block', 'littledino-core' ),
                    'inline' => esc_html__( 'Inline', 'littledino-core' ),
                    'none' => esc_html__( 'None', 'littledino-core' ),
                ],
                'default' => 'block',
                'selectors' => [
                    '{{WRAPPER}} .title-2__wrap' => 'display: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();


        /*-----------------------------------------------------------------------------------*/
        /*  STYLE -> TITLE 3RD PART
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'section_style_3rd_title',
            [
                'label' => esc_html__( 'Title 3rd Part', 'littledino-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [ 'title_3!'  => '' ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_3_typo',
                'selector' => '{{WRAPPER}} .dbl-title__3',
            ]
        );

        $this->add_control(
            'title_3_color',
            [
                'label' => esc_html__( 'Color', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'default' => $h_font_color,
                'selectors' => [
                    '{{WRAPPER}} .dbl-title__3' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'title_3_bg',
            [
                'label' => esc_html__( 'Background Color', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'default' => 'rgba('.\LittleDino_Theme_Helper::hexToRGB($third_color).', 0.5)',
                'selectors' => [
                    '{{WRAPPER}} .dbl-title__3' => 'background-image: linear-gradient(to top, {{VALUE}}, {{VALUE}});',
                ],
            ]
        );

        $this->add_responsive_control(
            'title_3_display',
            [
                'label' => esc_html__( 'Display', 'littledino-core' ),
                'type' => Controls_Manager::SELECT,
                'separator' => 'after',
                'prefix_class' => 'dbl-3rd-%s',
                'options' => [
                    'block' => esc_html__( 'Block', 'littledino-core' ),
                    'inline' => esc_html__( 'Inline', 'littledino-core' ),
                    'none' => esc_html__( 'None', 'littledino-core' ),
                ],
                'default' => 'block',
                'selectors' => [
                    '{{WRAPPER}} .title-3__wrap' => 'display: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();


        /*-----------------------------------------------------------------------------------*/
        /*  STYLE -> SUBTITLE
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'section_style_subtitle',
            [
                'label' => esc_html__( 'Subtitle', 'littledino-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [ 'subtitle!'  => '' ],
            ]
        );

        $this->add_control(
            'subtitle_h',
            [
                'label' => esc_html__( 'Subtitle', 'littledino-core' ),
                'type' => Controls_Manager::HEADING,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'subtitle_typo',
                'selector' => '{{WRAPPER}} .dbl-subtitle',
            ]
        );

        $this->add_control(
            'subtitle_color',
            [
                'label' => esc_html__( 'Color', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'separator' => 'after',
                'default' => $third_color,
                'selectors' => [
                    '{{WRAPPER}} .dbl-subtitle' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_section();
    }

    /**
     * @since 1.0.0
     * @version 1.0.5
     */
    protected function render()
    {
        $_s = $this->get_settings_for_display();

        if (!empty($_s['link']['url'])) {
            $this->add_render_attribute('link', 'class', 'dbl-title_link');
            $this->add_link_attributes('link', $_s['link']);
        }

        $this->add_render_attribute(
            [
                'wrapper' => [
                    'class' => [
                        'wgl-double_heading',
                        'a'.$_s['align']
                    ],
                ],
                'title-1' => [
                    'class' => 'dbl-title__1',
                ],
                'title-2' => [
                    'class' => 'dbl-title__2',
                ],
                'title-3' => [
                    'class' => 'dbl-title__3',
                ],
            ]
        );

        printf( '<div %s>', $this->get_render_attribute_string( 'wrapper' ) );

            if ( $_s['subtitle'] ) printf( '<div class="dbl-subtitle"><span>%s</span></div>', esc_html($_s['subtitle']) );

            if ( $_s['link']['url'] ) printf ( '<a %s>', $this->get_render_attribute_string( 'link' ) );
              printf( '<%s class="dbl-titles_wrapper">', esc_attr($_s['title_tag']) );
                if ( $_s['title_1'] )
                    printf( '<span class="dbl-title__wrap title-1__wrap"><span %s>%s</span></span>',
                        $this->get_render_attribute_string( 'title-1' ),
                        esc_html($_s['title_1'])
                    );
                if ( $_s['title_2'] )
                    printf( '<span class="dbl-title__wrap title-2__wrap"><span %s>%s</span></span>',
                        $this->get_render_attribute_string( 'title-2' ),
                        esc_html($_s['title_2'])
                    );
                if ( $_s['title_3'] )
                    printf( '<span class="dbl-title__wrap title-3__wrap"><span %s>%s</span></span>',
                        $this->get_render_attribute_string( 'title-3' ),
                        esc_html($_s['title_3'])
                    );
              printf( '</%s>', esc_attr($_s['title_tag']) );
            if ( $_s['link']['url'] ) echo '</a>';
            ?>
        </div><?php
    }

    public function wpml_support_module() {
        add_filter( 'wpml_elementor_widgets_to_translate',  [$this, 'wpml_widgets_to_translate_filter']);
    }

    public function wpml_widgets_to_translate_filter( $widgets ){
        return \WglAddons\Includes\Wgl_WPML_Settings::get_translate(
            $this, $widgets
        );
    }
}