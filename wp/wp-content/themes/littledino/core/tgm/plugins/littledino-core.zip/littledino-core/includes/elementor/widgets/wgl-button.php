<?php
namespace WglAddons\Widgets;

defined('ABSPATH') || exit; // Abort, if accessed directly.

use Elementor\{Widget_Base, Controls_Manager, Core\Schemes\Color};
use Elementor\{Group_Control_Border, Group_Control_Typography, Group_Control_Box_Shadow};
use WglAddons\Includes\Wgl_Icons;


class Wgl_Button extends Widget_Base
{
    public function get_name() {
        return 'wgl-button';
    }

    public function get_title() {
        return esc_html__( 'WGL Button', 'littledino-core' );
    }

    public function get_icon() {
        return 'wgl-button';
    }

    public function get_categories() {
        return [ 'wgl-extensions' ];
    }

    public static function get_button_sizes() {
        return [
            'xs' => esc_html__( 'Extra Small', 'littledino-core' ),
            'sm' => esc_html__( 'Small', 'littledino-core' ),
            'md' => esc_html__( 'Medium', 'littledino-core' ),
            'lg' => esc_html__( 'Large', 'littledino-core' ),
            'xl' => esc_html__( 'Extra Large', 'littledino-core' ),
        ];
    }

    protected function register_controls()
    {
        $second_color = esc_attr(\LittleDino_Theme_Helper::get_option('theme-secondary-color'));
        $third_color = esc_attr(\LittleDino_Theme_Helper::get_option('theme-third-color'));

        /*-----------------------------------------------------------------------------------*/
        /*  CONTENT -> GENERAL
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'section_content_general',
            [ 'label' => esc_html__( 'General', 'littledino-core' ) ]
        );

        $this->add_control(
            'text',
            [
                'label' => esc_html__( 'Text', 'littledino-core' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__( 'View More', 'littledino-core' ),
                'placeholder' => esc_attr__( 'Button text', 'littledino-core' ),
            ]
        );

        $this->add_control(
            'link',
            [
                'label' => esc_html__( 'Link', 'littledino-core' ),
                'type' => Controls_Manager::URL,
                'placeholder' => esc_attr__( 'https://your-link.com', 'littledino-core' ),
                'default' => ['url' => '#'],
            ]
        );

        $this->add_responsive_control(
            'align',
            [
                'label' => esc_html__( 'Alignment', 'littledino-core' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'left' => [
                        'title' => esc_html__( 'Left', 'littledino-core' ),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__( 'Center', 'littledino-core' ),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__( 'Right', 'littledino-core' ),
                        'icon' => 'eicon-text-align-right',
                    ],
                    'justify' => [
                        'title' => esc_html__( 'Justified', 'littledino-core' ),
                        'icon' => 'eicon-text-align-justify',
                    ],
                ],
                'prefix_class' => 'elementor%s-align-',
                'default' => '',
            ]
        );

        $this->add_control(
            'b_size',
            [
                'label' => esc_html__( 'Size', 'littledino-core' ),
                'type' => Controls_Manager::SELECT,
                'options' => self::get_button_sizes(),
                'default' => 'lg',
                'style_transfer' => true,
            ]
        );

        $this->add_control(
            'b_css_id',
            [
                'label' => esc_html__( 'Button ID', 'littledino-core' ),
                'type' => Controls_Manager::TEXT,
                'default' => '',
                'title' => esc_html__( 'Add your custom id WITHOUT the Pound key. e.g: my-id', 'littledino-core' ),
                'label_block' => false,
                'description' => esc_html__( 'Ensure the ID is unique and unused elsewhere on page. Allowed characters are <code>A-z 0-9</code> & underscore without spaces.', 'littledino-core' ),
                'separator' => 'before',
            ]
        );

        $this->end_controls_section();


        /*-----------------------------------------------------------------------------------*/
        /*  CONTENT -> ICON/IMAGE
        /*-----------------------------------------------------------------------------------*/

        $output['b_icon_align'] = [
            'label' => esc_html__( 'Position', 'littledino-core' ),
            'type' => Controls_Manager::SELECT,
            'condition' => [ 'icon_type!' => '' ],
            'default' => 'left',
            'options' => [
                'left' => esc_html__( 'Before', 'littledino-core' ),
                'right' => esc_html__( 'After', 'littledino-core' ),
            ],
        ];

        $output['icon_indent'] = [
            'label' => esc_html__( 'Spacing', 'littledino-core' ),
            'type' => Controls_Manager::SLIDER,
            'condition' => [ 'icon_type!' => '' ],
            'range' => [
                'px' => [ 'max' => 50 ],
            ],
            'default' => [
                'size' => 10,
                'unit' => 'px',
            ],
            'selectors' => [
                '{{WRAPPER}} .elementor-button .align-icon-right i.icon' => 'margin-left: {{SIZE}}{{UNIT}};',
                '{{WRAPPER}} .elementor-button .align-icon-left i.icon' => 'margin-right: {{SIZE}}{{UNIT}};',
            ],
        ];

        Wgl_Icons::init(
            $this,
            [
                'output' => $output,
                'section' => true,
            ]
        );

        /*-----------------------------------------------------------------------------------*/
        /*  STYLE -> BUTTON
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'section_style_button',
            [
                'label' => esc_html__( 'Button', 'littledino-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'b_hover_animation',
            [
                'label' => esc_html__( 'Hover Animation', 'littledino-core' ),
                'type' => Controls_Manager::HOVER_ANIMATION,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'typography',
                'selector' => '{{WRAPPER}} a.elementor-button, {{WRAPPER}} .elementor-button',
            ]
        );

        $this->start_controls_tabs( 'tabs_button_style' );

        $this->start_controls_tab(
            'tab_button_idle',
            [ 'label' => esc_html__( 'Idle', 'littledino-core' ) ]
        );

        $this->add_control(
            'b_text_color',
            [
                'label' => esc_html__( 'Text Color', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} a.elementor-button, {{WRAPPER}} .elementor-button' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'b_bg_color_idle',
            [
                'label' => esc_html__( 'Background Color', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'scheme' => [
                    'type' => Color::get_type(),
                    'value' => Color::COLOR_1,
                ],
                'default' => $second_color,
                'selectors' => [
                    '{{WRAPPER}} a.elementor-button, {{WRAPPER}} .elementor-button' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'tab_button_hover',
            [ 'label' => esc_html__( 'Hover', 'littledino-core' ) ]
        );

        $this->add_control(
            'b_color_hover',
            [
                'label' => esc_html__( 'Text Color', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} a.elementor-button:hover, {{WRAPPER}} .elementor-button:hover, {{WRAPPER}} a.elementor-button:focus, {{WRAPPER}} .elementor-button:focus' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'b_bg_color_hover',
            [
                'label' => esc_html__( 'Background Color', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'default' => $third_color,
                'selectors' => [
                    '{{WRAPPER}} a.elementor-button:hover, {{WRAPPER}} .elementor-button:hover, {{WRAPPER}} a.elementor-button:focus, {{WRAPPER}} .elementor-button:focus' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'border_color_hover',
            [
                'label' => esc_html__( 'Border Color', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'condition' => [ 'border_border!' => '' ],
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} a.elementor-button:hover, {{WRAPPER}} .elementor-button:hover, {{WRAPPER}} a.elementor-button:focus, {{WRAPPER}} .elementor-button:focus' => 'border-color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();

        $this->add_responsive_control(
            'b_border_padding',
            [
                'label' => esc_html__( 'Padding', 'littledino-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'separator' => 'before',
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'button',
                'selector' => '{{WRAPPER}} .elementor-button',
            ]
        );


        $this->add_responsive_control(
            'b_border_radius',
            [
                'label' => esc_html__( 'Border Radius', 'littledino-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} a.elementor-button, {{WRAPPER}} .elementor-button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'button',
                'selector' => '{{WRAPPER}} .elementor-button',
            ]
        );

        $this->end_controls_section();


        /*-----------------------------------------------------------------------------------*/
        /*  STYLE -> INNER DASHES
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'section_style_dashed_border',
            [
                'label' => esc_html__( 'Inner Dashes', 'littledino-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'b_dashed_switch',
            [
                'label' => esc_html__( 'Use inner dashed border?', 'littledino-core' ),
                'type' => Controls_Manager::SWITCHER,
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'b_dashed_anim_switch',
            [
                'label' => esc_html__( 'Use running animation on Hover state?', 'littledino-core' ),
                'type' => Controls_Manager::SWITCHER,
                'condition' => [ 'b_dashed_switch' => 'yes' ],
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'b_dashed_color',
            [
                'label' => esc_html__( 'Color', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'condition' => [ 'b_dashed_switch' => 'yes' ],
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .wgl-button.elementor-button .inner-dashed-border' => 'stroke: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'b_dashed_disatance',
            [
                'label' => esc_html__( 'Offset', 'littledino-core' ),
                'type' => Controls_Manager::SLIDER,
                'condition' => [ 'b_dashed_switch' => 'yes' ],
                'label_block' => true,
                'range' => [ 'px' => [ 'max' => 35 ] ],
                'default' => [
                    'size' => 5,
                    'unit' => 'px',
                ],
            ]
        );

        $this->end_controls_section();


        /*-----------------------------------------------------------------------------------*/
        /*  STYLE -> ICON/IMAGE
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'section_style_icon',
            [
                'label' => esc_html__( 'Icon/Image', 'littledino-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
                'condition' => [ 'icon_type!' => '' ]
            ]
        );

        $this->add_responsive_control(
            'icon_margin',
            [
                'label' => esc_html__( 'Margin', 'littledino-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'separator' => 'before',
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .elementor-button .wgl-icon' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->start_controls_tabs(
            'tabs_button_style_icon',
            [ 'condition' => [ 'icon_type' => 'font' ] ]
        );

        $this->start_controls_tab(
            'tab_icon_idle',
            [ 'label' => esc_html__( 'Idle', 'littledino-core' ) ]
        );

        $this->add_control(
            'icon_color_idle',
            [
                'label' => esc_html__( 'Icon Color', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .wgl-icon' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'icon_size_idle',
            [
                'label' => esc_html__( 'Font Size', 'littledino-core' ),
                'type' => Controls_Manager::SLIDER,
                'condition' => [ 'icon_type' => 'font' ],
                'size_units' => [ 'px', 'em', 'rem', 'vw' ],
                'range' => [ 'px' => [ 'max' => 90 ] ],
                'default' => [ 'size' => 13, 'unit' => 'px' ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-icon' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'icon_rotation_idle',
            [
                'label' => esc_html__( 'Rotation', 'littledino-core' ),
                'type' => Controls_Manager::SLIDER,
                'condition' => [ 'icon_type!' => '' ],
                'size_units' => [ 'deg', 'turn' ],
                'range' => [
                    'deg' => [ 'min' => -360, 'max' => 360 ],
                    'turn' => [ 'min' => -1, 'max' => 1, 'step' => 0.1 ],
                ],
                'default' => [ 'size' => 0, 'unit' => 'deg' ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-icon i' => 'transform: rotate({{SIZE}}{{UNIT}});',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'tab_icon_hover',
            [ 'label' => esc_html__( 'Hover', 'littledino-core' ) ]
        );

        $this->add_control(
            'icon_color_hover',
            [
                'label' => esc_html__( 'Icon Color', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .elementor-button:hover .wgl-icon' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'icon_size_hover',
            [
                'label' => esc_html__( 'Font Size', 'littledino-core' ),
                'type' => Controls_Manager::SLIDER,
                'condition' => [ 'icon_type' => 'font' ],
                'size_units' => [ 'px', 'em', 'rem', 'vw' ],
                'range' => [ 'px' => [ 'max' => 90 ] ],
                'selectors' => [
                    '{{WRAPPER}} .elementor-button:hover .wgl-icon' => 'font-size: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'icon_rotation_hover',
            [
                'label' => esc_html__( 'Rotation', 'littledino-core' ),
                'type' => Controls_Manager::SLIDER,
                'condition' => [ 'icon_type!' => '' ],
                'size_units' => [ 'deg', 'turn' ],
                'range' => [
                    'deg' => [ 'min' => -360, 'max' => 360 ],
                    'turn' => [ 'min' => -1, 'max' => 1, 'step' => 0.1 ],
                ],
                'selectors' => [
                    '{{WRAPPER}} .elementor-button:hover .wgl-icon i' => 'transform: rotate({{SIZE}}{{UNIT}});',
                ],
            ]
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();
    }

    protected function render() {
        $_s = $this->get_settings_for_display();

        echo Wgl_Button::init_button($this, $_s);
    }

    /**
     * @since 1.0.0
     * @version 1.0.5
     */
    public static function init_button($self, $_s)
    {
        $self->add_render_attribute(
            [
                'wrapper' => [
                    'class' => 'wgl-button-wrapper',
                ],
                'button' => [
                    'class' => [
                        'wgl-button',
                        'elementor-button',
                    ],
                    'role' => 'button',
                ]
            ]
        );

        if (!empty($_s['link']['url'])) :
            $self->add_render_attribute('button', 'class', 'button-link');
            $self->add_link_attributes('button', $_s['link']);
        endif;

        if ( ! empty( $_s['b_css_id'] ) )
            $self->add_render_attribute( 'button', 'id', $_s['b_css_id'] );

        if ( ! empty( $_s['b_size'] ) )
            $self->add_render_attribute( 'button', 'class', 'size-'.$_s['b_size'] );

        if ( ! empty($_s['b_hover_animation']) )
            $self->add_render_attribute( 'button', 'class', 'hover-animation-'.$_s['b_hover_animation'] );


        $icon_alignment = isset($_s['b_icon_align']) ? 'align-icon-'.$_s['b_icon_align'] : '';

        $rect = [];
        if ( $_s['b_dashed_switch'] ) :

            switch ($_s['b_size']) {
                case 'xl': $rect['rx'] = $rect['ry'] = '23px'; break;
                case 'lg': $rect['rx'] = $rect['ry'] = '25px'; break;
                case 'md': $rect['rx'] = $rect['ry'] = '20px'; break;
                case 'sm': $rect['rx'] = $rect['ry'] = '18px'; break;
                case 'xs': $rect['rx'] = $rect['ry'] = '15px'; break;
            }

            if ( $_s['b_dashed_disatance']['size'] ) $rect['x'] = $rect['y'] = $_s['b_dashed_disatance']['size'] . $_s['b_dashed_disatance']['unit'];
            if ( $_s['b_border_radius']['top'] ) $rect['rx'] = $_s['b_border_radius']['top'] * 0.8 . $_s['b_border_radius']['unit'];
            if ( $_s['b_border_radius']['left'] ) $rect['ry'] = $_s['b_border_radius']['left'] * 0.8 . $_s['b_border_radius']['unit'];

        endif;

        $self->add_render_attribute(
            [
                'content-wrapper' => [
                    'class' => [
                        'button-content-wrapper',
                        $icon_alignment,
                    ]
                ],
                'wrapper' => [
                    'class' => (!empty($_s['icon_type']) ? 'has-icon' : '')
                ],
                'text' => [ 'class' => 'elementor-button-text' ],
                'svg' => [
                    'class' => [
                        'wgl-dashes inner-dashed-border',
                        ($_s['b_dashed_anim_switch'] ? 'animated-dashes' : '')
                    ],
                ],
                'rect' => [
                    'x' => !empty($rect['x']) ? $rect['x'] : '',
                    'y' => !empty($rect['y']) ? $rect['y'] : '',
                    'rx' => !empty($rect['rx']) ? $rect['rx'] : '',
                    'ry' => !empty($rect['ry']) ? $rect['ry'] : '',
                    'width' => '0',
                    'height' => '0',
                ],
            ]
        );

        printf( '<div %s>', $self->get_render_attribute_string( 'wrapper' ) );
            printf( '<a %s>', $self->get_render_attribute_string( 'button' ) );
            printf( '<div %s>', $self->get_render_attribute_string( 'content-wrapper' ) );
                if ( ! empty( $_s['icon_type'] ) ) :
                    $icons = new Wgl_Icons;
                    $button_icon_out = $icons->build($self, $_s, []);
                    echo \LittleDino_Theme_Helper::render_html($button_icon_out);
                endif;
                printf( '<span %s>%s</span>',
                    $self->get_render_attribute_string( 'text' ),
                    esc_html($_s['text'])
                );
                if ( $_s['b_dashed_switch'] )
                    printf( '<svg %s><rect %s></rect></svg>',
                        $self->get_render_attribute_string( 'svg' ),
                        $self->get_render_attribute_string( 'rect' )
                    );
                ?>
            </div>
            </a>
        </div>
        <?php
    }

    public function wpml_support_module() {
        add_filter( 'wpml_elementor_widgets_to_translate',  [$this, 'wpml_widgets_to_translate_filter']);
    }

    public function wpml_widgets_to_translate_filter( $widgets ){
        return \WglAddons\Includes\Wgl_WPML_Settings::get_translate(
            $this, $widgets
        );
    }
}