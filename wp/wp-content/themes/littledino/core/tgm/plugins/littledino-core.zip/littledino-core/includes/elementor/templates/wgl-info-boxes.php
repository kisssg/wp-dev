<?php
namespace WglAddons\Templates;

defined('ABSPATH') || exit;

use Elementor\Plugin;
use Elementor\Frontend;
use WglAddons\Includes\Wgl_Loop_Settings;
use WglAddons\Includes\Wgl_Elementor_Helper;
use WglAddons\Includes\Wgl_Carousel_Settings;
use WglAddons\Includes\Wgl_Icons;

/**
* Wgl Elementor Info Boxes Render
*
*
* @category Class
* @author WebGeniusLab <webgeniuslab@gmail.com>
* @since 1.0.0
* @version 1.0.5
*/
class WglInfoBoxes
{
    private static $instance = null;

    public static function get_instance()
    {
		if ( null == self::$instance ) {
			self::$instance = new self();
		}

		return self::$instance;
	}

    public function render($self, $atts)
    {
		extract($atts);

		$theme_color = esc_attr(\LittleDino_Theme_Helper::get_option('theme-custom-color'));
		$h_font_color = esc_attr(\LittleDino_Theme_Helper::get_option('header-font')['color']);
		$main_font_color = esc_attr(\LittleDino_Theme_Helper::get_option('main-font')['color']);

		$ib_icon = $title_out = $title_bg_out = $ib_button = $b_icon_left = $b_icon_right = $ib_link_out = '';
		$svg = $btn_svg = '';

		// Classes
		$ib_wrapper_classes = $icon_type === 'font' ?  ' elementor-icon-box-wrapper' : '';
		$ib_wrapper_classes .= $icon_type === 'image' ? ' elementor-image-box-wrapper' : '';

		// KSES allowed tags
        $allowed_html = [
            'a' => [
                'href' => true, 'title' => true,
                'class' => true, 'style' => true,
                'target' => true, 'rel' => true,
            ],
            'br' => ['class' => true, 'style' => true],
            'em' => ['class' => true, 'style' => true],
            'strong' => ['class' => true, 'style' => true],
            'span' => ['class' => true, 'style' => true],
            'p' => ['class' => true, 'style' => true],
            'ul' => ['class' => true, 'style' => true],
            'ol' => ['class' => true, 'style' => true],
        ];

        // Title out
        if (!empty($ib_title))
            $title_out = sprintf(
                '<%1$s class="wgl-infobox_title">%2$s</%1$s>',
                esc_attr($title_tag),
                wp_kses($ib_title, $allowed_html)
            );

        if (!empty($ib_bg_title))
            $title_bg_out = sprintf(
                '<div class="wgl-infobox_bg_title">%s</div>',
                wp_kses($ib_bg_title, $allowed_html)
            );

        $title_wrap_out = sprintf(
            '<div class="wgl-infobox-title_wrapper">%s%s</div>',
            $title_out,
            $title_bg_out
        );

		// Content out
		$infobox_content = !empty($ib_content) ? '<'.esc_attr($content_tag).' class="wgl-infobox_content">'.wp_kses($ib_content, $allowed_html).'</'.esc_attr($content_tag).'>' : '';

		// Icon/Image out
		if (!empty($icon_type)) {
			$atts['wrapper_class'] = 'wgl-infobox-icon_wrapper';
			$atts['container_class'] = 'wgl-infobox-icon_container';

			$icons = new Wgl_Icons;
			$ib_icon .= $icons->build($self, $atts, []);
		}

		// ↓ svg
		$rect = $btn_rect = [];
		if ( $inner_dashes_switch ) :

			if ( $dashes_disatance['size'] ) $rect['x/y'] = $dashes_disatance['size'] . $dashes_disatance['unit'];
			if ( $dashes_radius['size'] ) $rect['rx/ry'] = $dashes_radius['size'] . $dashes_radius['unit'];

			$self->add_render_attribute(
				[
					'svg' => [
						'class' => [
							'wgl-dashes inner-dashed-border',
							$dashes_anim_switch ? 'animated-dashes' : '',
						],
					],
					'rect' => [
						'x' => !empty($rect['x/y']) ? $rect['x/y'] : '',
						'y' => !empty($rect['x/y']) ? $rect['x/y'] : '',
						'rx' => !empty($rect['rx/ry']) ? $rect['rx/ry'] : '',
						'ry' => !empty($rect['rx/ry']) ? $rect['rx/ry'] : '',
						'width' => '0',
						'height' => '0',
					],
				]
			);

            $svg = sprintf(
                '<svg %s><rect %s></rect></svg>',
                $self->get_render_attribute_string('svg'),
                $self->get_render_attribute_string('rect')
            );
		endif;

		if ( $ib_b_dashes_switch ) :

			if ( $ib_b_dashes_disatance['size'] ) $btn_rect['x/y'] = $ib_b_dashes_disatance['size'] . $ib_b_dashes_disatance['unit'];
			if ( $ib_b_dashes_radius['size'] ) $btn_rect['rx/ry'] = $ib_b_dashes_radius['size'] . $ib_b_dashes_radius['unit'];

			$self->add_render_attribute(
				[
					'btn-svg' => [
						'class' => [
							'wgl-dashes btn-dashes',
							$ib_b_dashes_anim_switch ? 'btn_animated-dashes' : '',
						],
					],
					'btn-rect' => [
						'x' => !empty($btn_rect['x/y']) ? $btn_rect['x/y'] : '',
						'y' => !empty($btn_rect['x/y']) ? $btn_rect['x/y'] : '',
						'rx' => !empty($btn_rect['rx/ry']) ? $btn_rect['rx/ry'] : '',
						'ry' => !empty($btn_rect['rx/ry']) ? $btn_rect['rx/ry'] : '',
						'width' => '0',
						'height' => '0',
					],
				]
			);

			$btn_svg = sprintf(
				'<svg %s><rect %s></rect></svg>',
				$self->get_render_attribute_string('btn-svg'),
				$self->get_render_attribute_string('btn-rect')
			);

		endif;
		// ↑ svg

		if ($add_read_more) :

            // Read more button
            if (!empty($link['url'])) {
                $self->add_link_attributes('link', $link);
            }

            if ($read_more_icon_sticky) {
                $self->add_render_attribute('link', 'class', ['corner-attached', 'corner-position_' . esc_attr($read_more_icon_sticky_pos)]);
            }

            $self->add_render_attribute('link', 'class', [
                'wgl-infobox_button',
                'button-read-more',
                'read-more-icon',
                'icon-position-' . esc_attr($read_more_icon_align)
            ]);

			if ($read_more_icon_switch) :

				switch ($icon_read_more_pack) {
					case 'fontawesome':
						wp_enqueue_style('font-awesome', get_template_directory_uri() . '/css/font-awesome.min.css');
						$icon_font = $read_more_icon_fontawesome;
						break;
					case 'flaticon':
						wp_enqueue_style('flaticon', get_template_directory_uri() . '/fonts/flaticon/flaticon.css');
						$icon_font = $read_more_icon_flaticon;
						break;
				}

				switch ($read_more_icon_align) {
					case 'left': $b_icon_left = '<i class="'.esc_attr($icon_font).'"></i>'; break;
					case 'right': $b_icon_right = '<i class="'.esc_attr($icon_font).'"></i>'; break;
				}

			endif;

			$ib_button .= sprintf(
                '<div class="wgl-infobox-button_wrapper"><a %s>%s%s%s%s</a></div>',
				$self->get_render_attribute_string('link'),
				$b_icon_left,
				esc_html($read_more_text),
				$b_icon_right,
				$btn_svg
			);

		endif;

        if ($ib_link_switch) :
            if (!empty($ib_link['url'])) {
                $self->add_link_attributes('item_link', $ib_link);
            }
            $ib_link_out = '<a class="wgl-infobox_item_link" ' . $self->get_render_attribute_string('item_link') . '></a>';
        endif;

		// Render
		$output = '<div class="wgl-infobox">';
			$output .= $svg;
			$output .= '<div class="wgl-infobox_wrapper'.esc_attr($ib_wrapper_classes).'">';
				$output .= $ib_icon;
				$output .= '<div class="wgl-infobox-content_wrapper">';
				$output .= $title_wrap_out;
				$output .= $infobox_content;
				$output .= $ib_button;
				$output .= '</div>';
				$output .= $ib_link_out;
			$output .= '</div>';
		$output .= '</div>';

		echo \LittleDino_Theme_Helper::render_html($output);
	}
}