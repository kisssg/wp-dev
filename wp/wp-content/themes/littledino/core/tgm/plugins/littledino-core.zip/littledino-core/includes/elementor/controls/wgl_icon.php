<?php
namespace WglAddons\Controls;

use Elementor\Plugin;
use Elementor\Controls_Manager;
use Elementor\Base_Data_Control;

if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
* Wgl Elementor Custom Icon Control
*
*
* @class        Wgl_Icon
* @version      1.0
* @category Class
* @author       WebGeniusLab
*/

class Wgl_Icon extends Base_Data_Control{

    /**
     * Get radio image control type.
     *
     * Retrieve the control type, in this case `radio-image`.
     *
     * @since 1.0.0
     * @access public
     *
     * @return string Control type.
     */
    public function get_type() {
        return 'wgl-icon';
    }

    public function enqueue() {
        // Scripts
        wp_enqueue_script( 'wgl-elementor-extensions', WGL_ELEMENTOR_ADDONS_URL . 'assets/js/wgl_elementor_extenstions.js');

        // Style
        wp_enqueue_style( 'wgl-elementor-extensions', WGL_ELEMENTOR_ADDONS_URL . 'assets/css/wgl_elementor_extenstions.css');
    }

    public static function get_flaticons( ) {
        return array(
            'flaticon-dummy' => 'dummy',
            'flaticon-play-button' => 'play-button',
            'flaticon-close-cross' => 'close-cross',
            'flaticon-star' => 'star',
            'flaticon-arrow-point-to-right' => 'arrow-point-to-right',
            'flaticon-info' => 'info',
            'flaticon-question' => 'question',
            'flaticon-close' => 'close',
            'flaticon-arrow-down-sign-to-navigate' => 'arrow-down-sign-to-navigate',
            'flaticon-shopping-cart' => 'shopping-cart',
            'flaticon-navigate-up-arrow' => 'navigate-up-arrow',
            'flaticon-arrowhead-thin-outline-to-the-left' => 'arrowhead-thin-outline-to-the-left',
            'flaticon-check-mark' => 'check-mark',
            'flaticon-musica-searcher' => 'musica-searcher',
            'flaticon-phone-call' => 'phone-call',
            'flaticon-tyrannosaurus-rex' => 'tyrannosaurus-rex',
            'flaticon-footprint' => 'footprint',
            'flaticon-footprint-1' => 'footprint-1',
            'flaticon-triceratops' => 'triceratops',
            'flaticon-telephone' => 'telephone',
            'flaticon-pencil' => 'pencil',
            'flaticon-baby-bottle' => 'baby-bottle',
            'flaticon-dummy-1' => 'dummy-1',
            'flaticon-teddy-bear' => 'teddy-bear',
            'flaticon-ducky' => 'ducky',
            'flaticon-lollipop' => 'lollipop',
            'flaticon-footprint-2' => 'footprint-2',
            'flaticon-cake' => 'cake',
            'flaticon-dish' => 'dish',
            'flaticon-abc' => 'abc',
            'flaticon-baby-mobile' => 'baby-mobile',
            'flaticon-ball' => 'ball',
            'flaticon-toy-1' => 'toy-1',
            'flaticon-baby-carriage' => 'baby-carriage',
            'flaticon-butterfly' => 'butterfly',
            'flaticon-placeholder' => 'placeholder',
            'flaticon-sending' => 'sending',
            'flaticon-pencil-1' => 'pencil-1',
            'flaticon-start-up' => 'start-up',
            'flaticon-thumbs-up-hand-symbol' => 'thumbs-up-hand-symbol',
            'flaticon-heart' => 'heart',
            'flaticon-eye' => 'eye',
            'flaticon-eye-1' => 'eye-1',
            'flaticon-share' => 'share',
            'flaticon-share-1' => 'share-1',
            'flaticon-web-link' => 'web-link',
            'flaticon-twitter-logo-silhouette' => 'twitter-logo-silhouette',
            'flaticon-facebook-logo' => 'facebook-logo',
            'flaticon-linkedin-logo' => 'linkedin-logo',
            'flaticon-instagram' => 'instagram',
            'flaticon-pinterest-logo' => 'pinterest-logo',
            'flaticon-pinterest' => 'pinterest',
        );
    }

    /**
     * Get radio image control default settings.
     *
     *
     * @since 1.0.0
     * @access protected
     *
     * @return array Control default settings.
     */
    protected function get_default_settings() {
        return [
            'label_block' => true,
            'options' => self::get_flaticons(),
            'include' => '',
            'exclude' => '',
            'select2options' => [],
        ];
    }

    /**
     * Render radio image control output in the editor.
     *
     * Used to generate the control HTML in the editor using Underscore JS
     * template. The variables for the class are available using `data` JS
     * object.
     *
     * @since 1.0.0
     * @access public
     */
    public function content_template() {

        $control_uid = $this->get_control_uid();
        ?>
        <div class="elementor-control-field">
            <# if ( data.label ) {#>
                <label for="<?php echo $control_uid; ?>" class="elementor-control-title">{{{ data.label }}}</label>
            <# } #>
            <div class="elementor-control-input-wrapper">
                <select id="<?php echo $control_uid; ?>" class="elementor-control-icon elementor-select2" type="select2"  data-setting="{{ data.name }}" data-placeholder="<?php echo __( 'Select Icon', 'littledino-core' ); ?>">
                    <# _.each( data.options, function( option_title, option_value ) {
                        var value = data.controlValue;
                        if ( typeof value == 'string' ) {
                            var selected = ( option_value === value ) ? 'selected' : '';
                        } else if ( null !== value ) {
                            var value = _.values( value );
                            var selected = ( -1 !== value.indexOf( option_value ) ) ? 'selected' : '';
                        }
                        #>
                    <option {{ selected }} value="{{ option_value }}">{{{ option_title }}}</option>
                    <# } ); #>
                </select>
            </div>
        </div>
        <# if ( data.description ) { #>
            <div class="elementor-control-field-description">{{{ data.description }}}</div>
        <# } #>
        <?php
    }
}

?>