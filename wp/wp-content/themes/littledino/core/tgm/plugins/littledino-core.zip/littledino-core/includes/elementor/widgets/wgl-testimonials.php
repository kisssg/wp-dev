<?php

namespace WglAddons\Widgets;

if ( ! defined( 'ABSPATH' ) ) exit; // Abort, if accessed directly.

use WglAddons\Includes\Wgl_Icons;
use WglAddons\Includes\Wgl_Carousel_Settings;
use WglAddons\Templates\WglTestimonials;
use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Core\Schemes\Color;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Group_Control_Background;
use Elementor\Utils;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Css_Filter;
use Elementor\Repeater;


class Wgl_Testimonials extends Widget_Base {

    public function get_name() {
        return 'wgl-testimonials';
    }

    public function get_title() {
        return esc_html__( 'WGL Testimonials', 'littledino-core' );
    }

    public function get_icon() {
        return 'wgl-testimonials';
    }

    public function get_script_depends() {
        return [
            'slick',
        ];
    }

    public function get_categories() {
        return [ 'wgl-extensions' ];
    }

    protected function register_controls() {

        $theme_color = esc_attr(\LittleDino_Theme_Helper::get_option('theme-custom-color'));
        $main_font_color = esc_attr(\LittleDino_Theme_Helper::get_option('main-font')['color']);
        $h_font_color = esc_attr(\LittleDino_Theme_Helper::get_option('header-font')['color']);


        /*-----------------------------------------------------------------------------------*/
        /*  CONTENT -> GENERAL
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'section_content_general',
            [ 'label' => esc_html__( 'General', 'littledino-core' ) ]
        );

        $this->add_control(
            'posts_per_line',
            [
                'label' => esc_html__( 'Columns Amount', 'littledino-core' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '1' => esc_html__( 'One Column', 'littledino-core' ),
                    '2' => esc_html__( 'Two Columns', 'littledino-core' ),
                    '3' => esc_html__( 'Three Columns', 'littledino-core' ),
                    '4' => esc_html__( 'Four Columns', 'littledino-core' ),
                    '5' => esc_html__( 'Five Columns', 'littledino-core' ),
                ],
                'default' => '1',
            ]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'thumbnail',
            [
                'label' => esc_html__( 'Image', 'littledino-core' ),
                'type' => Controls_Manager::MEDIA,
                'label_block' => true,
                'default' => [ 'url' => Utils::get_placeholder_image_src() ],
            ]
        );

        $repeater->add_control(
            'author_name',
            [
                'label' => esc_html__( 'Author Name', 'littledino-core' ),
                'type' => Controls_Manager::TEXT,
                'label_block' => true
            ]
        );

        $repeater->add_control(
            'link_author',
            [
                'label' => esc_html__( 'Link Author', 'littledino-core' ),
                'type' => Controls_Manager::URL,
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'author_position',
            [
                'label' => esc_html__( 'Author Position', 'littledino-core' ),
                'type' => Controls_Manager::TEXT,
                'label_block' => true
            ]
        );

        $repeater->add_control(
            'quote',
            [
                'label' => esc_html__( 'Quote', 'littledino-core' ),
                'type' => Controls_Manager::WYSIWYG,
                'label_block' => true
            ]
        );

        $repeater->add_control(
            'unique_quote_bg',
            [
                'label' => esc_html__( 'Add Unique Quote Backgrounds', 'littledino-core' ),
                'type' => Controls_Manager::SWITCHER,
            ]
        );

        $repeater->start_controls_tabs(
            'tabs_unique_quote_bg',
            [ 'condition' => [ 'unique_quote_bg' => 'yes' ] ]
        );

        $repeater->start_controls_tab(
            'tab_unique_quote_bg_idle',
            [ 'label' => esc_html__( 'Idle' , 'littledino-core' ) ]
        );

        $repeater->add_control(
            'quote_bg_idle',
            [
                'label' => esc_html__( 'Background Color', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}} .testimonials__quote' => 'background-color: {{VALUE}};',
                    '{{WRAPPER}} {{CURRENT_ITEM}} .testimonials__quote svg' => 'fill: {{VALUE}};',
                ],
            ]
        );

        $repeater->end_controls_tab();

        $repeater->start_controls_tab(
            'tab_unique_quote_bg_hover',
            [ 'label' => esc_html__( 'Hover' , 'littledino-core' ) ]
        );

        $repeater->add_control(
            'quote_bg_hover',
            [
                'label' => esc_html__( 'Background Color', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}}.testimonials__item-wrap:hover .testimonials__quote' => 'background-color: {{VALUE}};',
                    '{{WRAPPER}} {{CURRENT_ITEM}}.testimonials__item-wrap:hover .testimonials__quote svg' => 'fill: {{VALUE}};',
                ],
            ]
        );

        $repeater->end_controls_tab();
        $repeater->end_controls_tabs();

        $this->add_control(
            'list',
            [
                'label' => esc_html__( 'Items', 'littledino-core' ),
                'type' => Controls_Manager::REPEATER,
                'default' => [
                    [
                        'author_name' => esc_html__( 'Tina Roberts', 'littledino-core' ),
                        'author_position' => '',
                        'quote' => esc_html__( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quisque massa purus, ullamcorper sit amet sollicitudin a, lacinia non est. Integer imperdiet fringilla commodo...', 'littledino-core' ),
                        'thumbnail' => Utils::get_placeholder_image_src()
                    ],
                ],
                'fields' => $repeater->get_controls(),
                'title_field' => '{{{ author_name }}}'
            ]
        );

        $this->add_control(
            'item_type',
            [
                'label' => esc_html__( 'Overall Layout', 'littledino-core' ),
                'type' => 'wgl-radio-image',
                'options' => [
                    'author_top' => [
                        'title'=> esc_html__( 'Top', 'littledino-core' ),
                        'image' => WGL_ELEMENTOR_ADDONS_URL . 'assets/img/wgl_composer_addon/icons/testimonials_1.png',
                    ],
                    'author_bottom' => [
                        'title'=> esc_html__( 'Bottom', 'littledino-core' ),
                        'image' => WGL_ELEMENTOR_ADDONS_URL . 'assets/img/wgl_composer_addon/icons/testimonials_4.png',
                    ],
                    'inline_top' => [
                        'title'=> esc_html__( 'Top Inline', 'littledino-core' ),
                        'image' => WGL_ELEMENTOR_ADDONS_URL . 'assets/img/wgl_composer_addon/icons/testimonials_2.png',
                    ],
                    'inline_bottom' => [
                        'title'=> esc_html__( 'Bottom Inline', 'littledino-core' ),
                        'image' => WGL_ELEMENTOR_ADDONS_URL . 'assets/img/wgl_composer_addon/icons/testimonials_3.png',
                    ],
                ],
                'default' => 'inline_bottom',
            ]
        );

        $this->add_control(
            'item_align',
            [
                'label' => esc_html__( 'Alignment', 'littledino-core' ),
                'type' => Controls_Manager::CHOOSE,
                'toggle' => true,
                'options' => [
                    'left' => [
                        'title' => esc_html__( 'Left', 'littledino-core' ),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'center' => [
                        'title' => esc_html__( 'Center', 'littledino-core' ),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'right' => [
                        'title' => esc_html__( 'Right', 'littledino-core' ),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'default' => 'left',
            ]
        );

        $this->add_control(
            'hover_animation',
            [
                'label' => esc_html__( 'Lift Up the Item on Hover.','littledino-core' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'On', 'littledino-core' ),
                'label_off' => esc_html__( 'Off', 'littledino-core' ),
                'return_value' => 'yes',
            ]
        );

        $this->end_controls_section();


        /*-----------------------------------------------------------------------------------*/
        /*  CONTENT -> CAROUSEL OPTIONS
        /*-----------------------------------------------------------------------------------*/

        Wgl_Carousel_Settings::options($this);


        /*-----------------------------------------------------------------------------------*/
        /*  STYLE -> IMAGE
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'section_style_image',
            [
                'label' => esc_html__( 'Image', 'littledino-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'image_size',
            [
                'label' => esc_html__( 'Image Size', 'littledino-core' ),
                'type' => Controls_Manager::SLIDER,
                'size_units' => [ 'px' ],
                'range' => [
                    'px' => [
                        'min' => 40,
                        'max' => 600,
                    ],
                ],
                'default' => [
                    'size' => 80,
                    'unit' => 'px',
                ],
            ]
        );

        $this->add_responsive_control(
            'image_margin',
            [
                'label' => esc_html__( 'Margin', 'littledino-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-testimonials .testimonials__image' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'image_border',
                'separator' => 'before',
                'selector' => '{{WRAPPER}} .wgl-testimonials .testimonials__image img',
            ]
        );

        $this->add_control(
            'image_border_radius',
            [
                'label' => esc_html__( 'Border Radius', 'littledino-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'default'   => [
                    'top' => 50,
                    'left' => 50,
                    'right' => 50,
                    'bottom' => 50,
                    'unit' => '%',
                ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-testimonials .testimonials__image img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'image',
                'separator' => 'before',
                'selector' => '{{WRAPPER}} .testimonials__image img',
            ]
        );

        $this->end_controls_section();


        /*-----------------------------------------------------------------------------------*/
        /*  STYLE -> QUOTE
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'quote_style_section',
            [
                'label' => esc_html__( 'Quote', 'littledino-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            't_quote_tag',
            [
                'label' => esc_html__( 'HTML tag', 'littledino-core' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'h1' => '‹h1›',
                    'h2' => '‹h2›',
                    'h3' => '‹h3›',
                    'h4' => '‹h4›',
                    'h5' => '‹h5›',
                    'h6' => '‹h6›',
                    'div' => '‹div›',
                    'span' => '‹span›',
                ],
                'default' => 'div',
            ]
        );

        $this->add_responsive_control(
            'quote_padding',
            [
                'label' => esc_html__( 'Padding', 'littledino-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'default' => [
                    'top' => 40,
                    'left' => 40,
                    'right' => 40,
                    'bottom' => 20,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .testimonials__quote' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            't_quote_border_radius',
            [
                'label' => esc_html__( 'Border Radius', 'littledino-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'default' => [
                    'top' => 30,
                    'left' => 30,
                    'right' => 30,
                    'bottom' => 30,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .testimonials__quote' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'quote_margin',
            [
                'label' => esc_html__( 'Margin', 'littledino-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'default' => [
                    'top' => 0,
                    'left' => 0,
                    'right' => 0,
                    'bottom' => 0,
                    'unit' => 'px',
                    'isLinked' => false,
                ],
                'selectors' => [
                    '{{WRAPPER}} .testimonials__quote' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'custom_fonts_quote',
                'selector' => '{{WRAPPER}} .testimonials__quote',
            ]
        );

        $this->start_controls_tabs(
            'tabs_quote_colors',
            [ 'separator' => 'before' ]
        );

        $this->start_controls_tab(
            'tab_quote_colors_idle',
            [ 'label' => esc_html__( 'Idle' , 'littledino-core' ) ]
        );

        $this->add_control(
            't_quote_color_idle',
            [
                'label' => esc_html__( 'Color', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .testimonials__quote' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            't_quote_bg_idle',
            [
                'label' => esc_html__( 'Background Color', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'default' => $theme_color,
                'selectors' => [
                    '{{WRAPPER}} .testimonials__quote' => 'background-color: {{VALUE}};',
                    '{{WRAPPER}} .testimonials__quote svg' => 'fill: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'tab_quote_colors_hover',
            [ 'label' => esc_html__( 'Hover' , 'littledino-core' ) ]
        );

        $this->add_control(
            't_quote_color_hover',
            [
                'label' => esc_html__( 'Color', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'default' => '#ffffff',
                'selectors' => [
                    '{{WRAPPER}} .testimonials__item:hover .testimonials__quote' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            't_quote_bg_hover',
            [
                'label' => esc_html__( 'Background Color', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'default' => $theme_color,
                'selectors' => [
                    '{{WRAPPER}} .testimonials__item-wrap:hover .testimonials__quote' => 'background-color: {{VALUE}};',
                    '{{WRAPPER}} .testimonials__item-wrap:hover svg' => 'fill: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();

        $this->add_control(
            'quote_icon_switch',
            [
                'label' => esc_html__( 'Enable Quote Icon','littledino-core' ),
                'type' => Controls_Manager::SWITCHER,
                'separator' => 'before',
                'label_on' => esc_html__( 'On', 'littledino-core' ),
                'label_off' => esc_html__( 'Off', 'littledino-core' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->start_controls_tabs( 'tabs_quote_icon_colors' );

        $this->start_controls_tab(
            'tab_quote_icon_color_idle',
            [
                'label' => esc_html__( 'Idle' , 'littledino-core' ),
                'condition' => [ 'quote_icon_switch' => 'yes' ]
            ]
        );

        $this->add_control(
            't_quote_icon_color',
            [
                'label' => esc_html__( 'Color', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'condition' => [ 'quote_icon_switch' => 'yes' ],
                'default' => 'rgba(252, 249, 244, 0.23)',
                'selectors' => [
                    '{{WRAPPER}} .testimonials__quote:after' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'tab_quote_icon_color_hover',
            [
                'label' => esc_html__( 'Hover' , 'littledino-core' ),
                'condition' => [ 'quote_icon_switch' => 'yes' ]
            ]
        );

        $this->add_control(
            't_quote_icon_color_hover',
            [
                'label' => esc_html__( 'Color', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'condition' => [ 'quote_icon_switch' => 'yes' ],
                'default' => 'rgba(252, 249, 244, 0.23)',
                'selectors' => [
                    '{{WRAPPER}} .testimonials__item:hover .testimonials__item:after' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();

        $this->add_control(
            'pointing_mark_offset_left',
            [
                'label' => esc_html__( 'Pointing Mark Left Offset', 'littledino-core' ),
                'type' => Controls_Manager::SLIDER,
                'condition' => [
                    'item_type' => 'inline_bottom',
                    'item_align' => [ 'left', 'center' ]
                ],
                'separator' => 'before',
                'size_units' => [ 'px', '%' ],
                'range' => [
                    'px' => [ 'max' => 750 ],
                    '%' => [ 'max' => 90 ],
                ],
                'default' => [
                    'size' => 40,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .testimonials__quote .quote_svg' => 'left: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'pointing_mark_offset_right',
            [
                'label' => esc_html__( 'Pointing Mark Right Offset', 'littledino-core' ),
                'type' => Controls_Manager::SLIDER,
                'condition' => [
                    'item_type' => 'inline_bottom',
                    'item_align' => 'right',
                ],
                'separator' => 'before',
                'size_units' => [ 'px', '%' ],
                'range' => [
                    'px' => [ 'max' => 750 ],
                    '%' => [ 'max' => 90 ],
                ],
                'default' => [
                    'size' => 40,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .testimonials__quote .quote_svg' => 'right: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();


        /*-----------------------------------------------------------------------------------*/
        /*  STYLE -> NAME
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'section_style_author-name',
            [
                'label' => esc_html__( 'Name', 'littledino-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            't_name_tag',
            [
                'label' => esc_html__( 'HTML tag', 'littledino-core' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'h1' => '‹h1›',
                    'h2' => '‹h2›',
                    'h3' => '‹h3›',
                    'h4' => '‹h4›',
                    'h5' => '‹h5›',
                    'h6' => '‹h6›',
                    'div' => '‹div›',
                    'span' => '‹span›',
                ],
                'default' => 'h3',
            ]
        );

        $this->add_responsive_control(
            'name_padding',
            [
                'label' => esc_html__( 'Padding', 'littledino-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'default'   => [
                    'top' => 0,
                    'left' => 0,
                    'right' => 0,
                    'bottom' => 3,
                    'unit' => 'px',
                    'isLinked'  => false
                ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-testimonials .testimonials__name' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->start_controls_tabs( 'tabs_name_colors' );

        $this->start_controls_tab(
            'tab_name_color_idle',
            [ 'label' => esc_html__( 'Idle' , 'littledino-core' ) ]
        );

        $this->add_control(
            't_name_color_idle',
            [
                'label' => esc_html__( 'Color', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'default' => $h_font_color,
                'selectors' => [
                    '{{WRAPPER}} .wgl-testimonials .testimonials__name' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'tab_name_color_hover',
            [ 'label' => esc_html__( 'Hover' , 'littledino-core' ) ]
        );

        $this->add_control(
            't_name_color_hover',
            [
                'label' => esc_html__( 'Color', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'default' => $h_font_color,
                'selectors' => [
                    '{{WRAPPER}} .testimonials__name:hover' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'custom_fonts_name',
                'selector' => '{{WRAPPER}} .wgl-testimonials .testimonials__name',
            ]
        );

        $this->end_controls_section();


        /*-----------------------------------------------------------------------------------*/
        /*  STYLE -> POSITION
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'author_position_style_section',
            [
                'label' => esc_html__( 'Position', 'littledino-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            't_position_tag',
            [
                'label' => esc_html__( 'HTML tag', 'littledino-core' ),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'h1' => '‹h1›',
                    'h2' => '‹h2›',
                    'h3' => '‹h3›',
                    'h4' => '‹h4›',
                    'h5' => '‹h5›',
                    'h6' => '‹h6›',
                    'div' => '‹div›',
                    'span' => '‹span›',
                ],
                'default' => 'span',
            ]
        );

        $this->add_responsive_control(
            't_position_padding',
            [
                'label' => esc_html__( 'Padding', 'littledino-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'default' => [
                    'top' => 0,
                    'unit' => 'px',
                    'isLinked' => false
                ],
                'selectors' => [
                    '{{WRAPPER}} .wgl-testimonials .testimonials__position' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->start_controls_tabs( 'tabs_position_colors' );

        $this->start_controls_tab(
            'tab_position_color_idle',
            [ 'label' => esc_html__( 'Idle' , 'littledino-core' ) ]
        );

        $this->add_control(
            't_position_color_idle',
            [
                'label' => esc_html__( 'Color', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'default' => $main_font_color,
                'selectors' => [
                    '{{WRAPPER}} .wgl-testimonials .testimonials__position' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'tab_position_color_hover',
            [ 'label' => esc_html__( 'Hover' , 'littledino-core' ) ]
        );

        $this->add_control(
            't_position_color_hover',
            [
                'label' => esc_html__( 'Color', 'littledino-core' ),
                'type' => Controls_Manager::COLOR,
                'default' => $main_font_color,
                'selectors' => [
                    '{{WRAPPER}} .wgl-testimonials .testimonials__position:hover' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'custom_fonts_position',
                'selector' => '{{WRAPPER}} .wgl-testimonials .testimonials__position',
            ]
        );

        $this->end_controls_section();


        /*-----------------------------------------------------------------------------------*/
        /*  STYLE -> CONTENT BOX
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'section_style_item',
            [
                'label' => esc_html__( 'Item', 'littledino-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Background::get_type(),
            [
                'name' => 'background_item',
                'label' => esc_html__( 'Background', 'littledino-core' ),
                'types' => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .testimonials__item',
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'testimonials_shadow',
                'selector' =>  '{{WRAPPER}} .testimonials__item',
            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'testimonials_border',
                'label' => esc_html__( 'Border', 'littledino-core' ),
                'selector' => '{{WRAPPER}} .testimonials__item',
            ]
        );

        $this->add_control(
            't_content_border_radius',
            [
                'label' => esc_html__( 'Border Radius', 'littledino-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%' ],
                'selectors' => [
                    '{{WRAPPER}} .testimonials__item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'content_padding',
            [
                'label' => esc_html__( 'Content Padding', 'littledino-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', 'em', '%' ],
                'default' => [
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .testimonials__item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();

    }

    protected function render() {
        $atts = $this->get_settings_for_display();

        $testimonials = new WglTestimonials();
        echo $testimonials->render($this, $atts);
    }

    public function wpml_support_module() {
        add_filter( 'wpml_elementor_widgets_to_translate',  [$this, 'wpml_widgets_to_translate_filter']);
    }

    public function wpml_widgets_to_translate_filter( $widgets ){
        return \WglAddons\Includes\Wgl_WPML_Settings::get_translate(
            $this, $widgets
        );
    }

}