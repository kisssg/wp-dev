<?php
namespace WglAddons\Widgets;

defined('ABSPATH') || exit; // Abort, if accessed directly.

use Elementor\{Widget_Base, Controls_Manager, Control_Media};
use Elementor\{Group_Control_Border, Group_Control_Box_Shadow, Group_Control_Typography};
use Elementor\Repeater;

/**
 * Time Line Vertical widget
 *
 * @category Class
 * @author WebGeniusLab <webgeniuslab@gmail.com>
 * @since 1.0.0
 * @version 1.0.5
 */
class Wgl_Time_Line_Vertical extends Widget_Base
{
    public function get_name()
    {
        return 'wgl-time-line-vertical';
    }

    public function get_title()
    {
        return esc_html__('WGL Time-line Vertical', 'littledino-core');
    }

    public function get_icon()
    {
        return 'wgl-time-line-vertical';
    }

    public function get_categories()
    {
        return ['wgl-extensions'];
    }

    public function get_script_depends()
    {
        return ['appear'];
    }

    protected function register_controls()
    {
        $theme_color = esc_attr(\LittleDino_Theme_Helper::get_option('theme-custom-color'));
        $second_color = esc_attr(\LittleDino_Theme_Helper::get_option('theme-secondary-color'));
        $third_color = esc_attr(\LittleDino_Theme_Helper::get_option('theme-third-color'));
        $h_font_color = esc_attr(\LittleDino_Theme_Helper::get_option('header-font')['color']);
        $main_font_color = esc_attr(\LittleDino_Theme_Helper::get_option('main-font')['color']);

        /*-----------------------------------------------------------------------------------*/
        /*  CONTENT -> GENERAL
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'section_content_general',
            ['label' => esc_html__('General', 'littledino-core')]
        );

        $this->add_control(
            'tlv_add_appear',
            [
                'label' => esc_html__('Enable Appear Animation', 'littledino-core'),
                'type' => Controls_Manager::SWITCHER,
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'line_color',
            [
                'label' => esc_html__('Vertical Line Color', 'littledino-core'),
                'type' => Controls_Manager::COLOR,
                'default' => $theme_color,
                'selectors' => [
                    '{{WRAPPER}} .wgl-timeline-vertical' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'tlv_start_img',
            [
                'label' => esc_html__('Starting Image', 'littledino-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '' => esc_html__('None', 'littledino-core'),
                    'custom' => esc_html__('Custom', 'littledino-core')
                ],
            ]
        );

        $this->add_control(
            'tlv_start_img_thumb',
            [
                'label' => esc_html__('Thumbnail', 'littledino-core'),
                'type' => Controls_Manager::MEDIA,
                'condition' => ['tlv_start_img!' => ''],
            ]
        );

        $this->add_responsive_control(
            'start_image_margin',
            [
                'label' => esc_html__('Image Margin', 'littledino-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'condition' => ['tlv_start_img!' => ''],
                'selectors' => [
                    '{{WRAPPER}} .tlv__start-image' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'start_image_border_radius',
            [
                'label' => esc_html__('Image Border Radius', 'littledino-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'condition' => ['tlv_start_img!' => ''],
                'size_units' => ['px', '%'],
                'default' => [
                    'top' => 50,
                    'right' => 50,
                    'bottom' => 50,
                    'left' => 50,
                    'unit' => '%',
                ],
                'selectors' => [
                    '{{WRAPPER}} .tlv__start-image' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_section();


        /*-----------------------------------------------------------------------------------*/
        /*  CONTENT -> CONTENT
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'content_section',
            ['label' => esc_html__('Content', 'littledino-core')]
        );

        $repeater = new Repeater();

        $repeater->add_control(
            'title',
            [
                'label' => esc_html__('Title', 'littledino-core'),
                'type' => Controls_Manager::TEXT,
                'placeholder' => esc_attr__('Type your heading', 'littledino-core'),
            ]
        );

        $repeater->add_control(
            'date',
            [
                'label' => esc_html__('Date', 'littledino-core'),
                'type' => Controls_Manager::TEXT,
            ]
        );

        $repeater->add_control(
            'content',
            [
                'label' => esc_html__('Content', 'littledino-core'),
                'type' => Controls_Manager::WYSIWYG,
                'default' => esc_html__('Content area.  Lorem ipsum dolor sit amet...', 'littledino-core'),
            ]
        );

        $repeater->add_control(
            'item_thumbnail',
            [
                'label' => esc_html__('Thumbnail', 'littledino-core'),
                'type' => Controls_Manager::MEDIA,
            ]
        );

        $repeater->add_control(
            'item_link',
            [
                'label' => esc_html__('Link', 'littledino-core'),
                'type' => Controls_Manager::URL,
                'description' => esc_html__('Make content and image boxes clickable.', 'littledino-core'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'items',
            [
                'label' => esc_html__('Items', 'littledino-core'),
                'type' => Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'title' => esc_html__('First Heading​', 'littledino-core'),
                        'date' => esc_html__('2019​', 'littledino-core'),

                    ], [
                        'title' => esc_html__('Second Heading​', 'littledino-core'),
                        'date' => esc_html__('2020', 'littledino-core'),
                    ],
                ],
                'title_field' => '{{title}}',
            ]
        );

        $this->end_controls_section();

        /*-----------------------------------------------------------------------------------*/
        /*  STYLE -> TITLE
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'section_style_title',
            [
                'label' => esc_html__('Title', 'littledino-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'title_',
                'selector' => '{{WRAPPER}} .tlv__title',
            ]
        );

        $this->start_controls_tabs('tabs_title_colors');

        $this->start_controls_tab(
            'tab_title_idle_color',
            ['label' => esc_html__('Idle', 'littledino-core')]
        );

        $this->add_control(
            'title_color_idle',
            [
                'label' => esc_html__('Color', 'littledino-core'),
                'type' => Controls_Manager::COLOR,
                'default' => $h_font_color,
                'selectors' => [
                    '{{WRAPPER}} .tlv__title' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'title_color_hover',
            ['label' => esc_html__('Hover', 'littledino-core')]
        );

        $this->add_control(
            'title_hover_color',
            [
                'label' => esc_html__('Color', 'littledino-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tlv__item:hover .tlv__title' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();

        /*-----------------------------------------------------------------------------------*/
        /*  STYLE -> CONTENT
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'content_style_section',
            [
                'label' => esc_html__('Content', 'littledino-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'content_',
                'selector' => '{{WRAPPER}} .tlv__text',
            ]
        );

        $this->add_control(
            'content_color',
            [
                'label' => esc_html__('Color', 'littledino-core'),
                'type' => Controls_Manager::COLOR,
                'default' => $main_font_color,
                'selectors' => [
                    '{{WRAPPER}} .tlv__text' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'content_bg_color',
            [
                'label' => esc_html__('Background Color', 'littledino-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tlv__content' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'content_padding',
            [
                'label' => esc_html__('Padding', 'littledino-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'default' => [
                    'top' => 0,
                    'right' => 0,
                    'bottom' => 0,
                    'left' => 0,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .tlv__content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'content_border_radius',
            [
                'label' => esc_html__('Border Radius', 'littledino-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'default' => [
                    'top' => 0,
                    'right' => 0,
                    'bottom' => 0,
                    'left' => 0,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .tlv__content' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],

            ]
        );

        $this->add_group_control(
            Group_Control_Border::get_type(),
            [
                'name' => 'content_',
                'selector' => '{{WRAPPER}} .tlv__content',
            ]
        );

        $this->add_group_control(
            Group_Control_Box_Shadow::get_type(),
            [
                'name' => 'content_shadow',
                'selector' => '{{WRAPPER}} .tlv__content',
            ]
        );

        $this->end_controls_section();

        /*-----------------------------------------------------------------------------------*/
        /*  STYLE -> DATE
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'section_style_date',
            [
                'label' => esc_html__('Date', 'littledino-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'date_',
                'selector' => '{{WRAPPER}} .tlv__date',
            ]
        );

        $this->start_controls_tabs('tabs_date_colors');

        $this->start_controls_tab(
            'tab_date_idle_color',
            ['label' => esc_html__('Idle', 'littledino-core')]
        );

        $this->add_control(
            'date_color_idle',
            [
                'label' => esc_html__('Color', 'littledino-core'),
                'type' => Controls_Manager::COLOR,
                'default' => $third_color,
                'selectors' => [
                    '{{WRAPPER}} .tlv__date' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'tab_date_hover_color',
            ['label' => esc_html__('Hover', 'littledino-core')]
        );

        $this->add_control(
            'date_color_hover',
            [
                'label' => esc_html__('Color', 'littledino-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tlv__item:hover .tlv__date' => 'color: {{VALUE}};',
                ],
            ]
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();

        /*-----------------------------------------------------------------------------------*/
        /*  STYLE -> THUMBNAIL
        /*-----------------------------------------------------------------------------------*/

        $this->start_controls_section(
            'section_style_thumbnail',
            [
                'label' => esc_html__('Thumbnail', 'littledino-core'),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
            'h_img_container',
            [
                'label' => esc_html__('Image Container', 'littledino-core'),
                'type' => Controls_Manager::HEADING,
            ]
        );

        $this->add_responsive_control(
            'thumb_wrap_diameter',
            [
                'label' => esc_html__('Diameter', 'littledino-core'),
                'type' => Controls_Manager::SLIDER,
                'label_block' => true,
                'range' => ['px' => ['min' => 100, 'max' => 500]],
                'default' => ['size' => 214, 'unit' => 'px'],
                'selectors' => [
                    '{{WRAPPER}} .tlv__thumbnail-wrap' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->start_controls_tabs('tabs_thumbnail');

        $this->start_controls_tab(
            'tab_thumb_idle',
            ['label' => esc_html__('Idle', 'littledino-core')]
        );

        $this->add_control(
            'thumb_bg_idle',
            [
                'label' => esc_html__('Background Color', 'littledino-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tlv__thumbnail-wrap' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'thumb_border_style_idle',
            [
                'label' => esc_html__('Border Type', 'littledino-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'none' => esc_html__('None', 'littledino-core'),
                    'solid'  => esc_html__('Solid', 'littledino-core'),
                    'double' => esc_html__('Double', 'littledino-core'),
                    'dotted' => esc_html__('Dotted', 'littledino-core'),
                    'dashed' => esc_html__('Dashed', 'littledino-core'),
                    'groove' => esc_html__('Groove', 'littledino-core'),
                ],
                'default' => 'solid',
                'selectors' => [
                    '{{WRAPPER}} .tlv__thumbnail-wrap' => 'border-style: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'thumb_border_width_idle',
            [
                'label' => esc_html__('Border Width', 'littledino-core'),
                'type' => Controls_Manager::SLIDER,
                'condition' => ['thumb_border_style_idle!' => 'none'],
                'range' => ['px' => ['max' => 10]],
                'default' => ['size' => 2, 'unit' => 'px'],
                'selectors' => [
                    '{{WRAPPER}} .tlv__thumbnail-wrap' => 'border-width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'thumb_padding_idle',
            [
                'label' => esc_html__('Padding', 'littledino-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'default' => [
                    'top' => 0,
                    'right' => 0,
                    'bottom' => 0,
                    'left' => 0,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .tlv__thumbnail-wrap' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],

            ]
        );

        $this->end_controls_tab();

        $this->start_controls_tab(
            'tab_thumb_hover',
            ['label' => esc_html__('Hover', 'littledino-core')]
        );

        $this->add_control(
            'thumb_bg_hover',
            [
                'label' => esc_html__('Background Color', 'littledino-core'),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .tlv__item:hover  .tlv__thumbnail-wrap' => 'background-color: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'thumb_border_style_hover',
            [
                'label' => esc_html__('Border Type', 'littledino-core'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'none' => esc_html__('None', 'littledino-core'),
                    'solid'  => esc_html__('Solid', 'littledino-core'),
                    'double'  => esc_html__('Double', 'littledino-core'),
                    'dotted'  => esc_html__('Dotted', 'littledino-core'),
                    'dashed'  => esc_html__('Dashed', 'littledino-core'),
                    'groove'  => esc_html__('Groove', 'littledino-core'),
                ],
                'default' => 'dashed',
                'selectors' => [
                    '{{WRAPPER}} .tlv__item:hover .tlv__thumbnail-wrap' => 'border-style: {{VALUE}};',
                ],
            ]
        );

        $this->add_control(
            'thumb_border_width_hover',
            [
                'label' => esc_html__('Border Width', 'littledino-core'),
                'type' => Controls_Manager::SLIDER,
                'condition' => ['thumb_border_style_idle!' => 'none'],
                'range' => ['px' => ['max' => 10]],
                'default' => ['size' => 2, 'unit' => 'px'],
                'selectors' => [
                    '{{WRAPPER}} .tlv__item:hover .tlv__thumbnail-wrap' => 'border-width: {{SIZE}}{{UNIT}};',
                ],
            ]
        );

        $this->add_control(
            'thumb_padding_hover',
            [
                'label' => esc_html__('Padding', 'littledino-core'),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => ['px', '%'],
                'default' => [
                    'top' => 12,
                    'right' => 12,
                    'bottom' => 12,
                    'left' => 12,
                    'unit' => 'px',
                ],
                'selectors' => [
                    '{{WRAPPER}} .tlv__item:hover .tlv__thumbnail-wrap' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->end_controls_tab();
        $this->end_controls_tabs();
        $this->end_controls_section();
    }

    protected function render()
    {
        $_s = $this->get_settings_for_display();

        $this->add_render_attribute(
            [
                'wrapper' => [
                    'class' => [
                        'wgl-timeline-vertical',
                        $_s['tlv_start_img'] ? 'custom-start-img' : '',
                        $_s['tlv_add_appear'] ? 'appear_anim' : '',
                    ],
                ],
                'start-image' => [
                    'class' => 'tlv__start-image',
                    'alt' => Control_Media::get_image_alt($_s['tlv_start_img_thumb']),
                ]
            ]
        );
        if (isset($_s['tlv_start_img_thumb']['url'])) {
            $this->add_render_attribute('start-image', 'src', esc_url($_s['tlv_start_img_thumb']['url']));
        }

        if (isset($_s['tlv_start_img_thumb']['url'])) {
            $start_img['height'] = wp_get_attachment_image_src($_s['tlv_start_img_thumb']['id'], 'full')['2'];
            $start_img['out'] = '<img ' . $this->get_render_attribute_string('start-image') . '/>';
        }

        $this->add_render_attribute(
            'items-wrapper',
            [
                'class' => 'tlv__items-wrap',
                'style' => !empty($start_img['height']) ? 'font-size: ' . $start_img['height'] . 'px' : '',
            ]
        );

        printf('<div %s>', $this->get_render_attribute_string('wrapper'));

        printf('<div class="tlv__item-first">%s</div>', !empty($start_img['out']) ? $start_img['out'] : '');

        printf('<div %s>', $this->get_render_attribute_string('items-wrapper'));

        foreach ($_s['items'] as $index => $item) :
            $wrapper = $this->get_repeater_setting_key('item_wrap', 'items', $index);
            $title = $this->get_repeater_setting_key('title', 'items', $index);
            $thumbnail = $this->get_repeater_setting_key('thumbnail', 'items', $index);
            $item_link = $this->get_repeater_setting_key('item_link', 'items', $index);
            $thumb_url = isset($item['item_thumbnail']['url']) ? esc_url($item['item_thumbnail']['url']) : '';
            $item_url = isset($item['item_link']['url']) ? esc_url($item['item_link']['url']) : '';

            $this->add_render_attribute(
                [
                    $wrapper => [
                        'class' => [
                            'tlv__item',
                            $thumb_url ? '' : 'no-thumb',
                        ],
                    ],
                    $title => ['class' => 'tlv__title'],
                    $thumbnail => [
                        'class' => 'tlv__thumbnail',
                        'src' => $thumb_url,
                        'alt' => Control_Media::get_image_alt($item['item_thumbnail']),
                    ],
                ]
            );

            if ($item_url) {
                $this->add_link_attributes($item_link, $item['item_link']);
            }

            printf('<div %s>', $this->get_render_attribute_string($wrapper)); ?>
            <div class="tlv__pointer"></div><?php

                printf(
                    '<%s class="tlv__content"%s>',
                    $item_url ? 'a' : 'div',
                    $item_url ? $this->get_render_attribute_string($item_link) : ''
                );

                    if ($item['content'] || $item['title']) :

                        if ($item['date'])
                            printf('<h4 class="tlv__date">%s</h4>', esc_html($item['date']));

                        if ($item['title'])
                            printf(
                                '<h3 %s>%s</h3>',
                                $this->get_render_attribute_string($title),
                                esc_html($item['title'])
                            );

                        if ($item['content'])
                            printf('<div class="tlv__text">%s</div>', $item['content']);

                    endif;

                printf('</%s>', $item_url ? 'a' : 'div');
                ?>

                <div class="tlv__media"><?php
                    if (isset($item['item_thumbnail']['url']))
                        printf(
                            '<%1$s class="tlv__thumbnail-wrap"%2$s><img %3$s/></%1$s>',
                            $item_url ? 'a' : 'span',
                            $item_url ? $this->get_render_attribute_string($item_link) : '',
                            $this->get_render_attribute_string($thumbnail)
                        );
                    ?>
                </div>

            </div><?php

        endforeach; ?>

        </div>

        <div class="tlv__item-last"></div>

        </div><?php
    }

    public function wpml_support_module() {
        add_filter( 'wpml_elementor_widgets_to_translate',  [$this, 'wpml_widgets_to_translate_filter']);
    }

    public function wpml_widgets_to_translate_filter( $widgets ){
        return \WglAddons\Includes\Wgl_WPML_Settings::get_translate(
            $this, $widgets
        );
    }
}
