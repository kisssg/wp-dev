<?php

namespace WglAddons\Widgets;

if ( ! defined( 'ABSPATH' ) ) exit; // Abort, if accessed directly.

use WglAddons\Includes\Wgl_Icons;
use WglAddons\Includes\Wgl_Loop_Settings;
use WglAddons\Includes\Wgl_Carousel_Settings;
use WglAddons\Templates\WglPricingTable;
use WglAddons\Widgets\Wgl_Button;
use Elementor\Widget_Base;
use Elementor\Utils;
use Elementor\Controls_Manager;
use Elementor\Core\Schemes\Color;
use Elementor\Scheme_Typography;
use Elementor\Group_Control_Border;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Text_Shadow;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Box_Shadow;


class Wgl_Pricing_Table extends Widget_Base {

	public function get_name() {
		return 'wgl-pricing-table';
	}

	public function get_title() {
		return esc_html__( 'WGL Pricing Table', 'littledino-core' );
	}

	public function get_icon() {
		return 'wgl-pricing-table';
	}

	public function get_categories() {
		return [ 'wgl-extensions' ];
	}

	protected function register_controls() {
		$theme_color = esc_attr(\LittleDino_Theme_Helper::get_option('theme-custom-color'));
		$second_color = esc_attr(\LittleDino_Theme_Helper::get_option('theme-secondary-color'));
		$third_color = esc_attr(\LittleDino_Theme_Helper::get_option('theme-third-color'));
		$header_font_color = esc_attr(\LittleDino_Theme_Helper::get_option('header-font')['color']);
		$main_font_color = esc_attr(\LittleDino_Theme_Helper::get_option('main-font')['color']);


		/*-----------------------------------------------------------------------------------*/
		/*  CONTENT -> GENERAL
		/*-----------------------------------------------------------------------------------*/

		$this->start_controls_section(
			'section_content_general',
			[ 'label' => esc_html__( 'General', 'littledino-core' ) ]
		);

		$this->add_control(
			'p_title',
			[
				'label' => esc_html__( 'Title', 'littledino-core' ),
				'type' => Controls_Manager::TEXT,
				'placeholder' => esc_attr__( 'Type your title', 'littledino-core' ),
				'default' => esc_html__( 'Basic', 'littledino-core' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'p_currency',
			[
				'label' => esc_html__( 'Currency', 'littledino-core' ),
				'type' => Controls_Manager::TEXT,
				'placeholder' => esc_attr__( 'Type your currency', 'littledino-core' ),
				'default' => esc_html__( '$', 'littledino-core' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'p_price',
			[
				'label' => esc_html__( 'Price', 'littledino-core' ),
				'type' => Controls_Manager::TEXT,
				'placeholder' => esc_attr__( 'Type your price', 'littledino-core' ),
				'default' => esc_html__( '99.99', 'littledino-core' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'p_period',
			[
				'label' => esc_html__( 'Payment Period', 'littledino-core' ),
				'type' => Controls_Manager::TEXT,
				'placeholder' => esc_attr__( 'Type your quantity', 'littledino-core' ),
				'default' => esc_html__( 'Per Day', 'littledino-core' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'p_content',
			[
				'label' => esc_html__( 'Content', 'littledino-core' ),
				'type' => Controls_Manager::WYSIWYG,
				'default' => esc_html__( 'Lorem ipsum dolor...', 'littledino-core' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'p_description',
			[
				'label' => esc_html__( 'Description', 'littledino-core' ),
				'type' => Controls_Manager::TEXTAREA,
				'placeholder' => esc_attr__( 'Type your description', 'littledino-core' ),
				'rows' => 2,
				'label_block' => true,
			]
		);

		$this->add_control(
			'hover_animation',
			[
				'label' => esc_html__( 'Enable hover animation','littledino-core' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'On', 'littledino-core' ),
				'label_off' => esc_html__( 'Off', 'littledino-core' ),
				'return_value' => 'yes',
				'description' => esc_html__( 'Lift up the item on hover.', 'littledino-core' ),
			]
		);

		$this->end_controls_section();


		/*-----------------------------------------------------------------------------------*/
		/*  CONTENT -> BUTTON
		/*-----------------------------------------------------------------------------------*/

		$this->start_controls_section(
			'section_content_button',
			[ 'label' => esc_html__( 'Button', 'littledino-core' ) ]
		);

		$this->add_control(
			'b_switch',
			[
				'label' => esc_html__( 'Use button?','littledino-core' ),
				'type' => Controls_Manager::SWITCHER,
				'default' => 'yes',
				'return_value' => 'yes',
			]
		);

		$this->add_control(
			'b_title',
			[
				'label' => esc_html__( 'Button Text', 'littledino-core' ),
				'type' => Controls_Manager::TEXT,
				'condition' => [ 'b_switch' => 'yes' ],
				'default' => esc_html__( 'Choose Plan', 'littledino-core' ),
				'label_block' => true,
			]
		);

		$this->add_control(
			'b_link',
			[
				'label' => esc_html__( 'Button Link', 'littledino-core' ),
				'type' => Controls_Manager::URL,
				'condition' => [ 'b_switch' => 'yes' ],
				'label_block' => true,
			]
		);

		$this->add_responsive_control(
			'b_margin',
			[
				'label' => esc_html__( 'Margin', 'littledino-core' ),
				'type' => Controls_Manager::DIMENSIONS,
				'condition' => [ 'b_switch' => 'yes' ],
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .pricing_footer' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();


		/*-----------------------------------------------------------------------------------*/
		/*  STYLE -> TITLE
		/*-----------------------------------------------------------------------------------*/

		$this->start_controls_section(
			'section_style_title',
			[
				'label' => esc_html__( 'Title', 'littledino-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$_title_icon['icon_align'] = [
			'label' => esc_html__( 'Icon Position', 'littledino-core' ),
			'type' => Controls_Manager::SELECT,
			'condition' => [ 'icon_type!' => '' ],
			'options' => [
				'left' => esc_html__( 'Left', 'littledino-core' ),
				'right' => esc_html__( 'Right', 'littledino-core' ),
			],
			'default' => 'left',
		];

		$_title_icon['icon_indent'] = [
			'label' => esc_html__( 'Icon Spacing (px)', 'littledino-core' ),
			'type' => Controls_Manager::SLIDER,
			'condition' => [ 'icon_type!' => '' ],
			'range' => [ 'px' => [ 'max' => 50 ] ],
			'default' => [ 'size' => 7, 'unit' => 'px' ],
			'selectors' => [
				'{{WRAPPER}} .pricing_title.icon-left .wgl-icon' => 'margin-right: {{SIZE}}{{UNIT}};',
				'{{WRAPPER}} .pricing_title.icon-right .wgl-icon' => 'margin-left: {{SIZE}}{{UNIT}};',
			],
		];

		Wgl_Icons::init(
			$this,
			[ 'output' => $_title_icon ]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'pricing_title_typo',
				'separator' => 'before',
				'fields_options' => [
                    'typography' => ['default' => 'yes'],
                    'font_family' => ['default' => \Wgl_Addons_Elementor::$typography_1['font_family']],
                    'font_weight' => ['default' => \Wgl_Addons_Elementor::$typography_1['font_weight']],
                ],
                'selector' => '{{WRAPPER}} .pricing_title',
			]
		);

		$this->add_control(
			'title_color',
			[
				'label' => esc_html__( 'Color', 'littledino-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .pricing_title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'title_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'littledino-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => $third_color,
				'selectors' => [
					'{{WRAPPER}} .pricing_title' => 'background: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'title_padding',
			[
				'label' => esc_html__( 'Padding', 'littledino-core' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .pricing_title' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'title_margin',
			[
				'label' => esc_html__( 'Margin', 'littledino-core' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .pricing_title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();


		/*-----------------------------------------------------------------------------------*/
		/*  STYLE -> PRICE
		/*-----------------------------------------------------------------------------------*/

		$this->start_controls_section(
			'section_style_price',
			[
				'label' => esc_html__( 'Price', 'littledino-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'pricing_price_typo',
				'fields_options' => [
                    'typography' => ['default' => 'yes'],
                    'font_family' => ['default' => \Wgl_Addons_Elementor::$typography_1['font_family']],
                    'font_weight' => ['default' => \Wgl_Addons_Elementor::$typography_1['font_weight']],
                ],
                'selector' => '{{WRAPPER}} .pricing_price_wrap',
			]
		);

		$this->add_control(
			'p_color',
			[
				'label' => esc_html__( 'Color', 'littledino-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .pricing_price_wrap' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'p_margin',
			[
				'label' => esc_html__( 'Margin', 'littledino-core' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .pricing_price_wrap' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();


		/*-----------------------------------------------------------------------------------*/
		/*  STYLE -> PERIOD
		/*-----------------------------------------------------------------------------------*/

		$this->start_controls_section(
			'section_style_period',
			[
				'label' => esc_html__( 'Period', 'littledino-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'pricing_period_typo',
				'fields_options' => [
                    'typography' => ['default' => 'yes'],
                    'font_family' => ['default' => \Wgl_Addons_Elementor::$typography_1['font_family']],
					'font_weight' => ['default' => \Wgl_Addons_Elementor::$typography_1['font_weight']],
					'font_size' => ['default' => [ 'size' => 0.3, 'unit' => 'em' ]]
                ],
                'selector' => '{{WRAPPER}} .pricing_period',
			]
		);

		$this->add_control(
			'period_color',
			[
				'label' => esc_html__( 'Color', 'littledino-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '#d3a852',
				'selectors' => [
					'{{WRAPPER}} .pricing_period' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'period_margin',
			[
				'label' => esc_html__( 'Margin', 'littledino-core' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .pricing_period' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();


		/*-----------------------------------------------------------------------------------*/
		/*  STYLE -> CONTENT
		/*-----------------------------------------------------------------------------------*/

		$this->start_controls_section(
			'section_style_content',
			[
				'label' => esc_html__( 'Content', 'littledino-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'pricing_content_typo',
				'fields_options' => [
                    'typography' => ['default' => 'yes'],
                    'font_family' => ['default' => \Wgl_Addons_Elementor::$typography_1['font_family']],
                    'font_weight' => ['default' => \Wgl_Addons_Elementor::$typography_1['font_weight']],
                ],
                'selector' => '{{WRAPPER}} .pricing_content',
			]
		);

		$this->add_control(
			'content_color',
			[
				'label' => esc_html__( 'Color', 'littledino-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => $header_font_color,
				'selectors' => [
					'{{WRAPPER}} .pricing_content' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'contet_margin',
			[
				'label' => esc_html__( 'Margin', 'littledino-core' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .pricing_content' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();


		/*-----------------------------------------------------------------------------------*/
		/*  STYLE -> DESCRIPTION
		/*-----------------------------------------------------------------------------------*/

		$this->start_controls_section(
			'section_style_description',
			[
				'label' => esc_html__( 'Description', 'littledino-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'pricing_desc_typo',
				'fields_options' => [
                    'typography' => ['default' => 'yes'],
                    'font_family' => ['default' => \Wgl_Addons_Elementor::$typography_1['font_family']],
                    'font_weight' => ['default' => \Wgl_Addons_Elementor::$typography_1['font_weight']],
                ],
                'selector' => '{{WRAPPER}} .pricing_desc',
			]
		);

		$this->add_control(
			'description_color',
			[
				'label' => esc_html__( 'Color', 'littledino-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => esc_attr($main_font_color),
				'selectors' => [
					'{{WRAPPER}} .pricing_desc' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_responsive_control(
			'description_margin',
			[
				'label' => esc_html__( 'Padding', 'littledino-core' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} .pricing_desc' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();


		/*-----------------------------------------------------------------------------------*/
		/*  STYLE -> BUTTON
		/*-----------------------------------------------------------------------------------*/

		$this->start_controls_section(
			'section_style_button',
			[
				'label' => esc_html__( 'Button', 'littledino-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'typography',
				'selector' => '{{WRAPPER}} a.elementor-button, {{WRAPPER}} .elementor-button',
			]
		);

		$this->start_controls_tabs( 'tabs_button_style' );

		$this->start_controls_tab(
			'tab_button_idle',
			[ 'label' => esc_html__( 'Idle', 'littledino-core' ) ]
		);

		$this->add_control(
			'b_color_idle',
			[
				'label' => esc_html__( 'Text Color', 'littledino-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} a.elementor-button, {{WRAPPER}} .elementor-button' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'b_bg_color_idle',
			[
				'label' => esc_html__( 'Background Color', 'littledino-core' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Color::get_type(),
					'value' => Color::COLOR_1,
				],
				'default' => $theme_color,
				'selectors' => [
					'{{WRAPPER}} a.elementor-button, {{WRAPPER}} .elementor-button' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'tab_button_hover',
			[ 'label' => esc_html__( 'Hover', 'littledino-core' ) ]
		);

		$this->add_control(
			'b_color_hover',
			[
				'label' => esc_html__( 'Text Color', 'littledino-core' ),
				'type' => Controls_Manager::COLOR,
				'default' => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} a.elementor-button:hover, {{WRAPPER}} .elementor-button:hover, {{WRAPPER}} a.elementor-button:focus, {{WRAPPER}} .elementor-button:focus' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'b_bg_color_hover',
			[
				'label' => esc_html__( 'Background Color', 'littledino-core' ),
				'type' => Controls_Manager::COLOR,
				'scheme' => [
					'type' => Color::get_type(),
					'value' => Color::COLOR_2,
				],
				'default' => $third_color,
				'selectors' => [
					'{{WRAPPER}} a.elementor-button:hover, {{WRAPPER}} .elementor-button:hover, {{WRAPPER}} a.elementor-button:focus, {{WRAPPER}} .elementor-button:focus' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'b_border_color_hover',
			[
				'label' => esc_html__( 'Border Color', 'littledino-core' ),
				'type' => Controls_Manager::COLOR,
				'condition' => [ 'border_border!' => '' ],
				'scheme' => [
					'type' => Color::get_type(),
					'value' => Color::COLOR_1,
				],
				'selectors' => [
					'{{WRAPPER}} a.elementor-button:hover, {{WRAPPER}} .elementor-button:hover, {{WRAPPER}} a.elementor-button:focus, {{WRAPPER}} .elementor-button:focus' => 'border-color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'border',
				'selector' => '{{WRAPPER}} .elementor-button',
				'separator' => 'before',
			]
		);

		$this->add_control(
			'b_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'littledino-core' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} a.elementor-button, {{WRAPPER}} .elementor-button' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'button',
				'selector' => '{{WRAPPER}} .elementor-button',
			]
		);

		$this->add_responsive_control(
			'b_padding',
			[
				'label' => esc_html__( 'Padding', 'littledino-core' ),
				'type' => Controls_Manager::DIMENSIONS,
				'separator' => 'before',
				'size_units' => [ 'px', 'em', '%' ],
				'selectors' => [
					'{{WRAPPER}} a.elementor-button, {{WRAPPER}} .elementor-button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_control(
			'b_dashed_switch',
			[
				'label' => esc_html__( 'Use inner dashed border?', 'littledino-core' ),
				'type' => Controls_Manager::SWITCHER,
				'separator' => 'before',
				'default' => 'yes',
			]
		);

		$this->add_control(
			'b_dashed_anim_switch',
			[
				'label' => esc_html__( 'Use running animation on Hover state?', 'littledino-core' ),
				'type' => Controls_Manager::SWITCHER,
				'condition' => [ 'b_dashed_switch' => 'yes' ],
				'default' => 'yes',
			]
		);

		$this->add_control(
			'b_dashed_color',
			[
				'label' => esc_html__( 'Dashes Color', 'littledino-core' ),
				'type' => Controls_Manager::COLOR,
				'condition' => [ 'b_dashed_switch' => 'yes' ],
				'default' => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .wgl-button.elementor-button .inner-dashed-border' => 'stroke: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'b_dashed_disatance',
			[
				'label' => esc_html__( 'Dashes Offset', 'littledino-core' ),
				'type' => Controls_Manager::SLIDER,
				'condition' => [ 'b_dashed_switch' => 'yes' ],
				'label_block' => true,
				'range' => [ 'px' => [ 'max' => 35 ] ],
				'default' => [ 'size' => 5, 'unit' => 'px' ],
			]
		);

		$this->end_controls_section();


		/*-----------------------------------------------------------------------------------*/
		/*  STYLE -> BACKGROUND
		/*-----------------------------------------------------------------------------------*/

		$this->start_controls_section(
			'section_style_bg',
			[
				'label' => esc_html__( 'Background', 'littledino-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'bg_scheme',
			[
				'label' => esc_html__( 'Customize background for:', 'littledino-core' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'module' => esc_html__( 'whole module', 'littledino-core' ),
					'sections'  => esc_html__( 'each of sections', 'littledino-core' ),
				],
				'default' => 'sections',
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name' => 'module',
				'label' => esc_html__( 'Background', 'littledino-core' ),
				'types' => [ 'classic', 'gradient' ],
				'condition' => [ 'bg_scheme' => 'module' ],
				'selector' => '{{WRAPPER}} .pricing_plan_wrap',
			]
		);

		$this->add_control(
			'punches_bg',
			[
				'label' => esc_html__( 'Pricing Punches Background', 'littledino-core' ),
				'type' => Controls_Manager::COLOR,
				'condition' => [ 'bg_scheme' => 'sections' ],
				'description' => esc_html__( 'Three punched holes at the module top.', 'littledino-core' ),
				'default' => '#ffffff',
				'selectors' => [
					'{{WRAPPER}} .pricing_punch_1' => 'background-color: {{VALUE}};',
					'{{WRAPPER}} .pricing_punch_2' => 'background-color: {{VALUE}};',
					'{{WRAPPER}} .pricing_punch_3' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'header_s_bg',
			[
				'label' => esc_html__( 'Header Section Background', 'littledino-core' ),
				'type' => Controls_Manager::COLOR,
				'condition' => [ 'bg_scheme' => 'sections' ],
				'default' => $second_color,
				'selectors' => [
					'{{WRAPPER}} .pricing_plan_wrap .pricing_header' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'content_s_bg',
			[
				'label' => esc_html__( 'Content Section Background', 'littledino-core' ),
				'type' => Controls_Manager::COLOR,
				'condition' => [ 'bg_scheme' => 'sections' ],
				'default' => '#fcf9f4',
				'selectors' => [
					'{{WRAPPER}} .pricing_plan_wrap .pricing_content' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'footer_s_bg',
			[
				'label' => esc_html__( 'Footer Section Background', 'littledino-core' ),
				'type' => Controls_Manager::COLOR,
				'condition' => [ 'bg_scheme' => 'sections' ],
				'default' => '#fcf9f4',
				'selectors' => [
					'{{WRAPPER}} .pricing_plan_wrap .pricing_footer' => 'background-color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'bg_border_radius',
			[
				'label' => esc_html__( 'Border Radius', 'littledino-core' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%' ],
				'default'   => [
					'top' => 30,
					'right' => 30,
					'bottom' => 30,
					'left' => 30,
					'unit'  => 'px',
				],
				'selectors' => [
					'{{WRAPPER}} .pricing_plan_wrap' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'bg_border',
				'selector' => '{{WRAPPER}} .pricing_plan_wrap',
			]
		);

		$this->end_controls_section();
	}

	protected function render() {

		$_s = $this->get_settings_for_display();

		$title = $title_icon = $currency = $price = $description = $period = $button = '';

		$icon_align = isset($_s['icon_align']) ? $_s['icon_align'] : '';

        // KSES allowed tags
        $allowed_html = [
            'a' => [
                'href' => true, 'title' => true,
                'class' => true, 'style' => true,
                'target' => true, 'rel' => true,
            ],
            'br' => ['class' => true, 'style' => true],
            'em' => ['class' => true, 'style' => true],
            'strong' => ['class' => true, 'style' => true],
            'span' => ['class' => true, 'style' => true],
            'p' => ['class' => true, 'style' => true],
            'ul' => ['class' => true, 'style' => true],
            'ol' => ['class' => true, 'style' => true],
        ];

		$this->add_render_attribute(
			[
				'wrapper' => [
					'class' => [
						'wgl__pricing_plan',
						$_s['hover_animation'] ? ' hover-animation' : '',
					],
				],
				'pricing_title' => [
					'class' => [
						'pricing_title',
						isset($_s['icon_align']) ? 'icon-'.$_s['icon_align'] : '',
					],
				]
			]
		);

		$punches = '<span class="pricing_punch_1"></span><span class="pricing_punch_2"></span><span class="pricing_punch_3"></span>';

		// Title
		if ( $_s['p_title'] ) {
			if ( ! empty( $_s['icon_type'] ) ) {
				$_s['get_wrappless_icon'] = true;
				$icon = new Wgl_Icons;
				$title_icon = $icon->build($this, $_s, []);
			}

			$title = sprintf( '<div class="pricing_title_wrap"><h4 %s>%s%s</h4></div>',
				$this->get_render_attribute_string( 'pricing_title' ),
				$title_icon,
				esc_html($_s['p_title'])
			);
		}

		// Currency
		if ( $_s['p_currency'] )
			$currency = sprintf( '<span class="price_currency">%s</span>', esc_html($_s['p_currency']) );

		// Price
		if ( $_s['p_price'] ) {
			preg_match( "/(\d+)(\.| |,)(\d+)$/", $_s['p_price'], $matches, PREG_OFFSET_CAPTURE );
			switch (isset($matches[0])) {
				case false:
				case true:
					$price = sprintf( '<span class="pricing_price">%s</span>', esc_html($_s['p_price']) );
					break;
				default:
					$price_decimal = sprintf( '<span class="price_decimal">%s</span>', esc_html($matches[3][0]) );
					$price = sprintf( '<span class="pricing_price">%s%s</span>',
						esc_html($matches[1][0]),
						$price_decimal
					);
					break;
			}
		}

		// Period
		if ( !empty($_s['p_period']) )
			$period = sprintf( '<span class="pricing_period">%s</span>', esc_html($_s['p_period']) );

		// Description
		if ( $_s['p_description'] )
			$description = sprintf( '<div class="pricing_desc">%s</div>', wp_kses( $_s['p_description'], $allowed_html ) );

		// Button
		if ( (bool)$_s['b_switch'] ) {
			$button_options = [
				'icon_type' => '',
				'text' => $_s['b_title'],
				'link' => $_s['b_link'],
				'b_size' => 'xl',
				'b_dashed_switch' => $_s['b_dashed_switch'],
				'b_dashed_anim_switch' => $_s['b_dashed_anim_switch'],
				'b_dashed_color' => $_s['b_dashed_color'],
				'b_dashed_disatance' => $_s['b_dashed_disatance'],
				'b_border_radius' => $_s['b_border_radius'],
			];
			ob_start();
				echo Wgl_Button::init_button($this, $button_options);
			$button = ob_get_clean();
		}

		// Define module structure
		$module = '<div class="pricing_header">';
			$module .= $punches;
			$module .= '<div class="pricing_price_wrap">';
				$module .= $currency;
				$module .= $price;
				$module .= $period;
			$module .= '</div>';
		$module .= '</div>';
		$module .= '<div class="pricing_content">';
			$module .= $title;
			$module .= $_s['p_content'];
		$module .= '</div>';
		$module .= '<div class="pricing_footer">';
			$module .= $description;
			$module .= $button;
		$module .= '</div>';

		// Render
		printf( '<div %s>', $this->get_render_attribute_string( 'wrapper' ) ); ?>
			<div class="pricing_plan_wrap"><?php
				printf($module); ?>
			</div>
		</div>
		<?php
	}

	public function wpml_support_module() {
        add_filter( 'wpml_elementor_widgets_to_translate',  [$this, 'wpml_widgets_to_translate_filter']);
    }

    public function wpml_widgets_to_translate_filter( $widgets ){
        return \WglAddons\Includes\Wgl_WPML_Settings::get_translate(
            $this, $widgets
        );
    }
}