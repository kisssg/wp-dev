<?php
namespace WglAddons\Templates;

defined('ABSPATH') || exit;

use WglAddons\Includes\Wgl_Carousel_Settings;

if (!class_exists('WglTestimonials')) {
    /**
    * Wgl Elementor Testimonials Render
    *
    *
    * @category Class
    * @author WebGeniusLab <webgeniuslab@gmail.com>
    * @since 1.0.0
    * @version 1.0.5
    */
    class WglTestimonials
    {
        private static $instance = null;

        public static function get_instance()
        {
			if ( null == self::$instance ) {
				self::$instance = new self( );
			}

			return self::$instance;
		}

        public function render($self, $atts)
        {
			extract($atts);
			
			$content = '';

			if ( $use_carousel ) {
				// carousel options array
				$carousel_options = [
					'slide_to_show' => $posts_per_line,
					'autoplay' => $autoplay,
					'autoplay_speed' => $autoplay_speed,
					'fade_animation' => $fade_animation,
					'slides_to_scroll' => true,
					'infinite' => true,
					'use_pagination' => $use_pagination,
					'pag_type' => $pag_type,
					'pag_offset' => $pag_offset,
					'pag_align' => $pag_align,
					'custom_pag_color' => $custom_pag_color,
					'pag_color' => $pag_color,
					'use_prev_next' => $use_prev_next, 
					'prev_next_position' => $prev_next_position,
					'custom_prev_next_color' => $custom_prev_next_color,
					'prev_next_color' => $prev_next_color,
					'prev_next_color_hover' => $prev_next_color_hover,
					'prev_next_bg_idle' => $prev_next_bg_idle,
					'prev_next_bg_hover' => $prev_next_bg_hover,
					'custom_resp' => $custom_resp,
					'resp_medium' => $resp_medium,
					'resp_medium_slides' => $resp_medium_slides,
					'resp_tablets' => $resp_tablets,
					'resp_tablets_slides' => $resp_tablets_slides,
					'resp_mobile' => $resp_mobile,
					'resp_mobile_slides' => $resp_mobile_slides,
				];

				wp_enqueue_script( 'slick', get_template_directory_uri() . '/js/slick.min.js', [], false, false);
			}

			switch ($posts_per_line) {
				case '1': $col = 1; break;  
				case '2': $col = 2; break;
				case '3': $col = 3; break;
				case '4': $col = 4; break;
				case '5': $col = 5; break;
			}

			// Wrapper classes
			$self->add_render_attribute( 'wrapper', 'class', [ 'wgl-testimonials', 'type-'.$item_type, ' align-'.$item_align  ] );
			if ( $hover_animation ) $self->add_render_attribute( 'wrapper', 'class', 'hover_animation' );
			if ( $quote_icon_switch ) $self->add_render_attribute( 'wrapper', 'class', 'add_quote_icon' );
			if ( ! $use_carousel ) $self->add_render_attribute( 'wrapper', 'class', 'grid_col-'.$col );

            // Image styles
            $default_width = 80; // define manually
            $image_size = isset($image_size['size']) ? $image_size['size'] : '';
            $image_width_crop = !empty($image_size) ? $image_size * 2 : $default_width * 2;
            $image_width = 'width: ' . (!empty($image_size) ? (int) $image_size : $default_width) . 'px;';
			

			$items = (array)$list;
			foreach ( $items as $item ) :

				// repeater variables initialization
				foreach ($item as $k => $v) {
					${$k} = null;
					${$k} = $item[$k] ?? false;
				}

				// components
				$name_out = $quote_out = $position_out = $img_src = $thumb_out = $svg_style = '';

                if ($link_author['url']) {
                    $self->add_link_attributes('link_author', $link_author);
                }

                if (isset($author_name)) {
                    $name_out = sprintf(
                        '<%1$s class="testimonials__name">%3$s%2$s%4$s</%1$s>',
                        esc_attr($t_name_tag),
                        esc_html($author_name),
                        ($link_author['url'] ? '<a ' . $self->get_render_attribute_string('link_author') . '>' : ''),
                        ($link_author['url'] ? '</a>' : '')
                    );
                }

				if ( isset($quote) ) {
					$ib_svg = $item_type == 'inline_bottom' ? '<svg class="quote_svg" '.$svg_style.' viewBox="0 0 259.43 367.5"><path d="M.53,0H255.84c15,14-23.29,233.58.07,367.5C255.91,367.5-13.49,272.51.53,0Z"></path></svg>' : '';
					
					$quote_out = sprintf(
                        '<%1$s class="testimonials__quote">%2$s%3$s</%1$s>',
						esc_attr($t_quote_tag),
						$quote,
						$ib_svg
					);
				}

                if (isset($author_position)) {
                    $position_out = sprintf(
                        '<%1$s class="testimonials__position">%2$s</%1$s>',
                        esc_attr($t_position_tag),
                        esc_html($author_position)
                    );
                }

                if (isset($thumbnail)) {
                    $img_src = aq_resize($thumbnail['url'], $image_width_crop, $image_width_crop, true, true, true);
                    if ($img_src) {
                        $thumb_out = '<div class="testimonials__image">';
                        $thumb_out .= sprintf(
                            '%s<img src="%s" alt="%s photo" style="%s">%s',
                            ($link_author['url'] ? '<a ' . $self->get_render_attribute_string('link_author') . '>' : ''),
                            esc_url($img_src),
                            esc_attr($author_name),
                            esc_attr($image_width),
                            ($link_author['url'] ? '</a>' : '')
                        );
                        $thumb_out .= '</div>';
                    }
                }

				// structure out of components
				$content .= '<div class="testimonials__item-wrap elementor-repeater-item-'.$_id.'">';
					switch ($item_type) {
						case 'author_top':
							$content .= '<div class="testimonials__item">';
								$content .= '<div class="testimonials__content-wrap">';
									$content .= $thumb_out;
									$content .= $quote_out;
								$content .= '</div>';
								$content .= '<div class="testimonials__meta-wrap">';
									$content .= '<div class="testimonials__name-wrap">';
										$content .= $name_out;
										$content .= $position_out;
									$content .= '</div>';
								$content .= '</div>';
							$content .= '</div>';
							break;
						case 'author_bottom':
							$content .= '<div class="testimonials__item">';
								$content .= '<div class="testimonials__content-wrap">';
									$content .= $quote_out;
								$content .= '</div>';
								$content .= '<div class="testimonials__meta-wrap">';
									$content .= $thumb_out;
									$content .= '<div class="testimonials__name-wrap">';
										$content .= $name_out;
										$content .= $position_out;
									$content .= '</div>';
								$content .= '</div>';
							$content .= '</div>';
							break;
						case 'inline_top':
							$content .= '<div class="testimonials__item">';
								$content .= '<div class="testimonials__content-wrap">';
									$content .= '<div class="testimonials__meta-wrap">';
										$content .= $thumb_out;
										$content .= '<div class="testimonials__name-wrap">';
											$content .= $name_out;
											$content .= $position_out;
										$content .= '</div>';
									$content .= '</div>';
									$content .= $quote_out;
								$content .= '</div>';
							$content .= '</div>';
							break;
						case 'inline_bottom':
							$content .= '<div class="testimonials__item">';
								$content .= '<div class="testimonials__content-wrap">';
									$content .= $quote_out;
								$content .= '</div>';
								$content .= '<div class="testimonials__meta-wrap">';
									$content .= $thumb_out;
									$content .= '<div class="testimonials__name-wrap">';
										$content .= $name_out;
										$content .= $position_out;
									$content .= '</div>';
								$content .= '</div>';
							$content .= '</div>';
							break;
					}
				$content .= '</div>';

			endforeach;

			// module
			$output = sprintf( '<div %s>', $self->get_render_attribute_string( 'wrapper' ) );
				if ( $use_carousel ) {
					$output .= Wgl_Carousel_Settings::init($carousel_options, $content, false);
				} else {
					$output .= $content;
				}
			$output .= '</div>';

			return $output;
		}
	}
}
